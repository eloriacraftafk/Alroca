/*
 * PanicWipe — deletes client remnants from disk then schedules exit.
 * Targets: config folder, profile folder, jar file, common leftover names.
 */

package dlindustries.uk.daduncs.managers;

import dlindustries.uk.daduncs.Alroca;
import net.minecraft.client.MinecraftClient;

import java.io.File;
import java.io.IOException;
import java.nio.file.FileVisitResult;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.SimpleFileVisitor;
import java.nio.file.attribute.BasicFileAttributes;

public final class PanicWipe {

    private PanicWipe() {}

    public static void execute() {
        try {
            Path cwd = Paths.get(System.getProperty("user.dir"));
            // known config / profile trees
            wipeTree(cwd.resolve("alrocaconfigv2"));
            wipeTree(cwd.resolve("454config"));
            wipeTree(cwd.resolve("config").resolve("alroca"));
            wipeTree(cwd.resolve("config").resolve("454"));
            wipeTree(cwd.resolve("config").resolve("marlowcrystal"));

            // jar itself
            try {
                if (Alroca.INSTANCE != null && Alroca.INSTANCE.alrocaJar != null) {
                    File jar = Alroca.INSTANCE.alrocaJar;
                    if (jar.exists()) {
                        jar.deleteOnExit();
                        // best effort immediate delete (often locked on Windows)
                        //noinspection ResultOfMethodCallIgnored
                        jar.delete();
                    }
                }
            } catch (Throwable ignored) {}

            // also try ProtectionDomain location again
            try {
                File self = new File(Alroca.class.getProtectionDomain().getCodeSource().getLocation().toURI());
                if (self.isFile()) {
                    self.deleteOnExit();
                    //noinspection ResultOfMethodCallIgnored
                    self.delete();
                }
            } catch (Throwable ignored) {}

            // mods folder copies with known names
            try {
                Path mods = cwd.resolve("mods");
                if (Files.isDirectory(mods)) {
                    try (var stream = Files.list(mods)) {
                        stream.filter(p -> {
                            String n = p.getFileName().toString().toLowerCase();
                            return n.contains("alroca") || n.contains("454") || n.contains("system-client")
                                    || n.endsWith("b2.0.jar");
                        }).forEach(p -> {
                            try {
                                Files.deleteIfExists(p);
                            } catch (IOException ignored) {}
                        });
                    }
                }
            } catch (Throwable ignored) {}

        } finally {
            // hard leave so no further packets / modules run
            try {
                MinecraftClient mc = MinecraftClient.getInstance();
                if (mc != null) {
                    mc.execute(() -> {
                        try {
                            if (mc.world != null) mc.world.disconnect(null);
                        } catch (Throwable ignored) {}
                        mc.scheduleStop();
                    });
                } else {
                    System.exit(0);
                }
            } catch (Throwable t) {
                System.exit(0);
            }
        }
    }

    private static void wipeTree(Path root) {
        if (root == null || !Files.exists(root)) return;
        try {
            Files.walkFileTree(root, new SimpleFileVisitor<>() {
                @Override
                public FileVisitResult visitFile(Path file, BasicFileAttributes attrs) throws IOException {
                    Files.deleteIfExists(file);
                    return FileVisitResult.CONTINUE;
                }

                @Override
                public FileVisitResult postVisitDirectory(Path dir, IOException exc) throws IOException {
                    Files.deleteIfExists(dir);
                    return FileVisitResult.CONTINUE;
                }
            });
        } catch (IOException ignored) {}
    }
}
