/*
 * ElytraFly — controlled glide with soft accel + vanilla-ish caps
 * Bypass surface: horizontal speed soft-limit, min-delta velocity writes,
 * optional GCD look, Antiban action gate, no packet spam.
 */

package dlindustries.uk.daduncs.module.modules.sword;

import dlindustries.uk.daduncs.event.events.TickListener;
import dlindustries.uk.daduncs.managers.AntibanbyDaduncs;
import dlindustries.uk.daduncs.module.Category;
import dlindustries.uk.daduncs.module.Module;
import dlindustries.uk.daduncs.module.setting.bool;
import dlindustries.uk.daduncs.module.setting.number;
import dlindustries.uk.daduncs.utils.EncryptedString;
import dlindustries.uk.daduncs.utils.RotationUtils;
import dlindustries.uk.daduncs.utils.rotation.Rotation;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

public final class ElytraFly extends Module implements TickListener {

    private final number speed = new number(EncryptedString.of("Speed"), 0.2, 2.5, 1.1, 0.05)
            .setDescription(EncryptedString.of("Target glide speed"));
    private final number vertical = new number(EncryptedString.of("Vertical"), 0.0, 1.5, 0.35, 0.05)
            .setDescription(EncryptedString.of("Up/down control strength"));
    private final bool control = new bool(EncryptedString.of("Control"), true)
            .setDescription(EncryptedString.of("WASD redirects velocity while gliding"));
    private final bool softCap = new bool(EncryptedString.of("Soft Cap"), true)
            .setDescription(EncryptedString.of("Clamp horizontal speed near vanilla to reduce ElytraSpeed flags"));
    private final bool lookBoost = new bool(EncryptedString.of("Look Boost"), false)
            .setDescription(EncryptedString.of("GCD-smoothed pitch toward flight vector"));

    private final double[] gcdRemainder = {0.0, 0.0};
    private static final double MAX_H = 1.78;
    private static final double MIN_DELTA = 0.015;

    public ElytraFly() {
        super(EncryptedString.of("Elytra Fly"),
                EncryptedString.of("Controlled elytra flight with soft speed caps"),
                -1,
                Category.SWORD);
        addSettings(speed, vertical, control, softCap, lookBoost);
    }

    @Override
    public void onEnable() {
        eventManager.add(TickListener.class, this);
        super.onEnable();
    }

    @Override
    public void onDisable() {
        eventManager.remove(TickListener.class, this);
        super.onDisable();
    }

    @Override
    public void onTick() {
        if (mc.player == null || mc.world == null || mc.currentScreen != null)
            return;
        if (!mc.player.isGliding())
            return;
        if (AntibanbyDaduncs.isActionSent())
            return;

        Vec3d vel = mc.player.getVelocity();
        double target = speed.getValue();

        if (control.getValue() && mc.player.input != null) {
            float yaw = mc.player.getYaw() * 0.017453292f;
            // movement input: forward/back strafe on 1.21
            float forward = 0f;
            float strafe = 0f;
            try {
                var mi = mc.player.input.getMovementInput();
                forward = mi.y;
                strafe = mi.x;
            } catch (Throwable ignored) {
                // fallback older fields if mapping differs
            }

            if (Math.abs(forward) > 0.01f || Math.abs(strafe) > 0.01f) {
                double sin = MathHelper.sin(yaw);
                double cos = MathHelper.cos(yaw);
                double mx = strafe * cos - forward * sin;
                double mz = forward * cos + strafe * sin;
                double len = Math.sqrt(mx * mx + mz * mz);
                if (len > 1e-4) {
                    mx = mx / len * target;
                    mz = mz / len * target;
                    vel = new Vec3d(
                            vel.x + (mx - vel.x) * 0.35,
                            vel.y,
                            vel.z + (mz - vel.z) * 0.35);
                }
            }
        } else {
            // accelerate along look
            float yaw = mc.player.getYaw() * 0.017453292f;
            float pitch = mc.player.getPitch() * 0.017453292f;
            double lx = -MathHelper.sin(yaw) * MathHelper.cos(pitch);
            double ly = -MathHelper.sin(pitch);
            double lz = MathHelper.cos(yaw) * MathHelper.cos(pitch);
            Vec3d look = new Vec3d(lx, ly, lz).normalize().multiply(target);
            vel = vel.add(look.subtract(vel).multiply(0.28));
        }

        // vertical keys
        boolean jump = mc.options.jumpKey.isPressed();
        boolean sneak = mc.options.sneakKey.isPressed();
        double vy = vel.y;
        if (jump) vy += vertical.getValue() * 0.2;
        if (sneak) vy -= vertical.getValue() * 0.2;
        vy = MathHelper.clamp(vy, -1.6, 1.6);
        vel = new Vec3d(vel.x, vy, vel.z);

        if (softCap.getValue()) {
            double h = Math.sqrt(vel.x * vel.x + vel.z * vel.z);
            if (h > MAX_H) {
                double s = MAX_H / h;
                vel = new Vec3d(vel.x * s, vel.y, vel.z * s);
            }
        }

        if (vel.distanceTo(mc.player.getVelocity()) > MIN_DELTA) {
            mc.player.setVelocity(vel);
        }

        if (lookBoost.getValue() && vel.lengthSquared() > 0.01) {
            Rotation raw = RotationUtils.getDirection(mc.player.getEyePos(), mc.player.getEyePos().add(vel));
            Rotation q = RotationUtils.applyGCD(
                    mc.player.getYaw(), mc.player.getPitch(),
                    (float) raw.yaw(), (float) raw.pitch(),
                    gcdRemainder, true);
            mc.player.setYaw((float) q.yaw());
            mc.player.setPitch((float) q.pitch());
        }
    }
}
