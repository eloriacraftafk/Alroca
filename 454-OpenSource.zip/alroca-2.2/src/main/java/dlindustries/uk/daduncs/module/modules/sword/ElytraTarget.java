/*
 * Patch: ElytraTarget — proper orbit circle + lead + bypass
 * - Persistent phase angle so the path is a real circle, not a radial snap
 * - Predicts target motion and can overtake in front of flight direction
 * - Vanilla horizontal speed cap + min-delta velocity write + GCD look
 * - Antiban action-sent guard
 */

package dlindustries.uk.daduncs.module.modules.sword;

import dlindustries.uk.daduncs.Alroca;
import dlindustries.uk.daduncs.event.events.TickListener;
import dlindustries.uk.daduncs.managers.AntibanbyDaduncs;
import dlindustries.uk.daduncs.module.Category;
import dlindustries.uk.daduncs.module.Module;
import dlindustries.uk.daduncs.module.setting.bool;
import dlindustries.uk.daduncs.module.setting.number;
import dlindustries.uk.daduncs.utils.EncryptedString;
import dlindustries.uk.daduncs.utils.RotationUtils;
import dlindustries.uk.daduncs.utils.rotation.Rotation;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

public final class ElytraTarget extends Module implements TickListener {

    private final number range = new number(EncryptedString.of("Range"), 5, 80, 40, 1)
            .setDescription(EncryptedString.of("Max distance to pick a target"));
    private final number radius = new number(EncryptedString.of("Radius"), 2, 16, 5, 0.5)
            .setDescription(EncryptedString.of("Orbit radius around the target"));
    private final number height = new number(EncryptedString.of("Height"), -4, 8, 1.5, 0.25)
            .setDescription(EncryptedString.of("Height offset relative to target"));
    private final number speed = new number(EncryptedString.of("Speed"), 0.2, 2.5, 0.85, 0.05)
            .setDescription(EncryptedString.of("Angular speed around the circle (rad/tick scale)"));
    private final bool clockwise = new bool(EncryptedString.of("Clockwise"), true)
            .setDescription(EncryptedString.of("Orbit direction"));
    private final bool overtake = new bool(EncryptedString.of("Overtake"), true)
            .setDescription(EncryptedString.of("Lead the target — fly in front of their motion"));
    private final number overtakeDistance = new number(EncryptedString.of("Overtake Distance"), 1, 24, 8, 0.5)
            .setDescription(EncryptedString.of("How far ahead of motion vector to place orbit center"))
            .setVisibility(overtake::getValue);
    private final bool follow = new bool(EncryptedString.of("Follow"), true)
            .setDescription(EncryptedString.of("Chase when outside orbit capture range"));
    private final number captureMult = new number(EncryptedString.of("Capture Mult"), 1.5, 6, 2.5, 0.1)
            .setDescription(EncryptedString.of("flat > radius * this → switch to chase"))
            .setVisibility(follow::getValue);
    private final bool lookAtTarget = new bool(EncryptedString.of("Look At Target"), true)
            .setDescription(EncryptedString.of("GCD-smoothed look toward target / flight vector"));
    private final bool friendSafe = new bool(EncryptedString.of("Friend Safe"), true)
            .setDescription(EncryptedString.of("Never targets your friends"));

    private PlayerEntity lastTarget;
    private Vec3d lastTargetPos;
    private Vec3d targetMotion = Vec3d.ZERO;
    private double phase; // radians, continuous orbit angle

    private final double[] gcdRemainder = {0.0, 0.0};

    private static final double MAX_HORIZONTAL_SPEED = 1.78;
    private static final double MIN_VELOCITY_DELTA = 0.015;

    public ElytraTarget() {
        super(EncryptedString.of("Elytra Target"),
                EncryptedString.of("Orbits the nearest player in a clean circle while gliding, can overtake and chase"),
                -1,
                Category.SWORD);
        addSettings(range, radius, height, speed, clockwise, overtake, overtakeDistance,
                follow, captureMult, lookAtTarget, friendSafe);
    }

    @Override
    public void onEnable() {
        eventManager.add(TickListener.class, this);
        lastTarget = null;
        lastTargetPos = null;
        targetMotion = Vec3d.ZERO;
        phase = Double.NaN;
        super.onEnable();
    }

    @Override
    public void onDisable() {
        eventManager.remove(TickListener.class, this);
        super.onDisable();
    }

    private PlayerEntity findTarget() {
        PlayerEntity best = null;
        double bestDistance = range.getValue();

        for (PlayerEntity player : mc.world.getPlayers()) {
            if (player == mc.player || !player.isAlive() || player.isSpectator())
                continue;
            if (friendSafe.getValue() && Alroca.INSTANCE.getFriendManager().isFriend(player))
                continue;

            double distance = mc.player.distanceTo(player);
            if (distance <= bestDistance) {
                bestDistance = distance;
                best = player;
            }
        }
        return best;
    }

    private Vec3d entityPos(PlayerEntity p) {
        // yarn 1.21.x entity pos
        return p.getEntityPos();
    }

    @Override
    public void onTick() {
        if (mc.player == null || mc.world == null || mc.currentScreen != null)
            return;
        if (!mc.player.isGliding())
            return;
        if (AntibanbyDaduncs.isActionSent())
            return;

        PlayerEntity target = findTarget();
        if (target == null)
            return;

        Vec3d me = entityPos(mc.player);
        Vec3d tp = entityPos(target);

        if (target != lastTarget || lastTargetPos == null) {
            lastTarget = target;
            targetMotion = Vec3d.ZERO;
            // seed phase from current relative angle so we don't snap
            double sdx = me.x - tp.x;
            double sdz = me.z - tp.z;
            phase = Math.atan2(sdz, sdx);
        } else {
            Vec3d sample = tp.subtract(lastTargetPos);
            targetMotion = targetMotion.multiply(0.55).add(sample.multiply(0.45));
        }
        lastTargetPos = tp;

        // orbit center: target + optional lead along flat motion
        Vec3d center = tp;
        if (overtake.getValue()) {
            Vec3d flat = new Vec3d(targetMotion.x, 0, targetMotion.z);
            if (flat.lengthSquared() > 0.0004) {
                center = center.add(flat.normalize().multiply(overtakeDistance.getValue()));
            }
        }
        // slight prediction on center itself
        center = center.add(targetMotion.multiply(0.35));

        double r = radius.getValue();
        double v = speed.getValue();
        double dir = clockwise.getValue() ? 1.0 : -1.0;

        double dx = me.x - center.x;
        double dz = me.z - center.z;
        double flat = Math.sqrt(dx * dx + dz * dz);

        Vec3d next;

        if (follow.getValue() && flat > r * captureMult.getValue()) {
            // chase into orbit radius
            Vec3d desired = new Vec3d(
                    center.x - me.x,
                    center.y + height.getValue() - me.y,
                    center.z - me.z);
            double len = desired.length();
            if (len > 1e-4) {
                double step = Math.min(v * 1.4, len);
                next = me.add(desired.normalize().multiply(step));
            } else {
                next = me;
            }
            // keep phase coherent for when we re-enter orbit
            phase = Math.atan2(me.z - center.z, me.x - center.x);
        } else {
            // true circle: advance phase by angular step = tangential speed / radius
            double angular = (v / Math.max(r, 0.5)) * dir;
            phase += angular;

            // soft radius pull so we settle on r without radial oscillation flags
            double nextRadius = flat + MathHelper.clamp(r - flat, -0.85, 0.85);
            nextRadius = MathHelper.clamp(nextRadius, r * 0.55, r * 1.35);

            double nextY = me.y + MathHelper.clamp(
                    (center.y + height.getValue()) - me.y, -0.55, 0.55);

            next = new Vec3d(
                    center.x + Math.cos(phase) * nextRadius,
                    nextY,
                    center.z + Math.sin(phase) * nextRadius);
        }

        Vec3d move = next.subtract(me);

        if (move.length() > 2.85)
            move = move.normalize().multiply(2.85);

        double hLen = Math.sqrt(move.x * move.x + move.z * move.z);
        if (hLen > MAX_HORIZONTAL_SPEED) {
            double scale = MAX_HORIZONTAL_SPEED / hLen;
            move = new Vec3d(move.x * scale, move.y, move.z * scale);
        }

        Vec3d currentVelocity = mc.player.getVelocity();
        if (move.distanceTo(currentVelocity) > MIN_VELOCITY_DELTA) {
            mc.player.setVelocity(move);
        }

        if (lookAtTarget.getValue()) {
            // look slightly ahead on the flight vector, not pure target — smoother, less AimPattern
            Vec3d lookPoint = center.add(0, height.getValue() * 0.35, 0);
            if (move.lengthSquared() > 0.01) {
                lookPoint = me.add(move.normalize().multiply(6.0));
            }
            Rotation raw = RotationUtils.getDirection(mc.player.getEyePos(), lookPoint);
            Rotation quantized = RotationUtils.applyGCD(
                    mc.player.getYaw(), mc.player.getPitch(),
                    (float) raw.yaw(), (float) raw.pitch(),
                    gcdRemainder, true);
            mc.player.setYaw((float) quantized.yaw());
            mc.player.setPitch((float) quantized.pitch());
        }
    }
}
