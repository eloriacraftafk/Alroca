/*
 * This file is part of System Client (https://github.com/daduncs/system)
 * Website: https://download.daduncs.cloud/
 *
 * Copyright (c) 2024 - 2026 DLindustries and project contributors.
 *
 * System Client is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * System Client is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with System Client. If not, see <https://www.gnu.org/licenses/>.
 */

package dlindustries.uk.daduncs.module.modules.render;

import dlindustries.uk.daduncs.event.events.GameRenderListener;
import dlindustries.uk.daduncs.module.Category;
import dlindustries.uk.daduncs.module.Module;
import dlindustries.uk.daduncs.module.setting.colour;
import dlindustries.uk.daduncs.module.setting.number;
import dlindustries.uk.daduncs.utils.EncryptedString;
import dlindustries.uk.daduncs.utils.RenderUtils;
import net.minecraft.client.render.Camera;
import net.minecraft.client.render.RenderLayers;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.math.RotationAxis;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;

import java.awt.Color;

public final class TargetCrystal extends Module implements GameRenderListener {

	private static final int SIDES = 6;
	private static final int RING_SEGMENTS = 40;

	private final number size = new number(EncryptedString.of("Boyut"), 0.2, 1.5, 0.6, 0.05)
			.setDescription(EncryptedString.of("Kristal boyutu"));
	private final number height = new number(EncryptedString.of("Yükseklik"), 0, 2, 0.5, 0.1)
			.setDescription(EncryptedString.of("Oyuncunun kafasından yükseklik"));
	private final number spin = new number(EncryptedString.of("Dönüş Hızı"), 0, 10, 3, 0.5)
			.setDescription(EncryptedString.of("Kristal ve halkaların dönüş hızı"));
	private final number ringSize = new number(EncryptedString.of("Halka Boyutu"), 0.5, 2.5, 1.0, 0.05)
			.setDescription(EncryptedString.of("Ayak altındaki halkaların boyutu"));
	private final colour color = new colour(EncryptedString.of("Kristal Rengi"), 0xFF6C7BFF);
	private final colour ringColor = new colour(EncryptedString.of("Halka Rengi"), 0xFF8E6BFF);

	public TargetCrystal() {
		super(EncryptedString.of("Target Crystal"),
				EncryptedString.of("Baktığın oyuncunun kafasında kristal, ayağının altında 2 halka gösterir"),
				-1,
				Category.RENDER);
		addSettings(size, height, spin, ringSize, color, ringColor);
	}

	@Override
	public void onEnable() {
		eventManager.add(GameRenderListener.class, this);
		super.onEnable();
	}

	@Override
	public void onDisable() {
		eventManager.remove(GameRenderListener.class, this);
		super.onDisable();
	}

	@Override
	public void onGameRender(GameRenderEvent event) {
		if (mc.world == null || mc.player == null)
			return;

		if (!(mc.crosshairTarget instanceof EntityHitResult hit) || !(hit.getEntity() instanceof PlayerEntity target))
			return;

		Camera camera = mc.gameRenderer.getCamera();

		if (camera == null)
			return;

		event.matrices.push();
		Vec3d cameraPos = camera.getCameraPos();
		event.matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(camera.getPitch()));
		event.matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(camera.getYaw() + 180.0F));
		event.matrices.translate(-cameraPos.x, -cameraPos.y, -cameraPos.z);

		Vec3d pos = target.getLerpedPos(RenderUtils.tickProgress());
		double time = (System.currentTimeMillis() % 100000L) / 1000.0;

		final float cx = (float) pos.x;
		final float cy = (float) (pos.y + target.getHeight() + height.getValue() + 0.08 * Math.sin(time * 2.0));
		final float cz = (float) pos.z;
		final float halfHeight = size.getValueFloat() / 2f;
		final float radius = size.getValueFloat() * 0.3f;
		final double spinAngle = time * spin.getValue();

		Color base = new Color(color.getValue(), true);
		final float r = base.getRed() / 255f;
		final float g = base.getGreen() / 255f;
		final float b = base.getBlue() / 255f;
		// alt yarı pembeye kayar (fotodaki gibi)
		final float br = r + (1.0f - r) * 0.35f;
		final float bg = g + (0.45f - g) * 0.35f;
		final float bb = b + (0.75f - b) * 0.35f;
		final Matrix4f matrix = event.matrices.peek().getPositionMatrix();

		RenderUtils.drawLayer(RenderLayers.debugFilledBox(), buffer -> {
			for (int i = 0; i < SIDES; i++) {
				double a1 = spinAngle + i * (Math.PI * 2 / SIDES);
				double a2 = spinAngle + (i + 1) * (Math.PI * 2 / SIDES);
				float x1 = cx + (float) Math.cos(a1) * radius;
				float z1 = cz + (float) Math.sin(a1) * radius;
				float x2 = cx + (float) Math.cos(a2) * radius;
				float z2 = cz + (float) Math.sin(a2) * radius;

				double faceAngle = (a1 + a2) / 2.0;
				float light = (float) (0.65 + 0.35 * Math.cos(faceAngle - 0.8));

				float topLight = Math.min(1f, light * 1.1f);
				buffer.vertex(matrix, cx, cy + halfHeight, cz).color(r * topLight, g * topLight, b * topLight, 0.92f);
				buffer.vertex(matrix, x1, cy, z1).color(r * topLight, g * topLight, b * topLight, 0.92f);
				buffer.vertex(matrix, x2, cy, z2).color(r * topLight, g * topLight, b * topLight, 0.92f);
				buffer.vertex(matrix, x2, cy, z2).color(r * topLight, g * topLight, b * topLight, 0.92f);

				float bottomLight = light * 0.7f;
				buffer.vertex(matrix, cx, cy - halfHeight, cz).color(br * bottomLight, bg * bottomLight, bb * bottomLight, 0.92f);
				buffer.vertex(matrix, x2, cy, z2).color(br * bottomLight, bg * bottomLight, bb * bottomLight, 0.92f);
				buffer.vertex(matrix, x1, cy, z1).color(br * bottomLight, bg * bottomLight, bb * bottomLight, 0.92f);
				buffer.vertex(matrix, x1, cy, z1).color(br * bottomLight, bg * bottomLight, bb * bottomLight, 0.92f);
			}
		});

		// ayak altındaki 2 halka
		Color rc = new Color(ringColor.getValue(), true);
		final float rr = rc.getRed() / 255f;
		final float rg = rc.getGreen() / 255f;
		final float rb = rc.getBlue() / 255f;
		final float baseRadius = Math.max(0.6f, target.getWidth() * 1.1f) * ringSize.getValueFloat();
		final float feetY = (float) pos.y + 0.05f;
		final float tilt = (float) Math.toRadians(16.0);

		RenderUtils.drawLayer(RenderLayers.debugFilledBox(), buffer -> {
			for (int ring = 0; ring < 2; ring++) {
				float ringRadius = baseRadius * (ring == 0 ? 1.0f : 0.72f);
				float half = 0.045f;
				double phase = spinAngle * (ring == 0 ? 0.6 : -0.8) + ring * 1.7;
				float shade = ring == 0 ? 1.0f : 0.85f;

				for (int i = 0; i < RING_SEGMENTS; i++) {
					double t1 = i * (Math.PI * 2 / RING_SEGMENTS);
					double t2 = (i + 1) * (Math.PI * 2 / RING_SEGMENTS);
					float o = ringRadius + half;
					float n = ringRadius - half;

					float ox1 = cx + (float) Math.cos(t1) * o, oz1 = cz + (float) Math.sin(t1) * o;
					float ox2 = cx + (float) Math.cos(t2) * o, oz2 = cz + (float) Math.sin(t2) * o;
					float ix1 = cx + (float) Math.cos(t1) * n, iz1 = cz + (float) Math.sin(t1) * n;
					float ix2 = cx + (float) Math.cos(t2) * n, iz2 = cz + (float) Math.sin(t2) * n;

					float y1 = feetY + (float) (Math.sin(t1 - phase) * Math.sin(tilt) * ringRadius);
					float y2 = feetY + (float) (Math.sin(t2 - phase) * Math.sin(tilt) * ringRadius);

					float glow = (float) (0.65 + 0.35 * Math.cos(t1 - phase));
					float cr = rr * glow * shade, cg = rg * glow * shade, cb = rb * glow * shade;

					buffer.vertex(matrix, ox1, y1, oz1).color(cr, cg, cb, 0.85f);
					buffer.vertex(matrix, ox2, y2, oz2).color(cr, cg, cb, 0.85f);
					buffer.vertex(matrix, ix2, y2, iz2).color(cr, cg, cb, 0.25f);
					buffer.vertex(matrix, ix1, y1, iz1).color(cr, cg, cb, 0.25f);
				}
			}
		});

		event.matrices.pop();
	}
}
