/*
 * Patch: FakeLag — outbound movement choke
 * - Queues PlayerMoveC2SPacket (and optional interact) for a randomized window
 * - Flushes on release / choke end / combat pulse
 * - Pulse mode: short choke bursts instead of continuous hold (harder pattern)
 * - Never holds KeepAlive / transaction — avoids timeout & PingSpoof clash
 */

package dlindustries.uk.daduncs.module.modules.misc;

import dlindustries.uk.daduncs.event.events.PacketSendListener;
import dlindustries.uk.daduncs.event.events.TickListener;
import dlindustries.uk.daduncs.module.Category;
import dlindustries.uk.daduncs.module.Module;
import dlindustries.uk.daduncs.module.setting.bool;
import dlindustries.uk.daduncs.module.setting.number;
import dlindustries.uk.daduncs.utils.EncryptedString;
import net.minecraft.network.packet.Packet;
import net.minecraft.network.packet.c2s.play.PlayerInteractEntityC2SPacket;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;

import java.util.ArrayDeque;
import java.util.concurrent.ThreadLocalRandom;

public final class FakeLag extends Module implements PacketSendListener, TickListener {

    private final number minChoke = new number(EncryptedString.of("Min Choke"), 1, 40, 4, 1)
            .setDescription(EncryptedString.of("Minimum ticks to hold packets"));
    private final number maxChoke = new number(EncryptedString.of("Max Choke"), 2, 60, 12, 1)
            .setDescription(EncryptedString.of("Maximum ticks to hold packets"));
    private final number releaseGap = new number(EncryptedString.of("Release Gap"), 1, 30, 6, 1)
            .setDescription(EncryptedString.of("Ticks of free send between choke windows"));
    private final bool pulse = new bool(EncryptedString.of("Pulse"), true)
            .setDescription(EncryptedString.of("Alternating choke/release windows (safer)"));
    private final bool holdAttacks = new bool(EncryptedString.of("Hold Attacks"), false)
            .setDescription(EncryptedString.of("Also queue PlayerInteractEntity during choke"));
    private final bool flushOnHurt = new bool(EncryptedString.of("Flush On Hurt"), true)
            .setDescription(EncryptedString.of("Release queue immediately when you take damage"));
    private final number maxQueue = new number(EncryptedString.of("Max Queue"), 4, 64, 24, 1)
            .setDescription(EncryptedString.of("Hard cap on buffered packets"));

    private final ArrayDeque<Packet<?>> queue = new ArrayDeque<>();
    private int chokeLeft;
    private int gapLeft;
    private boolean choking;
    private int lastHurtTime;

    public FakeLag() {
        super(EncryptedString.of("Fake Lag"),
                EncryptedString.of("Chokes outbound movement packets in short randomized bursts"),
                -1,
                Category.MISC);
        addSettings(minChoke, maxChoke, releaseGap, pulse, holdAttacks, flushOnHurt, maxQueue);
    }

    @Override
    public void onEnable() {
        eventManager.add(PacketSendListener.class, this);
        eventManager.add(TickListener.class, this);
        queue.clear();
        chokeLeft = 0;
        gapLeft = 0;
        choking = false;
        lastHurtTime = 0;
        startWindow();
        super.onEnable();
    }

    @Override
    public void onDisable() {
        flush();
        eventManager.remove(PacketSendListener.class, this);
        eventManager.remove(TickListener.class, this);
        super.onDisable();
    }

    private void startWindow() {
        int min = Math.min(minChoke.getValueInt(), maxChoke.getValueInt());
        int max = Math.max(minChoke.getValueInt(), maxChoke.getValueInt());
        chokeLeft = min + ThreadLocalRandom.current().nextInt(Math.max(1, max - min + 1));
        gapLeft = Math.max(1, releaseGap.getValueInt()
                + ThreadLocalRandom.current().nextInt(3) - 1);
        choking = true;
    }

    private void flush() {
        if (mc.getNetworkHandler() == null) {
            queue.clear();
            return;
        }
        while (!queue.isEmpty()) {
            Packet<?> p = queue.pollFirst();
            try {
                mc.getNetworkHandler().getConnection().send(p);
            } catch (Exception ignored) {
            }
        }
    }

    @Override
    public void onTick() {
        if (mc.player == null) return;

        if (flushOnHurt.getValue()) {
            int ht = mc.player.hurtTime;
            if (ht > lastHurtTime && ht >= 8) {
                flush();
                choking = false;
                gapLeft = Math.max(2, releaseGap.getValueInt());
            }
            lastHurtTime = ht;
        }

        if (choking) {
            if (--chokeLeft <= 0) {
                flush();
                choking = false;
                gapLeft = Math.max(1, releaseGap.getValueInt());
            }
        } else {
            if (--gapLeft <= 0) {
                if (pulse.getValue() || true) {
                    startWindow();
                }
            }
        }
    }

    @Override
    public void onPacketSend(PacketSendEvent event) {
        Packet<?> packet = event.packet;

        // never touch keepalive / login / config
        if (!(packet instanceof PlayerMoveC2SPacket)
                && !(holdAttacks.getValue() && packet instanceof PlayerInteractEntityC2SPacket)) {
            return;
        }

        if (!choking) return;

        if (queue.size() >= maxQueue.getValueInt()) {
            // force flush oldest to avoid unbounded memory + rubberband hell
            flush();
            return;
        }

        queue.addLast(packet);
        event.cancel();
    }
}
