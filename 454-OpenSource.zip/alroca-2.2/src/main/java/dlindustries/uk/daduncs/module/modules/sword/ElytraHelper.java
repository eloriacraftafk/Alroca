/*
 * Patch: ElytraHelper — inventory firework ban fix
 * Problem: SWAP+USE same tick (even with deferred restore) flags
 *          InventoryMove / MultiAction on Kont-style NCP configs.
 * Fix:
 *   1. Mainhand / offhand rocket → interact only, zero inventory packets
 *   2. Hotbar rocket → selected-slot switch, USE next tick, restore next tick
 *   3. Back-inventory rocket → 3-tick machine: SWAP → USE → SWAP restore
 * Never two inventory mutations in the same tick.
 */

package dlindustries.uk.daduncs.module.modules.sword;

import dlindustries.uk.daduncs.Alroca;
import dlindustries.uk.daduncs.event.events.TickListener;
import dlindustries.uk.daduncs.managers.AntibanbyDaduncs;
import dlindustries.uk.daduncs.module.Category;
import dlindustries.uk.daduncs.module.Module;
import dlindustries.uk.daduncs.module.setting.bind;
import dlindustries.uk.daduncs.module.setting.bool;
import dlindustries.uk.daduncs.module.setting.number;
import dlindustries.uk.daduncs.utils.EncryptedString;
import dlindustries.uk.daduncs.utils.InventoryUtils;
import dlindustries.uk.daduncs.utils.KeyUtils;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Items;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.util.Hand;

public final class ElytraHelper extends Module implements TickListener {

    private final bind fireworkKey = new bind(EncryptedString.of("Firework Key"), -1, false)
            .setDescription(EncryptedString.of("Press this key to use a firework from inventory"));

    private final bool onlyWhileGliding = new bool(EncryptedString.of("Only While Gliding"), true)
            .setDescription(EncryptedString.of("Only fire while elytra-gliding"));

    private final bool holdToRepeat = new bool(EncryptedString.of("Hold To Repeat"), true)
            .setDescription(EncryptedString.of("Keep boosting while the key is held"));

    private final number repeatDelay = new number(EncryptedString.of("Repeat Delay"), 2, 40, 10, 1)
            .setDescription(EncryptedString.of("Ticks between rockets when holding (min 2)"));

    private final bool autoNearTarget = new bool(EncryptedString.of("Auto Near Target"), true)
            .setDescription(EncryptedString.of("Auto-boost when an enemy is within Auto Range while gliding"));

    private final number autoRange = new number(EncryptedString.of("Auto Range"), 4, 48, 18, 1)
            .setDescription(EncryptedString.of("Distance for Auto Near Target"))
            .setVisibility(autoNearTarget::getValue);

    private final number autoDelay = new number(EncryptedString.of("Auto Delay"), 4, 40, 14, 1)
            .setDescription(EncryptedString.of("Ticks between auto rockets"))
            .setVisibility(autoNearTarget::getValue);

    private final bool friendSafe = new bool(EncryptedString.of("Friend Safe"), true)
            .setDescription(EncryptedString.of("Ignore friends for auto boost"));

    private final number stepGap = new number(EncryptedString.of("Step Gap"), 1, 4, 1, 1)
            .setDescription(EncryptedString.of("Idle ticks between SWAP / USE / restore steps"));

    private enum Phase {
        IDLE,
        HOTBAR_WAIT_USE,
        HOTBAR_WAIT_RESTORE,
        INV_WAIT_USE,
        INV_WAIT_RESTORE
    }

    private Phase phase = Phase.IDLE;
    private int phaseTicks;
    private int originalHotbar = -1;
    private int rocketHotbar = -1;
    private int invSlotId = -1;
    private int invTargetHotbar = -1;

    private boolean wasPressed;
    private int cooldown;
    private int autoCooldown;

    public ElytraHelper() {
        super(EncryptedString.of("Elytra Helper"),
                EncryptedString.of("Uses inventory fireworks without same-tick swap/use — hotbar preferred, 3-tick inv path"),
                -1,
                Category.SWORD);
        addSettings(fireworkKey, onlyWhileGliding, holdToRepeat, repeatDelay,
                autoNearTarget, autoRange, autoDelay, friendSafe, stepGap);
    }

    @Override
    public void onEnable() {
        eventManager.add(TickListener.class, this);
        resetPhase();
        wasPressed = false;
        cooldown = 0;
        autoCooldown = 0;
        super.onEnable();
    }

    @Override
    public void onDisable() {
        eventManager.remove(TickListener.class, this);
        if (mc.player != null && originalHotbar >= 0 && phase != Phase.IDLE) {
            InventoryUtils.setInvSlot(originalHotbar);
        }
        resetPhase();
        wasPressed = false;
        cooldown = 0;
        autoCooldown = 0;
        super.onDisable();
    }

    private void resetPhase() {
        phase = Phase.IDLE;
        phaseTicks = 0;
        originalHotbar = -1;
        rocketHotbar = -1;
        invSlotId = -1;
        invTargetHotbar = -1;
    }

    private boolean enemyInRange(double r) {
        if (mc.world == null || mc.player == null) return false;
        for (PlayerEntity p : mc.world.getPlayers()) {
            if (p == mc.player || !p.isAlive() || p.isSpectator()) continue;
            if (friendSafe.getValue() && Alroca.INSTANCE.getFriendManager().isFriend(p)) continue;
            if (mc.player.distanceTo(p) <= r) return true;
        }
        return false;
    }

    private boolean canStart() {
        if (phase != Phase.IDLE) return false;
        if (mc.player == null || mc.interactionManager == null) return false;
        if (onlyWhileGliding.getValue() && !mc.player.isGliding()) return false;
        if (AntibanbyDaduncs.isActionSent() || AntibanbyDaduncs.isSlotPending()) return false;
        return true;
    }

    @Override
    public void onTick() {
        if (mc.player == null || mc.world == null || mc.interactionManager == null) {
            wasPressed = false;
            resetPhase();
            return;
        }
        if (mc.currentScreen != null) {
            wasPressed = false;
            if (phase == Phase.IDLE) return;
        }

        if (phase != Phase.IDLE) {
            tickPhase();
            return;
        }

        if (cooldown > 0) cooldown--;
        if (autoCooldown > 0) autoCooldown--;

        int key = fireworkKey.getKey();
        boolean pressed = key != -1 && KeyUtils.isKeyPressed(key);

        if (pressed && !wasPressed && canStart()) {
            if (beginUse()) {
                cooldown = Math.max(2, repeatDelay.getValueInt());
            }
        } else if (pressed && holdToRepeat.getValue() && cooldown <= 0 && canStart()) {
            if (beginUse()) {
                cooldown = Math.max(2, repeatDelay.getValueInt());
            }
        }

        if (autoNearTarget.getValue()
                && autoCooldown <= 0
                && canStart()
                && mc.player.isGliding()
                && enemyInRange(autoRange.getValue())) {
            if (beginUse()) {
                autoCooldown = Math.max(2, autoDelay.getValueInt());
            }
        }

        wasPressed = pressed;
    }

    private void tickPhase() {
        if (phaseTicks > 0) {
            phaseTicks--;
            return;
        }

        ClientPlayerEntity player = mc.player;
        if (player == null || mc.interactionManager == null) {
            resetPhase();
            return;
        }

        if (AntibanbyDaduncs.isActionSent() || AntibanbyDaduncs.isSlotPending()) {
            phaseTicks = 1;
            return;
        }

        int gap = Math.max(1, stepGap.getValueInt());

        switch (phase) {
            case HOTBAR_WAIT_USE -> {
                mc.interactionManager.interactItem(player, Hand.MAIN_HAND);
                phase = Phase.HOTBAR_WAIT_RESTORE;
                phaseTicks = gap;
            }
            case HOTBAR_WAIT_RESTORE -> {
                if (originalHotbar >= 0 && originalHotbar <= 8) {
                    InventoryUtils.setInvSlot(originalHotbar);
                }
                resetPhase();
            }
            case INV_WAIT_USE -> {
                mc.interactionManager.interactItem(player, Hand.MAIN_HAND);
                phase = Phase.INV_WAIT_RESTORE;
                phaseTicks = gap;
            }
            case INV_WAIT_RESTORE -> {
                if (invSlotId >= 0 && invTargetHotbar >= 0) {
                    int syncId = player.playerScreenHandler.syncId;
                    mc.interactionManager.clickSlot(syncId, invSlotId, invTargetHotbar,
                            SlotActionType.SWAP, player);
                }
                resetPhase();
            }
            default -> resetPhase();
        }
    }

    /** @return true if a use sequence was started or completed immediately */
    private boolean beginUse() {
        ClientPlayerEntity player = mc.player;
        int selected = player.getInventory().getSelectedSlot();

        // 1) mainhand rocket — pure use
        if (player.getInventory().getStack(selected).isOf(Items.FIREWORK_ROCKET)) {
            mc.interactionManager.interactItem(player, Hand.MAIN_HAND);
            return true;
        }

        // 2) offhand rocket — pure use
        if (player.getOffHandStack().isOf(Items.FIREWORK_ROCKET)) {
            mc.interactionManager.interactItem(player, Hand.OFF_HAND);
            return true;
        }

        // 3) hotbar rocket — slot switch / use / restore (no clickSlot)
        for (int i = 0; i < 9; i++) {
            if (i == selected) continue;
            if (!player.getInventory().getStack(i).isOf(Items.FIREWORK_ROCKET)) continue;

            originalHotbar = selected;
            rocketHotbar = i;
            InventoryUtils.setInvSlot(i);
            phase = Phase.HOTBAR_WAIT_USE;
            phaseTicks = Math.max(1, stepGap.getValueInt());
            return true;
        }

        // 4) back-inventory — 3-tick SWAP path
        int from = -1;
        for (int i = 9; i < 36; i++) {
            if (player.getInventory().getStack(i).isOf(Items.FIREWORK_ROCKET)) {
                from = i;
                break;
            }
        }
        if (from == -1) return false;

        invSlotId = from;
        invTargetHotbar = selected;
        originalHotbar = selected;

        int syncId = player.playerScreenHandler.syncId;
        mc.interactionManager.clickSlot(syncId, invSlotId, invTargetHotbar, SlotActionType.SWAP, player);
        phase = Phase.INV_WAIT_USE;
        phaseTicks = Math.max(1, stepGap.getValueInt());
        return true;
    }
}
