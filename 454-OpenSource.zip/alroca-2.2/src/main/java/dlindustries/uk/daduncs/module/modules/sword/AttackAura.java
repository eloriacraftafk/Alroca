/*
 * Patch: AttackAura — rotatesiz default + silent + bypass hardening
 * - Rotate OFF by default (rotatesiz vur)
 * - Silent mode: GCD aim only when needed for raytrace, never holds client view
 * - Hit-timing jitter, hurtTime>=2, Antiban packet-order guard
 */

package dlindustries.uk.daduncs.module.modules.sword;

import dlindustries.uk.daduncs.Alroca;
import dlindustries.uk.daduncs.event.events.TickListener;
import dlindustries.uk.daduncs.managers.AntibanbyDaduncs;
import dlindustries.uk.daduncs.module.Category;
import dlindustries.uk.daduncs.module.Module;
import dlindustries.uk.daduncs.module.setting.bool;
import dlindustries.uk.daduncs.module.setting.number;
import dlindustries.uk.daduncs.utils.EncryptedString;
import dlindustries.uk.daduncs.utils.RotationUtils;
import dlindustries.uk.daduncs.utils.rotation.Rotation;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.Hand;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

import java.util.concurrent.ThreadLocalRandom;

public final class AttackAura extends Module implements TickListener {

    private final number range = new number(EncryptedString.of("Range"), 2, 6, 3.0, 0.1)
            .setDescription(EncryptedString.of("Distance to hit players from"));
    private final number cooldown = new number(EncryptedString.of("Cooldown"), 0.5, 1, 0.95, 0.05)
            .setDescription(EncryptedString.of("Attack strength needed before hitting"));
    // rotatesiz: default OFF
    private final bool rotate = new bool(EncryptedString.of("Rotate"), false)
            .setDescription(EncryptedString.of("Turns client view toward target (off = rotatesiz)"));
    private final bool silent = new bool(EncryptedString.of("Silent"), true)
            .setDescription(EncryptedString.of("When Rotate is on: snap only for the hit tick, restore view next tick"));
    private final bool throughWalls = new bool(EncryptedString.of("Through Walls"), false)
            .setDescription(EncryptedString.of("Also hits players you cannot see"));
    private final bool friendSafe = new bool(EncryptedString.of("Friend Safe"), true)
            .setDescription(EncryptedString.of("Never targets your friends"));
    private final bool onlyWeapon = new bool(EncryptedString.of("Only Weapon"), false)
            .setDescription(EncryptedString.of("Only attack while holding a weapon-class item"));

    private float jitteredThreshold = 0.95f;
    private int jitterRefreshCooldown = 0;
    private final double[] gcdRemainder = {0.0, 0.0};

    private float savedYaw, savedPitch;
    private boolean restoreView;

    public AttackAura() {
        super(EncryptedString.of("Attack Aura"),
                EncryptedString.of("Automatically hits the nearest player in range — rotatesiz by default"),
                -1,
                Category.SWORD);
        addSettings(range, cooldown, rotate, silent, throughWalls, friendSafe, onlyWeapon);
    }

    @Override
    public void onEnable() {
        eventManager.add(TickListener.class, this);
        jitteredThreshold = cooldown.getValueFloat();
        jitterRefreshCooldown = 0;
        restoreView = false;
        super.onEnable();
    }

    @Override
    public void onDisable() {
        eventManager.remove(TickListener.class, this);
        if (restoreView && mc.player != null) {
            mc.player.setYaw(savedYaw);
            mc.player.setPitch(savedPitch);
            restoreView = false;
        }
        super.onDisable();
    }

    private void refreshJitter() {
        float base = cooldown.getValueFloat();
        float variance = base * 0.05f;
        float delta = (float) (ThreadLocalRandom.current().nextDouble() * variance * 2 - variance);
        jitteredThreshold = MathHelper.clamp(base + delta, 0.5f, 1.0f);
        jitterRefreshCooldown = 4 + ThreadLocalRandom.current().nextInt(6);
    }

    private PlayerEntity findTarget() {
        PlayerEntity best = null;
        double reach = Math.min(range.getValue(), 3.0);
        if (mc.player.isGliding())
            reach -= 0.3;
        double bestDistance = reach;
        Vec3d eye = mc.player.getEyePos();

        for (PlayerEntity player : mc.world.getPlayers()) {
            if (player == mc.player || !player.isAlive() || player.isSpectator())
                continue;
            if (friendSafe.getValue() && Alroca.INSTANCE.getFriendManager().isFriend(player))
                continue;
            if (!throughWalls.getValue() && !mc.player.canSee(player))
                continue;
            if (player.hurtTime >= 2)
                continue;

            Box box = player.getBoundingBox();
            Vec3d closest = new Vec3d(
                    MathHelper.clamp(eye.x, box.minX, box.maxX),
                    MathHelper.clamp(eye.y, box.minY, box.maxY),
                    MathHelper.clamp(eye.z, box.minZ, box.maxZ));
            double distance = eye.distanceTo(closest);

            if (distance <= bestDistance) {
                bestDistance = distance;
                best = player;
            }
        }
        return best;
    }

    @Override
    public void onTick() {
        if (mc.player == null || mc.world == null || mc.interactionManager == null || mc.currentScreen != null)
            return;

        // silent restore — next tick after a rotated hit
        if (restoreView) {
            mc.player.setYaw(savedYaw);
            mc.player.setPitch(savedPitch);
            restoreView = false;
        }

        if (AntibanbyDaduncs.isAttackSent() || AntibanbyDaduncs.isActionSent())
            return;

        if (jitterRefreshCooldown <= 0) {
            refreshJitter();
        } else {
            jitterRefreshCooldown--;
        }

        if (mc.player.getAttackCooldownProgress(0.5f) < jitteredThreshold)
            return;

        if (onlyWeapon.getValue()) {
            var stack = mc.player.getMainHandStack();
            if (stack.isEmpty()) return;
            String path = stack.getItem().toString().toLowerCase();
            if (!(path.contains("sword") || path.contains("axe") || path.contains("mace")
                    || path.contains("trident") || path.contains("spear")))
                return;
        }

        PlayerEntity target = findTarget();
        if (target == null)
            return;

        if (rotate.getValue()) {
            Rotation raw = RotationUtils.getDirection(mc.player.getEyePos(), target.getBoundingBox().getCenter());
            Rotation quantized = RotationUtils.applyGCD(
                    mc.player.getYaw(), mc.player.getPitch(),
                    (float) raw.yaw(), (float) raw.pitch(),
                    gcdRemainder, true);

            float deltaYaw = Math.abs(MathHelper.wrapDegrees((float) quantized.yaw() - mc.player.getYaw()));
            float deltaPitch = Math.abs((float) quantized.pitch() - mc.player.getPitch());

            if (deltaYaw > 0.001f || deltaPitch > 0.001f) {
                if (silent.getValue()) {
                    savedYaw = mc.player.getYaw();
                    savedPitch = mc.player.getPitch();
                    restoreView = true;
                }
                mc.player.setYaw((float) quantized.yaw());
                mc.player.setPitch((float) quantized.pitch());
            }
        }

        mc.interactionManager.attackEntity(mc.player, target);
        mc.player.swingHand(Hand.MAIN_HAND);
    }
}
