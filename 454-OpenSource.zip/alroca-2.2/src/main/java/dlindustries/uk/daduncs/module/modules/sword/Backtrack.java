/*
 * Patch: Backtrack — position history hitbox
 * - Samples other players every tick into a ring buffer
 * - Expands the effective hit candidate to the delayed position
 * - Used by AttackAura via static lookup; also self-attacks delayed pos
 * - Randomized sample age + min/max ms windows to avoid flat lag patterns
 * - No packet cancel (clean client-side prediction surface)
 */

package dlindustries.uk.daduncs.module.modules.sword;

import dlindustries.uk.daduncs.Alroca;
import dlindustries.uk.daduncs.event.events.TickListener;
import dlindustries.uk.daduncs.managers.AntibanbyDaduncs;
import dlindustries.uk.daduncs.module.Category;
import dlindustries.uk.daduncs.module.Module;
import dlindustries.uk.daduncs.module.setting.bool;
import dlindustries.uk.daduncs.module.setting.number;
import dlindustries.uk.daduncs.utils.EncryptedString;
import dlindustries.uk.daduncs.utils.RotationUtils;
import dlindustries.uk.daduncs.utils.rotation.Rotation;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.Hand;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

import java.util.ArrayDeque;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ThreadLocalRandom;

public final class Backtrack extends Module implements TickListener {

    private final number minMs = new number(EncryptedString.of("Min MS"), 0, 400, 40, 5)
            .setDescription(EncryptedString.of("Minimum position age to attack"));
    private final number maxMs = new number(EncryptedString.of("Max MS"), 50, 600, 180, 5)
            .setDescription(EncryptedString.of("Maximum position age in the buffer"));
    private final number range = new number(EncryptedString.of("Range"), 2, 6, 3.2, 0.1)
            .setDescription(EncryptedString.of("Max reach against delayed positions"));
    private final number cooldown = new number(EncryptedString.of("Cooldown"), 0.5, 1, 0.92, 0.05)
            .setDescription(EncryptedString.of("Attack strength threshold"));
    private final bool rotate = new bool(EncryptedString.of("Rotate"), false)
            .setDescription(EncryptedString.of("Rotate toward delayed position (default off / rotatesiz)"));
    private final bool friendSafe = new bool(EncryptedString.of("Friend Safe"), true);
    private final bool onlyWhenHurt = new bool(EncryptedString.of("Only When Hurt"), false)
            .setDescription(EncryptedString.of("Only backtrack while target hurtTime > 0 (safer pattern)"));

    private static final int MAX_SAMPLES = 40;
    private final Map<UUID, ArrayDeque<Sample>> history = new HashMap<>();
    private final double[] gcdRemainder = {0.0, 0.0};
    private float jitteredThreshold = 0.92f;
    private int jitterCd;

    private static Backtrack instance;

    private record Sample(long timeMs, Vec3d pos, Box box) {}

    public Backtrack() {
        super(EncryptedString.of("Backtrack"),
                EncryptedString.of("Hits players at their recent lagged positions — client-side history"),
                -1,
                Category.SWORD);
        addSettings(minMs, maxMs, range, cooldown, rotate, friendSafe, onlyWhenHurt);
        instance = this;
    }

    public static Backtrack get() {
        return instance;
    }

    /** Public lookup for other combat modules. */
    public static Vec3d getDelayedPos(PlayerEntity player) {
        if (instance == null || !instance.isEnabled() || player == null) return null;
        return instance.resolvePos(player);
    }

    public static Box getDelayedBox(PlayerEntity player) {
        if (instance == null || !instance.isEnabled() || player == null) return null;
        return instance.resolveBox(player);
    }

    @Override
    public void onEnable() {
        eventManager.add(TickListener.class, this);
        history.clear();
        jitteredThreshold = cooldown.getValueFloat();
        super.onEnable();
    }

    @Override
    public void onDisable() {
        eventManager.remove(TickListener.class, this);
        history.clear();
        super.onDisable();
    }

    private void samplePlayers() {
        long now = System.currentTimeMillis();
        long keep = (long) maxMs.getValue() + 80L;

        for (PlayerEntity p : mc.world.getPlayers()) {
            if (p == mc.player || !p.isAlive()) continue;
            UUID id = p.getUuid();
            ArrayDeque<Sample> q = history.computeIfAbsent(id, k -> new ArrayDeque<>());
            Vec3d pos = p.getEntityPos();
            q.addLast(new Sample(now, pos, p.getBoundingBox()));
            while (q.size() > MAX_SAMPLES || (!q.isEmpty() && now - q.peekFirst().timeMs > keep)) {
                q.pollFirst();
            }
        }

        // drop disconnected
        history.entrySet().removeIf(e -> {
            boolean still = false;
            for (PlayerEntity p : mc.world.getPlayers()) {
                if (p.getUuid().equals(e.getKey())) { still = true; break; }
            }
            return !still;
        });
    }

    private Sample pick(PlayerEntity p) {
        ArrayDeque<Sample> q = history.get(p.getUuid());
        if (q == null || q.isEmpty()) return null;
        long now = System.currentTimeMillis();
        long min = (long) minMs.getValue();
        long max = (long) maxMs.getValue();
        // jitter the chosen age a bit each hit window
        long prefer = min + ThreadLocalRandom.current().nextLong(Math.max(1, max - min + 1));

        Sample best = null;
        long bestDelta = Long.MAX_VALUE;
        for (Sample s : q) {
            long age = now - s.timeMs;
            if (age < min || age > max) continue;
            long d = Math.abs(age - prefer);
            if (d < bestDelta) {
                bestDelta = d;
                best = s;
            }
        }
        return best;
    }

    private Vec3d resolvePos(PlayerEntity p) {
        Sample s = pick(p);
        return s == null ? null : s.pos;
    }

    private Box resolveBox(PlayerEntity p) {
        Sample s = pick(p);
        return s == null ? null : s.box;
    }

    @Override
    public void onTick() {
        if (mc.player == null || mc.world == null || mc.interactionManager == null || mc.currentScreen != null)
            return;

        samplePlayers();

        if (AntibanbyDaduncs.isAttackSent() || AntibanbyDaduncs.isActionSent())
            return;

        if (jitterCd-- <= 0) {
            float base = cooldown.getValueFloat();
            float v = base * 0.04f;
            jitteredThreshold = MathHelper.clamp(base + (float) (ThreadLocalRandom.current().nextDouble() * v * 2 - v), 0.5f, 1f);
            jitterCd = 3 + ThreadLocalRandom.current().nextInt(5);
        }

        if (mc.player.getAttackCooldownProgress(0.5f) < jitteredThreshold)
            return;

        PlayerEntity best = null;
        Box bestBox = null;
        double bestDist = Math.min(range.getValue(), 3.2);
        Vec3d eye = mc.player.getEyePos();

        for (PlayerEntity p : mc.world.getPlayers()) {
            if (p == mc.player || !p.isAlive() || p.isSpectator()) continue;
            if (friendSafe.getValue() && Alroca.INSTANCE.getFriendManager().isFriend(p)) continue;
            if (onlyWhenHurt.getValue() && p.hurtTime <= 0) continue;
            if (p.hurtTime >= 2) continue;

            Box box = resolveBox(p);
            if (box == null) box = p.getBoundingBox();

            Vec3d closest = new Vec3d(
                    MathHelper.clamp(eye.x, box.minX, box.maxX),
                    MathHelper.clamp(eye.y, box.minY, box.maxY),
                    MathHelper.clamp(eye.z, box.minZ, box.maxZ));
            double d = eye.distanceTo(closest);
            if (d <= bestDist) {
                bestDist = d;
                best = p;
                bestBox = box;
            }
        }

        if (best == null || bestBox == null) return;

        if (rotate.getValue()) {
            Rotation raw = RotationUtils.getDirection(eye, bestBox.getCenter());
            Rotation q = RotationUtils.applyGCD(
                    mc.player.getYaw(), mc.player.getPitch(),
                    (float) raw.yaw(), (float) raw.pitch(),
                    gcdRemainder, true);
            mc.player.setYaw((float) q.yaw());
            mc.player.setPitch((float) q.pitch());
        }

        // attack real entity — server still validates entity id; delayed box
        // only helps client-side reach / aim alignment & prediction
        mc.interactionManager.attackEntity(mc.player, best);
        mc.player.swingHand(Hand.MAIN_HAND);
    }
}
