/*
 * FireworkFly — auto rocket while gliding
 * Reuses multi-tick inventory path (no same-tick SWAP+USE).
 * Prefer hotbar/offhand; step-gap between inventory steps.
 */

package dlindustries.uk.daduncs.module.modules.sword;

import dlindustries.uk.daduncs.event.events.TickListener;
import dlindustries.uk.daduncs.managers.AntibanbyDaduncs;
import dlindustries.uk.daduncs.module.Category;
import dlindustries.uk.daduncs.module.Module;
import dlindustries.uk.daduncs.module.setting.bool;
import dlindustries.uk.daduncs.module.setting.number;
import dlindustries.uk.daduncs.utils.EncryptedString;
import dlindustries.uk.daduncs.utils.InventoryUtils;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.item.Items;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.util.Hand;

public final class FireworkFly extends Module implements TickListener {

    private final number delay = new number(EncryptedString.of("Delay"), 4, 40, 12, 1)
            .setDescription(EncryptedString.of("Ticks between rocket uses"));
    private final number stepGap = new number(EncryptedString.of("Step Gap"), 1, 4, 1, 1)
            .setDescription(EncryptedString.of("Ticks between swap / use / restore"));
    private final bool onlyGliding = new bool(EncryptedString.of("Only Gliding"), true);
    private final bool lowSpeed = new bool(EncryptedString.of("Low Speed Only"), true)
            .setDescription(EncryptedString.of("Only fire when horizontal speed drops below threshold"));
    private final number speedThreshold = new number(EncryptedString.of("Speed Threshold"), 0.2, 2.0, 0.9, 0.05)
            .setVisibility(lowSpeed::getValue);

    private enum Phase { IDLE, HOTBAR_USE, HOTBAR_RESTORE, INV_USE, INV_RESTORE }

    private Phase phase = Phase.IDLE;
    private int phaseTicks;
    private int cooldown;
    private int originalHotbar = -1;
    private int invSlotId = -1;
    private int invTargetHotbar = -1;

    public FireworkFly() {
        super(EncryptedString.of("Firework Fly"),
                EncryptedString.of("Auto-uses fireworks while gliding with split-tick inventory path"),
                -1,
                Category.SWORD);
        addSettings(delay, stepGap, onlyGliding, lowSpeed, speedThreshold);
    }

    @Override
    public void onEnable() {
        eventManager.add(TickListener.class, this);
        reset();
        super.onEnable();
    }

    @Override
    public void onDisable() {
        eventManager.remove(TickListener.class, this);
        if (mc.player != null && originalHotbar >= 0 && phase != Phase.IDLE)
            InventoryUtils.setInvSlot(originalHotbar);
        reset();
        super.onDisable();
    }

    private void reset() {
        phase = Phase.IDLE;
        phaseTicks = 0;
        originalHotbar = -1;
        invSlotId = -1;
        invTargetHotbar = -1;
        cooldown = 0;
    }

    @Override
    public void onTick() {
        if (mc.player == null || mc.world == null || mc.interactionManager == null)
            return;
        if (mc.currentScreen != null && phase == Phase.IDLE)
            return;

        if (phase != Phase.IDLE) {
            tickPhase();
            return;
        }

        if (cooldown > 0) {
            cooldown--;
            return;
        }

        if (onlyGliding.getValue() && !mc.player.isGliding())
            return;
        if (AntibanbyDaduncs.isActionSent() || AntibanbyDaduncs.isSlotPending())
            return;

        if (lowSpeed.getValue()) {
            var v = mc.player.getVelocity();
            double h = Math.sqrt(v.x * v.x + v.z * v.z);
            if (h > speedThreshold.getValue())
                return;
        }

        if (beginUse()) {
            cooldown = Math.max(2, delay.getValueInt());
        }
    }

    private void tickPhase() {
        if (phaseTicks > 0) {
            phaseTicks--;
            return;
        }
        ClientPlayerEntity p = mc.player;
        if (p == null || mc.interactionManager == null) {
            reset();
            return;
        }
        if (AntibanbyDaduncs.isActionSent() || AntibanbyDaduncs.isSlotPending()) {
            phaseTicks = 1;
            return;
        }
        int gap = Math.max(1, stepGap.getValueInt());
        switch (phase) {
            case HOTBAR_USE -> {
                mc.interactionManager.interactItem(p, Hand.MAIN_HAND);
                phase = Phase.HOTBAR_RESTORE;
                phaseTicks = gap;
            }
            case HOTBAR_RESTORE -> {
                if (originalHotbar >= 0 && originalHotbar <= 8)
                    InventoryUtils.setInvSlot(originalHotbar);
                phase = Phase.IDLE;
                originalHotbar = -1;
            }
            case INV_USE -> {
                mc.interactionManager.interactItem(p, Hand.MAIN_HAND);
                phase = Phase.INV_RESTORE;
                phaseTicks = gap;
            }
            case INV_RESTORE -> {
                if (invSlotId >= 0 && invTargetHotbar >= 0) {
                    int sync = p.playerScreenHandler.syncId;
                    mc.interactionManager.clickSlot(sync, invSlotId, invTargetHotbar, SlotActionType.SWAP, p);
                }
                phase = Phase.IDLE;
                invSlotId = -1;
                invTargetHotbar = -1;
            }
            default -> phase = Phase.IDLE;
        }
    }

    private boolean beginUse() {
        ClientPlayerEntity p = mc.player;
        int selected = p.getInventory().getSelectedSlot();

        if (p.getInventory().getStack(selected).isOf(Items.FIREWORK_ROCKET)) {
            mc.interactionManager.interactItem(p, Hand.MAIN_HAND);
            return true;
        }
        if (p.getOffHandStack().isOf(Items.FIREWORK_ROCKET)) {
            mc.interactionManager.interactItem(p, Hand.OFF_HAND);
            return true;
        }

        for (int i = 0; i < 9; i++) {
            if (i == selected) continue;
            if (!p.getInventory().getStack(i).isOf(Items.FIREWORK_ROCKET)) continue;
            originalHotbar = selected;
            InventoryUtils.setInvSlot(i);
            phase = Phase.HOTBAR_USE;
            phaseTicks = Math.max(1, stepGap.getValueInt());
            return true;
        }

        int from = -1;
        for (int i = 9; i < 36; i++) {
            if (p.getInventory().getStack(i).isOf(Items.FIREWORK_ROCKET)) {
                from = i;
                break;
            }
        }
        if (from == -1) return false;

        invSlotId = from;
        invTargetHotbar = selected;
        originalHotbar = selected;
        int sync = p.playerScreenHandler.syncId;
        mc.interactionManager.clickSlot(sync, invSlotId, invTargetHotbar, SlotActionType.SWAP, p);
        phase = Phase.INV_USE;
        phaseTicks = Math.max(1, stepGap.getValueInt());
        return true;
    }
}
