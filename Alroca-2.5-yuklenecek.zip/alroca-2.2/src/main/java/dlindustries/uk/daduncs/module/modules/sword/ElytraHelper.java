package dlindustries.uk.daduncs.module.modules.sword;

import dlindustries.uk.daduncs.event.events.TickListener;
import dlindustries.uk.daduncs.module.Category;
import dlindustries.uk.daduncs.module.Module;
import dlindustries.uk.daduncs.module.setting.bind;
import dlindustries.uk.daduncs.module.setting.bool;
import dlindustries.uk.daduncs.module.setting.number;
import dlindustries.uk.daduncs.utils.EncryptedString;
import dlindustries.uk.daduncs.utils.KeyUtils;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.Items;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.util.Hand;

/**
 * Elytra Helper
 * Atanan tusa basinca envanterdeki (hotbar veya ana envanter) firework'u elinde tutmadan kullanir.
 * Secili hotbar slotu degismez.
 */
public final class ElytraHelper extends Module implements TickListener {

	private final bind fireworkKey = new bind(EncryptedString.of("Firework Key"), -1, false)
			.setDescription(EncryptedString.of("Press this key to use a firework from your inventory"));

	private final bool onlyWhileGliding = new bool(EncryptedString.of("Only While Gliding"), false)
			.setDescription(EncryptedString.of("Only use the firework while flying with an elytra"));

	private final bool holdToRepeat = new bool(EncryptedString.of("Hold To Repeat"), false)
			.setDescription(EncryptedString.of("Keep using fireworks while the key is held"));

	private final number repeatDelay = new number(EncryptedString.of("Repeat Delay"), 1, 40, 10, 1)
			.setDescription(EncryptedString.of("Ticks between fireworks when holding the key (20 ticks = 1 second)"));

	private boolean wasPressed;
	private int cooldown;

	public ElytraHelper() {
		super(EncryptedString.of("Elytra Helper"),
				EncryptedString.of("Uses a firework from your inventory when you press the key, without holding it"),
				-1,
				Category.SWORD);
		addSettings(fireworkKey, onlyWhileGliding, holdToRepeat, repeatDelay);
	}

	@Override
	public void onEnable() {
		eventManager.add(TickListener.class, this);
		wasPressed = false;
		cooldown = 0;
		super.onEnable();
	}

	@Override
	public void onDisable() {
		eventManager.remove(TickListener.class, this);
		wasPressed = false;
		cooldown = 0;
		super.onDisable();
	}

	@Override
	public void onTick() {
		if (mc.player == null || mc.world == null || mc.interactionManager == null) {
			wasPressed = false;
			return;
		}
		if (mc.currentScreen != null) {
			wasPressed = false;
			return;
		}

		if (cooldown > 0) cooldown--;

		int key = fireworkKey.getKey();
		if (key == -1) return;

		boolean pressed = KeyUtils.isKeyPressed(key);

		if (pressed && !wasPressed) {
			useFirework();
			cooldown = repeatDelay.getValueInt();
		} else if (pressed && holdToRepeat.getValue() && cooldown <= 0) {
			useFirework();
			cooldown = repeatDelay.getValueInt();
		}

		wasPressed = pressed;
	}

	private void useFirework() {
		if (onlyWhileGliding.getValue() && !mc.player.isGliding()) return;

		PlayerInventory inv = mc.player.getInventory();
		int selected = inv.getSelectedSlot();

		// 1) Elde zaten firework varsa direkt kullan.
		if (inv.getStack(selected).isOf(Items.FIREWORK_ROCKET)) {
			mc.interactionManager.interactItem(mc.player, Hand.MAIN_HAND);
			return;
		}

		// 2) Offhand'de varsa onu kullan.
		if (mc.player.getOffHandStack().isOf(Items.FIREWORK_ROCKET)) {
			mc.interactionManager.interactItem(mc.player, Hand.OFF_HAND);
			return;
		}

		// 3) Envanterde ara (0-8 hotbar, 9-35 ana envanter).
		int from = -1;
		for (int i = 0; i < 36; i++) {
			if (i == selected) continue;
			if (inv.getStack(i).isOf(Items.FIREWORK_ROCKET)) {
				from = i;
				break;
			}
		}
		if (from == -1) return;

		// Envanter indeksi -> container slot id (hotbar 0-8 => 36-44, ana envanter 9-35 => 9-35)
		int slotId = from < 9 ? 36 + from : from;
		int syncId = mc.player.playerScreenHandler.syncId;

		// Firework'u secili slota al, kullan, geri al. Hepsi ayni tick icinde.
		mc.interactionManager.clickSlot(syncId, slotId, selected, SlotActionType.SWAP, mc.player);
		mc.interactionManager.interactItem(mc.player, Hand.MAIN_HAND);
		mc.interactionManager.clickSlot(syncId, slotId, selected, SlotActionType.SWAP, mc.player);
	}
}
