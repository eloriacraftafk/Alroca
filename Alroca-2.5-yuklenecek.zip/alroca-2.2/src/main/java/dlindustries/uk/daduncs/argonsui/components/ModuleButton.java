/*
 * This file is part of System Client (https://github.com/daduncs/system)
 * Website: https://download.daduncs.cloud/
 *
 * Copyright (c) 2024 - 2026 DLindustries and project contributors.
 *
 * System Client is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * System Client is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with System Client. If not, see <https://www.gnu.org/licenses/>.
 */

package dlindustries.uk.daduncs.argonsui.components;

import dlindustries.uk.daduncs.Alroca;
import dlindustries.uk.daduncs.argonsui.Window;
import dlindustries.uk.daduncs.argonsui.components.settings.*;
import dlindustries.uk.daduncs.module.Module;
import dlindustries.uk.daduncs.argonsui.AnimationUtils;
import dlindustries.uk.daduncs.module.setting.*;
import dlindustries.uk.daduncs.utils.*;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

import java.awt.*;
import java.util.ArrayList;
import java.util.List;

import static dlindustries.uk.daduncs.Alroca.mc;

public final class ModuleButton {
	public List<RenderableSetting> settings = new ArrayList<>();
	public Window parent;
	public Module module;
	public int offset;
	public boolean extended;
	public int settingOffset;
	public Color currentColor;
	public Color defaultColor = Color.WHITE;
	public Color currentAlpha;
	public AnimationUtils animation = new AnimationUtils(0);

	public ModuleButton(Window parent, Module module, int offset) {
		this.parent = parent;
		this.module = module;
		this.offset = offset;
		this.extended = false;

		settingOffset = parent.getHeight();
		for (Setting<?> setting : module.getSettings()) {
			if (setting instanceof bool booleanSetting)
				settings.add(new CheckBox(this, booleanSetting, settingOffset));
			else if (setting instanceof number numberSetting)
				settings.add(new Slider(this, numberSetting, settingOffset));
			else if (setting instanceof mode<?> modeSetting)
				settings.add(new ModeBox(this, modeSetting, settingOffset));
			else if (setting instanceof bind keybindSetting)
				settings.add(new KeybindBox(this, keybindSetting, settingOffset));
			else if (setting instanceof string stringSetting)
				settings.add(new StringBox(this, stringSetting, settingOffset));
			else if (setting instanceof range minMaxSetting)
				settings.add(new MinMaxSlider(this, minMaxSetting, settingOffset));

			settingOffset += parent.getHeight();
		}
	}

	public void render(DrawContext context, int mouseX, int mouseY, float delta) {
		if (parent.getY() + offset > MinecraftClient.getInstance().getWindow().getHeight())
			return;

		for (RenderableSetting renderableSetting : settings)
			renderableSetting.onUpdate();

		if (currentColor == null)
			currentColor = new Color(0, 0, 0, 0);
		else currentColor = new Color(0, 0, 0, currentColor.getAlpha());

		// enabled = lighter purple row, disabled = dark purple row
		int toAlpha = module.isEnabled() ? 210 : 120;
		currentColor = ColorUtils.smoothAlphaTransition(0.05F, toAlpha, currentColor);

		Color toColor = Color.WHITE;

		if (defaultColor != toColor)
			defaultColor = ColorUtils.smoothColorTransition(0.1F, toColor, defaultColor);

		int rowX1 = parent.getX() + 8;
		int rowX2 = parent.getX() + parent.getWidth() - 8;
		int rowY1 = parent.getY() + offset + 2;
		int rowY2 = parent.getY() + parent.getHeight() + offset - 2;

		Color rowColor = module.isEnabled()
				? new Color(78, 44, 122, currentColor.getAlpha())
				: new Color(40, 24, 62, currentColor.getAlpha());

		RenderUtils.renderRoundedQuad(context, rowColor, rowX1, rowY1, rowX2, rowY2, 3, 3, 3, 3, 50);

		CharSequence nameChars = module.getName();

		// module name on the left
		TextRenderer.drawString(nameChars, context, rowX1 + 8, parent.getY() + offset + 8, defaultColor.getRGB());

		// small dash on the right for modules that have settings
		if (!module.getSettings().isEmpty()) {
			CharSequence dash = "-";
			TextRenderer.drawString(dash, context, rowX2 - 8 - TextRenderer.getWidth(dash), parent.getY() + offset + 8, new Color(200, 200, 210, 220).getRGB());
		}

		renderHover(context, mouseX, mouseY, delta);
		renderSettings(context, mouseX, mouseY, delta);

		for(RenderableSetting renderableSetting : settings)
			if(extended) renderableSetting.renderDescription(context, mouseX, mouseY, delta);

		if (isHovered(mouseX, mouseY) && !parent.dragging) {
			CharSequence chars = module.getDescription();

			int tw = TextRenderer.getWidth(chars);

			int parentCenter = mc.getWindow().getFramebufferWidth() / 2;
			int textCenter = parentCenter - tw / 2;

			RenderUtils.renderRoundedQuad(
					context,
					new Color(100, 100, 100, 100),
					textCenter - 5,
					((double) mc.getWindow().getFramebufferHeight() / 2) + 294,
					textCenter + tw + 5,
					((double) mc.getWindow().getFramebufferHeight() / 2) + 318,
					3,
					10
			);

			TextRenderer.drawString(chars, context, textCenter, (mc.getWindow().getFramebufferHeight() / 2) + 300, Color.WHITE.getRGB());
		}
	}

	private void renderHover(DrawContext context, int mouseX, int mouseY, float delta) {
		if (!parent.dragging) {
			int toHoverAlpha = isHovered(mouseX, mouseY) ? 15 : 0;

			if (currentAlpha == null)
				currentAlpha = new Color(255, 255, 255, toHoverAlpha);
			else currentAlpha = new Color(255, 255, 255, currentAlpha.getAlpha());

			if (currentAlpha.getAlpha() != toHoverAlpha)
				currentAlpha = ColorUtils.smoothAlphaTransition(0.05F, toHoverAlpha, currentAlpha);

			context.fill(parent.getX(), parent.getY() + offset, parent.getX() + parent.getWidth(), parent.getY() + parent.getHeight() + offset, currentAlpha.getRGB());
		}
	}

	private void renderSettings(DrawContext context, int mouseX, int mouseY, float delta) {
		int scissorX1 = parent.getX();
		int scissorY1 = parent.getY() + offset;
		int scissorX2 = scissorX1 + parent.getWidth();
		int scissorY2 = scissorY1 + (int) animation.getValue();

		context.enableScissor(scissorX1, scissorY1, scissorX2, scissorY2);

		for (RenderableSetting renderableSetting : settings)
			if(animation.getValue() > parent.getHeight())
				renderableSetting.render(context, mouseX, mouseY, delta);

		for (RenderableSetting renderableSetting : settings) {
			if(animation.getValue() > parent.getHeight()) {
				if (renderableSetting instanceof Slider slider) {
					RenderUtils.renderCircle(context, new Color(0, 0, 0, 170), (slider.parentX() + (Math.max(slider.lerpedOffsetX, 2.5))), slider.parentY() + slider.offset + slider.parentOffset() + 27.5, 6, 15);
					RenderUtils.renderCircle(context, slider.currentColor1.brighter(), (slider.parentX() + (Math.max(slider.lerpedOffsetX, 2.5))) , slider.parentY() + slider.offset + slider.parentOffset() + 27.5, 5, 15);

				} else if (renderableSetting instanceof MinMaxSlider slider) {
					RenderUtils.renderCircle(context, new Color(0, 0, 0, 170), (slider.parentX() + (Math.max(slider.lerpedOffsetMinX, 2.5))), slider.parentY() + slider.offset + slider.parentOffset() + 27.5, 6, 15);
					RenderUtils.renderCircle(context, slider.currentColor1.brighter(), (slider.parentX() + (Math.max(slider.lerpedOffsetMinX, 2.5))), slider.parentY() + slider.offset + slider.parentOffset() + 27.5, 5, 15);

					RenderUtils.renderCircle(context, new Color(0, 0, 0, 170), (slider.parentX() + (Math.max(slider.lerpedOffsetMaxX, 2.5))), slider.parentY() + slider.offset + slider.parentOffset() + 27.5, 6, 15);
					RenderUtils.renderCircle(context, slider.currentColor1.brighter(), (slider.parentX() + (Math.max(slider.lerpedOffsetMaxX, 2.5))), slider.parentY() + slider.offset + slider.parentOffset() + 27.5, 5, 15);
				}
			}
		}

		context.disableScissor();
	}

	public void onExtend() {
		for(ModuleButton moduleButton : parent.moduleButtons) {
			moduleButton.extended = false;
		}
	}

	public void keyPressed(int keyCode, int scanCode, int modifiers) {
		for (RenderableSetting setting : settings)
			setting.keyPressed(keyCode, scanCode, modifiers);
	}

	public void mouseDragged(double mouseX, double mouseY, int button, double deltaX, double deltaY) {
		if (extended)
			for (RenderableSetting renderableSetting : settings)
				renderableSetting.mouseDragged(mouseX, mouseY, button, deltaX, deltaY);
	}

	public void mouseClicked(double mouseX, double mouseY, int button) {
		if (isHovered(mouseX, mouseY)) {
			if (button == 0)
				module.toggle();

			if (button == 1) {
				if (module.getSettings().isEmpty()) return;
				if (!extended)
					onExtend();

				extended = !extended;
			}
		}
		if (extended) {
			for (RenderableSetting renderableSetting : settings) {
				renderableSetting.mouseClicked(mouseX, mouseY, button);
			}
		}
	}

	public void onGuiClose() {
		this.currentAlpha = null;
		this.currentColor = null;

		for (RenderableSetting renderableSetting : settings)
			renderableSetting.onGuiClose();
	}

	public void mouseReleased(double mouseX, double mouseY, int button) {
		for (RenderableSetting renderableSetting : settings)
			renderableSetting.mouseReleased(mouseX, mouseY, button);
	}

	public boolean isHovered(double mouseX, double mouseY) {
		return mouseX > parent.getX()
				&& mouseX < parent.getX() + parent.getWidth()
				&& mouseY > parent.getY() + offset
				&& mouseY < parent.getY() + offset + parent.getHeight();
	}
}
