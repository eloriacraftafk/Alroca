/*
 * This file is part of System Client (https://github.com/daduncs/system)
 * Website: https://download.daduncs.cloud/
 *
 * Copyright (c) 2024 - 2026 DLindustries and project contributors.
 *
 * System Client is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * System Client is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with System Client. If not, see <https://www.gnu.org/licenses/>.
 */

package dlindustries.uk.daduncs.imixin;

import net.minecraft.util.math.Vec3i;
import org.joml.Vector3d;

public interface IVec3d {
	void set(double x, double y, double z);

	default void set(Vec3i vec) {
		set(vec.getX(), vec.getY(), vec.getZ());
	}

	default void set(Vector3d vec) {
		set(vec.x, vec.y, vec.z);
	}

	void setXZ(double x, double z);

	void setY(double y);
}
