package dev.marlow.crystal.module.impl

import dev.marlow.crystal.module.Module
import dev.marlow.crystal.module.setting.Randomizer
import net.minecraft.entity.LivingEntity
import net.minecraft.entity.player.PlayerEntity
import net.minecraft.item.Items
import net.minecraft.network.packet.c2s.play.UpdateSelectedSlotC2SPacket
import net.minecraft.util.Hand

class FireworkSwap : Module("FireworkSwap", "Firework hit → sword hit → back to firework") {

    private var fwSlot    = -1
    private var swordSlot = -1
    private var phase     = Phase.IDLE
    private var phaseTick = 0
    private var swingHold = 3

    enum class Phase { IDLE, WAIT_TICK, SWORD_SWING, RETURN }

    fun onAttack(player: PlayerEntity, target: LivingEntity) {
        if (!enabled) return
        if (phase != Phase.IDLE) return

        val inv = player.inventory
        fwSlot  = inv.selectedSlot
        if (inv.getStack(fwSlot).item != Items.FIREWORK_ROCKET) return

        swordSlot = (0..8).firstOrNull {
            val item = inv.getStack(it).item
            item == Items.NETHERITE_SWORD || item == Items.DIAMOND_SWORD   ||
            item == Items.IRON_SWORD      || item == Items.GOLDEN_SWORD    ||
            item == Items.STONE_SWORD     || item == Items.WOODEN_SWORD
        } ?: return

        swingHold = Randomizer.gaussianLong(3L, 5L).toInt()

        setSlot(swordSlot)
        phase     = Phase.WAIT_TICK
        phaseTick = 0
    }

    override fun onTick(player: PlayerEntity) {
        if (!enabled) { reset(); return }

        when (phase) {
            Phase.WAIT_TICK -> {
                val t = mc.targetedEntity
                if (t is LivingEntity) {
                    mc.interactionManager?.attackEntity(player, t)
                    player.swingHand(Hand.MAIN_HAND)
                }
                phase     = Phase.SWORD_SWING
                phaseTick = 0
            }
            Phase.SWORD_SWING -> {
                phaseTick++
                if (phaseTick >= swingHold) {
                    setSlot(fwSlot)
                    phase     = Phase.RETURN
                    phaseTick = 0
                }
            }
            Phase.RETURN -> {
                phaseTick++
                if (phaseTick >= 2) {
                    phase     = Phase.IDLE
                    phaseTick = 0
                }
            }
            Phase.IDLE -> {}
        }
    }

    private fun setSlot(slot: Int) {
        val p = mc.player ?: return
        p.inventory.selectedSlot = slot
        mc.networkHandler?.sendPacket(UpdateSelectedSlotC2SPacket(slot))
    }

    private fun reset() {
        if (phase != Phase.IDLE && fwSlot != -1) setSlot(fwSlot)
        phase = Phase.IDLE; phaseTick = 0; fwSlot = -1; swordSlot = -1
    }

    override fun onDisable() = reset()
}
