package dev.marlow.crystal.module

import dev.marlow.crystal.gui.ToastManager
import dev.marlow.crystal.module.setting.BoolSetting
import dev.marlow.crystal.module.setting.FloatSetting
import dev.marlow.crystal.module.setting.IntSetting
import net.minecraft.client.MinecraftClient
import net.minecraft.client.gui.DrawContext
import net.minecraft.entity.player.PlayerEntity

abstract class Module(val name: String, val description: String, var key: Int = -1) {
    var enabled = false
        set(value) {
            field = value
            // toggle bildirimi — her enable/disable'da toast gönder
            ToastManager.push(name, value)
            if (value) onEnable() else onDisable()
        }

    protected val mc: MinecraftClient get() = MinecraftClient.getInstance()

    val settings: List<Any> get() = this::class.java.declaredFields
        .filter { it.type == IntSetting::class.java || it.type == FloatSetting::class.java || it.type == BoolSetting::class.java }
        .onEach { it.isAccessible = true }
        .mapNotNull { it.get(this) }

    open fun onEnable()  {}
    open fun onDisable() {}
    open fun onTick(player: PlayerEntity) {}
    open fun onRender(drawContext: DrawContext) {}
    fun toggle() { enabled = !enabled }
}
