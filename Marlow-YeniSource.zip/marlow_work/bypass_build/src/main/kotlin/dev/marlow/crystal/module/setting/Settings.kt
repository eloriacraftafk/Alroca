package dev.marlow.crystal.module.setting

class IntSetting(val name: String, default: Int, val min: Int, val max: Int) {
    var value: Int = default
}

class FloatSetting(val name: String, default: Float, val min: Float, val max: Float) {
    var value: Float = default
}

class BoolSetting(val name: String, default: Boolean) {
    var value: Boolean = default
}

object Randomizer {
    private val rng = java.util.Random()

    fun gaussian(): Double = rng.nextGaussian().coerceIn(-2.0, 2.0)

    fun gaussianLong(min: Long, max: Long): Long {
        val range = (max - min).toDouble()
        val g = (gaussian() + 2.0) / 4.0
        return min + (g * range).toLong()
    }

    fun uniform(min: Double, max: Double): Double = min + rng.nextDouble() * (max - min)

    fun jitterF(scale: Float): Float = (rng.nextGaussian() * scale).toFloat()
}

/**
 * GrimMouseSimulator — bypasses Grim's AimProcessor GCD detection.
 *
 * How Grim catches bots:
 *   AimProcessor.process() calls GrimMath.gcd(deltaYaw, lastYaw) every rotation update.
 *   It accumulates the GCD divisor in a RunningMode (80-sample window).
 *   If >15 samples share the same divisor, it infers mouse sensitivity from it.
 *   A fixed GCD step (like our original snapToGrid(0.15f)) produces a perfectly
 *   constant divisor that immediately fills the mode bucket — obvious flag vector.
 *
 * Fix strategy:
 *   1. Simulate vanilla Minecraft mouse sensitivity quantization.
 *      Vanilla: sensitivity ∈ [0,1] → f(s) = s*0.6+0.2 → gcd_step = f³*8*0.15
 *      We pick a random sensitivity per session and add per-tick noise to mimic
 *      real player micro-adjustments (sensitivity slider isn't perfectly stable).
 *   2. Add bounded Gaussian noise to the GCD step each tick so the divisor
 *      distribution is spread across multiple buckets, never filling one.
 *   3. Keep the noise amplitude small enough that rotations still look smooth
 *      (no >320° snap that triggers AimModulo360).
 *   4. Never send duplicate yaw+pitch (AimDuplicateLook: flags identical consecutive
 *      rotations from look packets — always jitter by at least MINIMUM_DIVISOR).
 */
object GrimMouseSimulator {
    // Grim's minimum meaningful divisor: ((0.2^3)*8)*0.15 ≈ 0.000384
    private const val MINIMUM_DIVISOR = 0.000384

    private val rng = java.util.Random()

    // Session sensitivity — randomized once per enable, mimics player picking a sens
    private var sessionSensitivity: Double = randomSensitivity()

    // Per-tick noise magnitude as fraction of gcd step
    private const val NOISE_FRACTION = 0.18

    fun resetSession() {
        sessionSensitivity = randomSensitivity()
    }

    private fun randomSensitivity(): Double {
        // Vanilla range [0,1]; most PvP players sit around 0.3–0.7
        return 0.30 + rng.nextGaussian().coerceIn(-1.0, 1.0) * 0.12 + 0.20
    }

    /**
     * Returns the GCD step to snap this tick's rotation to.
     * Varies slightly each call so the GCD divisor distribution is spread.
     */
    fun gcdStep(): Float {
        val f = sessionSensitivity * 0.6 + 0.2
        val baseStep = (f * f * f * 8.0 * 0.15).toFloat()
        // Add bounded Gaussian noise — stays above MINIMUM_DIVISOR
        val noise = (rng.nextGaussian() * NOISE_FRACTION * baseStep).toFloat()
        return (baseStep + noise).coerceAtLeast(MINIMUM_DIVISOR.toFloat())
    }

    /**
     * Snap [value] to the current GCD grid with a jitter offset so consecutive
     * rotations never land on the same exact float value (prevents AimDuplicateLook).
     */
    fun snap(value: Float): Float {
        val step = gcdStep()
        val snapped = (value / step).toLong() * step
        // Sub-step jitter: randomize the fractional remainder
        val jitter = rng.nextFloat() * step * 0.5f
        return snapped + jitter
    }
}
