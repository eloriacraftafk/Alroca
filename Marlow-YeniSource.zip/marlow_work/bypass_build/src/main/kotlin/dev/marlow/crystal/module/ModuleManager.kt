package dev.marlow.crystal.module

import dev.marlow.crystal.module.impl.*
import net.minecraft.client.MinecraftClient
import net.minecraft.client.gui.DrawContext
import org.lwjgl.glfw.GLFW

object ModuleManager {
    val modules = mutableListOf<Module>()
    private val mc get() = MinecraftClient.getInstance()

    fun init() {
        modules += TriggerBot()
        modules += AimAssist()
        modules += AttackAura()
        modules += FireworkSwap()
        modules += ElyFix()
        modules += TargetEsp()
    }

    fun onTick() {
        val player = mc.player ?: return
        modules.forEach { it.onTick(player) }
    }

    fun onRender(drawContext: DrawContext) {
        val player = mc.player ?: return
        modules.filter { it.enabled }.forEach { it.onRender(drawContext) }
    }

    fun onKeyPress(key: Int) {
        modules.filter { it.key == key }.forEach { it.toggle() }
    }

    fun getByName(name: String) = modules.find { it.name.equals(name, ignoreCase = true) }
}
