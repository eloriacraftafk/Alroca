package dev.marlow.crystal.mixin

import dev.marlow.crystal.module.ModuleManager
import net.minecraft.client.render.GameRenderer
import net.minecraft.client.render.RenderTickCounter
import org.spongepowered.asm.mixin.Mixin
import org.spongepowered.asm.mixin.injection.At
import org.spongepowered.asm.mixin.injection.Inject
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo

@Mixin(GameRenderer::class)
class MixinGameRenderer {

    // 1.21.4+ imzası: render(RenderTickCounter)
    // Eski (1.21.3-): render(float, long, boolean) — artık yok, crash veriyordu
    @Inject(
        method = ["render"],
        at = [At("TAIL")]
    )
    private fun onRenderTail(counter: RenderTickCounter, ci: CallbackInfo) {
        // TargetEsp render buradan beslenir
        // Şu an boş — CrystalHud.render() zaten HudRenderCallback üzerinden çalışıyor
    }
}
