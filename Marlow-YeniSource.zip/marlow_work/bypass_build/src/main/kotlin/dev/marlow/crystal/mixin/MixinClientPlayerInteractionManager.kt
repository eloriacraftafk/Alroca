package dev.marlow.crystal.mixin

import dev.marlow.crystal.module.ModuleManager
import dev.marlow.crystal.module.impl.FireworkSwap
import net.minecraft.client.network.ClientPlayerInteractionManager
import net.minecraft.entity.Entity
import net.minecraft.entity.LivingEntity
import net.minecraft.entity.player.PlayerEntity
import org.spongepowered.asm.mixin.Mixin
import org.spongepowered.asm.mixin.injection.At
import org.spongepowered.asm.mixin.injection.Inject
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo

@Mixin(ClientPlayerInteractionManager::class)
class MixinClientPlayerInteractionManager {

    // sol tık vurma anı — vanilla attackEntity çağrıldığında tetiklenir
    // FireworkSwap burada yakalıyor: elinde firework varsa swap döngüsü başlar
    @Inject(method = ["attackEntity"], at = [At("HEAD")])
    private fun onAttackEntity(player: PlayerEntity, entity: Entity, ci: CallbackInfo) {
        if (entity !is LivingEntity) return
        val fw = ModuleManager.getByName("FireworkSwap") as? FireworkSwap ?: return
        fw.onAttack(player, entity)
    }
}
