package dev.marlow.crystal.gui

import dev.marlow.crystal.module.Module
import dev.marlow.crystal.module.ModuleManager
import dev.marlow.crystal.module.setting.BoolSetting
import dev.marlow.crystal.module.setting.FloatSetting
import dev.marlow.crystal.module.setting.IntSetting
import net.minecraft.client.MinecraftClient
import net.minecraft.client.gui.Click
import net.minecraft.client.gui.DrawContext
import net.minecraft.client.gui.screen.Screen
import net.minecraft.client.input.KeyInput
import net.minecraft.text.Text
import org.lwjgl.glfw.GLFW

class CrystalScreen : Screen(Text.literal("Crystal Optimizer")) {
    private val mc get() = MinecraftClient.getInstance()

    private val panelW = 260
    private val panelH = 220
    private val colW = 120
    private val rowH = 28
    private val padding = 10

    private var settingsTarget: Module? = null
    private var bindTarget: Module? = null
    private var waitingForBind = false

    private val leftCol get() = ModuleManager.modules.take(3)
    private val rightCol get() = ModuleManager.modules.drop(3).take(3)

    private var draggingSetting: Any? = null

    override fun render(context: DrawContext, mouseX: Int, mouseY: Int, delta: Float) {
        val px = (width - panelW) / 2
        val py = (height - panelH) / 2

        context.fill(px, py, px + panelW, py + panelH, 0xE01a1a2e.toInt())
        context.fill(px, py, px + panelW, py + 20, 0xFF6a0dad.toInt())
        context.drawTextWithShadow(textRenderer, "Marlow Crystal Optimizer", px + 8, py + 6, 0xFFFFFF)
        context.drawTextWithShadow(textRenderer, "Combat / Utility", px + padding, py + 24, 0xAAAAAA)
        context.drawTextWithShadow(textRenderer, "Movement / Visual", px + padding + colW + 10, py + 24, 0xAAAAAA)

        leftCol.forEachIndexed { i, m -> drawBtn(context, m, px + padding, py + 36 + i * rowH, mouseX, mouseY) }
        rightCol.forEachIndexed { i, m -> drawBtn(context, m, px + padding + colW + 10, py + 36 + i * rowH, mouseX, mouseY) }

        settingsTarget?.let { drawSettings(context, it, px, py) }
        bindTarget?.let { drawBind(context, it) }

        super.render(context, mouseX, mouseY, delta)
    }

    private fun drawBtn(context: DrawContext, mod: Module, x: Int, y: Int, mx: Int, my: Int) {
        val hovered = mx >= x && mx <= x + colW && my >= y && my <= y + rowH - 2
        val bg = when {
            mod.enabled -> 0xFF2d1b4e.toInt()
            hovered -> 0xFF252540.toInt()
            else -> 0xFF1e1e38.toInt()
        }
        context.fill(x, y, x + colW, y + rowH - 2, bg)
        val color = if (mod.enabled) 0xFF00FF88.toInt() else 0xFFAAAAAA.toInt()
        context.drawTextWithShadow(textRenderer, mod.name, x + 6, y + 5, color)
        val bLabel = if (mod.key != -1) "[${GLFW.glfwGetKeyName(mod.key, 0)?.uppercase() ?: "?"}]" else "[--]"
        context.drawTextWithShadow(textRenderer, bLabel, x + 6, y + 15, 0x888888)
    }

    private fun drawSettings(context: DrawContext, mod: Module, px: Int, py: Int) {
        val sx = px + panelW + 4
        val sy = py
        val sw = 150
        val settings = mod.settings
        val sh = 20 + settings.size * 22 + 10

        context.fill(sx, sy, sx + sw, sy + sh, 0xEE1a1a2e.toInt())
        context.fill(sx, sy, sx + sw, sy + 16, 0xFF6a0dad.toInt())
        context.drawTextWithShadow(textRenderer, mod.name, sx + 4, sy + 4, 0xFFFFFF)

        settings.forEachIndexed { i, setting ->
            val ey = sy + 20 + i * 22
            when (setting) {
                is BoolSetting -> {
                    val col = if (setting.value) 0xFF00FF88.toInt() else 0xFF555577.toInt()
                    context.fill(sx + 4, ey, sx + sw - 4, ey + 16, 0xFF1e1e38.toInt())
                    context.drawTextWithShadow(textRenderer, setting.name, sx + 8, ey + 4, 0xFFFFFF)
                    context.fill(sx + sw - 20, ey + 3, sx + sw - 4, ey + 13, col)
                }
                is IntSetting -> {
                    context.fill(sx + 4, ey, sx + sw - 4, ey + 16, 0xFF1e1e38.toInt())
                    context.drawTextWithShadow(textRenderer, "${setting.name}: ${setting.value}", sx + 8, ey + 4, 0xFFFFFF)
                    val barX = sx + 4
                    val barW = sw - 8
                    val fill = ((setting.value - setting.min).toFloat() / (setting.max - setting.min) * barW).toInt()
                    context.fill(barX, ey + 13, barX + barW, ey + 16, 0xFF333355.toInt())
                    context.fill(barX, ey + 13, barX + fill, ey + 16, 0xFF6a0dad.toInt())
                }
                is FloatSetting -> {
                    context.fill(sx + 4, ey, sx + sw - 4, ey + 16, 0xFF1e1e38.toInt())
                    context.drawTextWithShadow(textRenderer, "${setting.name}: ${"%.2f".format(setting.value)}", sx + 8, ey + 4, 0xFFFFFF)
                    val barX = sx + 4
                    val barW = sw - 8
                    val fill = ((setting.value - setting.min) / (setting.max - setting.min) * barW).toInt()
                    context.fill(barX, ey + 13, barX + barW, ey + 16, 0xFF333355.toInt())
                    context.fill(barX, ey + 13, barX + fill, ey + 16, 0xFF6a0dad.toInt())
                }
            }
        }
    }

    private fun drawBind(context: DrawContext, mod: Module) {
        val bx = (width - 180) / 2
        val by = (height - 70) / 2
        context.fill(bx, by, bx + 180, by + 70, 0xEE1a1a2e.toInt())
        context.fill(bx, by, bx + 180, by + 18, 0xFF6a0dad.toInt())
        context.drawTextWithShadow(textRenderer, "Keybind: ${mod.name}", bx + 4, by + 4, 0xFFFFFF)
        val label = if (waitingForBind) "Press a key..." else "Bound: ${if (mod.key != -1) GLFW.glfwGetKeyName(mod.key, 0)?.uppercase() ?: "?" else "--"}"
        context.drawTextWithShadow(textRenderer, label, bx + 4, by + 28, 0xFFFFFF)
        context.drawTextWithShadow(textRenderer, "[ESC = cancel  DEL = clear]", bx + 4, by + 48, 0x888888)
    }

    override fun mouseClicked(click: Click, doubled: Boolean): Boolean {
        val mouseX = click.x()
        val mouseY = click.y()
        val button = click.buttonInfo().button()
        val px = (width - panelW) / 2
        val py = (height - panelH) / 2
        if (bindTarget != null) return true

        settingsTarget?.let { mod ->
            val sx = px + panelW + 4
            val sy = py
            val sw = 150
            val settings = mod.settings
            if (mouseX >= sx && mouseX <= sx + sw) {
                settings.forEachIndexed { i, setting ->
                    val ey = sy + 20 + i * 22
                    if (mouseY >= ey && mouseY <= ey + 16) {
                        when (setting) {
                            is BoolSetting -> if (button == GLFW.GLFW_MOUSE_BUTTON_LEFT) setting.value = !setting.value
                            is IntSetting, is FloatSetting -> draggingSetting = setting
                        }
                        return true
                    }
                }
                return true
            }
        }

        val allWithPos = buildList {
            leftCol.forEachIndexed { i, m -> add(Triple(m, px + padding, py + 36 + i * rowH)) }
            rightCol.forEachIndexed { i, m -> add(Triple(m, px + padding + colW + 10, py + 36 + i * rowH)) }
        }
        for ((mod, bx, by) in allWithPos) {
            if (mouseX >= bx && mouseX <= bx + colW && mouseY >= by && mouseY <= by + rowH - 2) {
                when (button) {
                    GLFW.GLFW_MOUSE_BUTTON_LEFT -> {
                        if (settingsTarget == mod) settingsTarget = null
                        else { mod.toggle(); settingsTarget = null }
                        return true
                    }
                    GLFW.GLFW_MOUSE_BUTTON_RIGHT -> {
                        settingsTarget = if (settingsTarget == mod) null else mod
                        return true
                    }
                    GLFW.GLFW_MOUSE_BUTTON_MIDDLE -> {
                        bindTarget = mod
                        waitingForBind = true
                        return true
                    }
                }
            }
        }
        if (button == GLFW.GLFW_MOUSE_BUTTON_LEFT && (mouseX < px || mouseX > px + panelW || mouseY < py || mouseY > py + panelH)) {
            if (settingsTarget == null) { mc.setScreen(null); return true }
            settingsTarget = null
        }
        return super.mouseClicked(click, doubled)
    }

    override fun mouseDragged(click: Click, deltaX: Double, deltaY: Double): Boolean {
        val mouseX = click.x()
        val setting = draggingSetting ?: return super.mouseDragged(click, deltaX, deltaY)
        settingsTarget ?: return super.mouseDragged(click, deltaX, deltaY)
        val px = (width - panelW) / 2
        val sx = px + panelW + 4
        val sw = 150
        val barW = sw - 8
        val ratio = ((mouseX - (sx + 4)) / barW).coerceIn(0.0, 1.0).toFloat()
        when (setting) {
            is IntSetting -> setting.value = (setting.min + ratio * (setting.max - setting.min)).toInt()
            is FloatSetting -> setting.value = setting.min + ratio * (setting.max - setting.min)
        }
        return true
    }

    override fun mouseReleased(click: Click): Boolean {
        draggingSetting = null
        return super.mouseReleased(click)
    }

    override fun keyPressed(input: KeyInput): Boolean {
        val keyCode = input.key()
        if (bindTarget != null && waitingForBind) {
            when (keyCode) {
                GLFW.GLFW_KEY_ESCAPE -> { bindTarget = null; waitingForBind = false }
                GLFW.GLFW_KEY_DELETE -> { bindTarget!!.key = -1; bindTarget = null; waitingForBind = false }
                else -> { bindTarget!!.key = keyCode; bindTarget = null; waitingForBind = false }
            }
            return true
        }
        if (keyCode == GLFW.GLFW_KEY_ESCAPE) {
            if (settingsTarget != null) { settingsTarget = null; return true }
            mc.setScreen(null)
            return true
        }
        return super.keyPressed(input)
    }

    override fun renderBackground(context: DrawContext, mouseX: Int, mouseY: Int, delta: Float) {
        context.fill(0, 0, width, height, 0x88000000.toInt())
    }

    override fun shouldPause() = false
}
