package dev.marlow.crystal.gui

import net.minecraft.client.MinecraftClient
import net.minecraft.client.gui.DrawContext

// ToastNotification — toggle bildirimi
// Ekranın ortasının biraz aşağısında çıkar, 1.5 saniye sonra fade out
data class Toast(
    val moduleName: String,
    val enabled: Boolean,
    val spawnTime: Long = System.currentTimeMillis()
) {
    // toplam ömür ms
    val duration = 1500L
    // fade başlangıcı — son 400ms'de solar
    val fadeStart = duration - 400L

    fun alpha(): Float {
        val elapsed = System.currentTimeMillis() - spawnTime
        if (elapsed >= duration) return 0f
        if (elapsed < fadeStart) return 1f
        // fadeStart → duration arası 1.0 → 0.0
        return 1f - ((elapsed - fadeStart).toFloat() / 400f)
    }

    fun alive() = System.currentTimeMillis() - spawnTime < duration
}

object ToastManager {
    private val mc get() = MinecraftClient.getInstance()
    // en fazla 5 toast aynı anda — stack gibi üst üste değil, dikey liste
    private val toasts = ArrayDeque<Toast>()

    fun push(moduleName: String, enabled: Boolean) {
        // aynı modülün eski toastını temizle
        toasts.removeAll { it.moduleName == moduleName }
        toasts.addLast(Toast(moduleName, enabled))
        if (toasts.size > 5) toasts.removeFirst()
    }

    fun render(drawContext: DrawContext) {
        toasts.removeAll { !it.alive() }
        if (toasts.isEmpty()) return

        val window   = mc.window
        val screenW  = window.scaledWidth
        val screenH  = window.scaledHeight
        val tr       = mc.textRenderer

        // başlangıç Y — ekranın %65'i (ortanın biraz aşağısı)
        val baseY    = (screenH * 0.65f).toInt()
        val toastW   = 160
        val toastH   = 20
        val gap      = 4

        toasts.forEachIndexed { i, toast ->
            val alpha = toast.alpha()
            if (alpha <= 0f) return@forEachIndexed

            val a    = (alpha * 255).toInt()
            val x    = (screenW - toastW) / 2
            val y    = baseY + i * (toastH + gap)

            // arka plan — yarı saydam koyu
            val bg   = (a shl 24) or 0x1a1a2e
            drawContext.fill(x, y, x + toastW, y + toastH, bg.toInt())

            // sol kenar çizgisi — enabled=yeşil, disabled=kırmızı
            val lineColor = if (toast.enabled)
                (a shl 24) or 0x00FF88
            else
                (a shl 24) or 0xFF4455
            drawContext.fill(x, y, x + 2, y + toastH, lineColor.toInt())

            // daire — enabled=yeşil, disabled=kırmızı
            // drawContext.fill ile 5x5 kare (daire taklidi)
            val circleColor = lineColor
            val cx = x + 10
            val cy = y + (toastH - 5) / 2
            drawContext.fill(cx, cy, cx + 5, cy + 5, circleColor.toInt())

            // metin
            val label  = if (toast.enabled) "§a${toast.moduleName} Enabled" else "§c${toast.moduleName} Disabled"
            val txtCol = (a shl 24) or 0xFFFFFF
            drawContext.drawTextWithShadow(tr, label, x + 20, y + 6, txtCol.toInt())
        }
    }
}
