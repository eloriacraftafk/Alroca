package dev.marlow.crystal.module.impl

import dev.marlow.crystal.module.Module
import net.minecraft.entity.EquipmentSlot
import net.minecraft.entity.player.PlayerEntity
import net.minecraft.item.Items
import net.minecraft.network.packet.c2s.play.ClientCommandC2SPacket
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket
import kotlin.math.abs
import kotlin.math.sqrt

class ElyFix : Module("ElyFix", "Fixes elytra stalls, freezes and unexpected stops") {

    private var wasFlying   = false
    private var stallTick   = 0
    private var fixCooldown = 0

    private val velYHistory  = ArrayDeque<Double>(5)
    private val HISTORY_SIZE = 5
    private val STALL_THRESH = 0.04

    override fun onTick(player: PlayerEntity) {
        if (!enabled) { reset(); return }

        val chestStack = player.getEquippedStack(EquipmentSlot.CHEST)
        if (chestStack.item != Items.ELYTRA) { reset(); return }

        val isFlying = player.isGliding
        val onGround = player.isOnGround
        val inWater  = player.isTouchingWater

        if (fixCooldown > 0) {
            fixCooldown--
            wasFlying = isFlying
            return
        }

        if (wasFlying && !isFlying && !onGround && !inWater) {
            mc.networkHandler?.sendPacket(
                ClientCommandC2SPacket(player, ClientCommandC2SPacket.Mode.START_FALL_FLYING)
            )
            fixCooldown = 10
        }

        if (isFlying) {
            velYHistory.addLast(player.velocity.y)
            if (velYHistory.size > HISTORY_SIZE) velYHistory.removeFirst()

            // FIX: replaced Math.sqrt / Math.abs (Java statics) with kotlin.math equivalents
            // for consistency with the rest of the module files; functionally identical.
            val velXZ  = sqrt(player.velocity.x * player.velocity.x + player.velocity.z * player.velocity.z)
            val avgVelY = if (velYHistory.size == HISTORY_SIZE) velYHistory.average() else null

            if (avgVelY != null && velXZ > 0.1 && abs(avgVelY) < STALL_THRESH) {
                stallTick++
            } else {
                stallTick = 0
            }

            if (stallTick >= HISTORY_SIZE) {
                mc.networkHandler?.sendPacket(
                    PlayerMoveC2SPacket.PositionAndOnGround(
                        player.x,
                        player.y + 0.0005,
                        player.z,
                        false,
                        player.horizontalCollision
                    )
                )
                stallTick   = 0
                fixCooldown = 8
            }

            if (player.pitch > 60f && velXZ < 0.3) {
                val lv  = player.rotationVector
                val mag = sqrt(lv.x * lv.x + lv.y * lv.y + lv.z * lv.z)
                val scale = (0.04 / mag).coerceAtMost(0.05)
                player.velocity = player.velocity.add(lv.x * scale, lv.y * scale, lv.z * scale)
            }
        }

        wasFlying = isFlying
    }

    private fun reset() {
        wasFlying   = false
        stallTick   = 0
        fixCooldown = 0
        velYHistory.clear()
    }

    override fun onDisable() = reset()
}
