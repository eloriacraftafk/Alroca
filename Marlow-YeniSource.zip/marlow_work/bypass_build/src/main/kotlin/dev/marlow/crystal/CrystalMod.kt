package dev.marlow.crystal

import dev.marlow.crystal.module.ModuleManager
import dev.marlow.crystal.gui.CrystalHud
import net.fabricmc.api.ClientModInitializer
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback
import net.minecraft.client.MinecraftClient
import net.minecraft.client.util.InputUtil

object CrystalMod : ClientModInitializer {
    val mc: MinecraftClient get() = MinecraftClient.getInstance()

    // FIX: edge-detection map for module hotkeys.
    // ModuleManager.onKeyPress() was defined but never called from any event,
    // so all keybinds assigned in the GUI were silently ignored at runtime.
    // We track previous-frame key state here to fire toggle exactly once per press.
    private val keyPrevState = mutableMapOf<Int, Boolean>()

    override fun onInitializeClient() {
        ModuleManager.init()
        CrystalHud.init()

        ClientTickEvents.END_CLIENT_TICK.register { client ->
            ModuleManager.onTick()

            // Poll module hotkeys — edge-detect (unpressed → pressed) so each
            // physical keypress produces exactly one toggle regardless of how long
            // the key is held.
            val windowHandle = client.window?.handle ?: return@register
            ModuleManager.modules.forEach { mod ->
                val key = mod.key
                if (key == -1) return@forEach
                val nowDown = InputUtil.isKeyPressed(windowHandle, key)
                val wasDown = keyPrevState.getOrDefault(key, false)
                if (nowDown && !wasDown) {
                    ModuleManager.onKeyPress(key)
                }
                keyPrevState[key] = nowDown
            }
        }

        HudRenderCallback.EVENT.register { drawContext, _ ->
            CrystalHud.render(drawContext)
        }
    }
}
