package dev.marlow.crystal.module.impl

import dev.marlow.crystal.module.Module
import dev.marlow.crystal.module.ModuleManager
import dev.marlow.crystal.module.setting.BoolSetting
import dev.marlow.crystal.module.setting.FloatSetting
import dev.marlow.crystal.module.setting.GrimMouseSimulator
import dev.marlow.crystal.module.setting.Randomizer
import net.minecraft.entity.LivingEntity
import net.minecraft.entity.player.PlayerEntity
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket
import net.minecraft.util.Hand
import net.minecraft.util.math.MathHelper
import kotlin.math.*

/**
 * AttackAura — Grim 2.0 bypass edition
 *
 * Grim detection surfaces patched:
 *
 * [1] Reach / Hitboxes
 *     Range cap stays at 3.0 (vanilla survival interaction range). Grim's threshold
 *     is 3.0 + its configured threshold (0.0005 default) + movement allowance.
 *     3.0 is clean; no change needed.
 *
 * [2] MultiInteractA (multiple targets in one tick)
 *     Original code: one target per tick, one attack. Clean. Preserved.
 *
 * [3] Rotation sent before attack (rotate=true path)
 *     Original: calcAngles() snapped to raw float atan2 output — no GCD quantisation.
 *     Grim's AimProcessor tracks ALL LookAndOnGround packets, including pre-attack
 *     rotations. If AimAssist is off, sudden angle jumps create a delta spike pattern
 *     distinct from GCD-quantised human movement.
 *     Fix: when rotate=true, snap the outgoing rotation through GrimMouseSimulator
 *     so the GCD divisor matches whatever AimAssist has been conditioning, keeping
 *     the mode bucket coherent. If AimAssist is not enabled, still snap to avoid
 *     producing an unquantised outlier in the sample window.
 *
 * [4] InvalidInteractTarget / InvalidInteractCursor
 *     We attack via interactionManager.attackEntity() which Fabric routes through
 *     the standard pipeline. No manual packet crafting — these checks stay clean.
 *
 * [5] BadPacketsJ (UseItem rotation mismatch)
 *     Not triggered — we send no UseItem packets in this module.
 */
class AttackAura : Module("AttackAura", "Auto attacks nearest entity in range") {

    val range  = FloatSetting("Range",  3.0f, 1.0f, 3.2f)
    val rotate = BoolSetting("Rotate", true)

    private var lastSwing = 0L
    private var nextDelay = 0L

    override fun onEnable() { scheduleDelay() }

    private fun scheduleDelay() {
        nextDelay = Randomizer.gaussianLong(55L, 95L)
    }

    override fun onTick(player: PlayerEntity) {
        if (!enabled) return
        val world = mc.world ?: return
        val now   = System.currentTimeMillis()

        val cd = player.getAttackCooldownProgress(mc.getRenderTickCounter().getTickProgress(false))
        if (cd < 0.98f) return
        if (now - lastSwing < nextDelay) return

        val target = world.entities
            .filterIsInstance<LivingEntity>()
            .filter { it != player && it.isAlive && dist(player, it) <= range.value }
            .minByOrNull { dist(player, it) } ?: return

        if (rotate.value) {
            val (rawYaw, rawPitch) = calcAngles(player, target)
            // === Grim bypass: quantise pre-attack rotation through GrimMouseSimulator ===
            // This keeps the GCD divisor distribution consistent with AimAssist's output.
            // Without this, an unquantised rotation spike in the AimProcessor's 80-tick
            // window skews the mode bucket and can expose the aimbot pattern.
            val snappedYaw   = GrimMouseSimulator.snap(rawYaw)
            val snappedPitch = GrimMouseSimulator.snap(MathHelper.clamp(rawPitch, -90f, 90f))
            mc.networkHandler?.sendPacket(
                PlayerMoveC2SPacket.LookAndOnGround(
                    snappedYaw, snappedPitch,
                    player.isOnGround, player.horizontalCollision
                )
            )
        }

        player.swingHand(Hand.MAIN_HAND)
        mc.interactionManager?.attackEntity(player, target)

        lastSwing = now
        scheduleDelay()
    }

    private fun calcAngles(player: PlayerEntity, target: LivingEntity): Pair<Float, Float> {
        val dx = target.x - player.x
        val dy = target.eyeY - player.eyeY
        val dz = target.z - player.z
        val hDist = sqrt(dx * dx + dz * dz)
        val yaw   = Math.toDegrees(atan2(dz, dx)).toFloat() - 90f
        val pitch = -Math.toDegrees(atan2(dy, hDist)).toFloat()
        return Pair(yaw, MathHelper.clamp(pitch, -90f, 90f))
    }

    private fun dist(a: PlayerEntity, b: LivingEntity): Double {
        val dx = a.x - b.x; val dy = a.y - b.y; val dz = a.z - b.z
        return sqrt(dx * dx + dy * dy + dz * dz)
    }
}
