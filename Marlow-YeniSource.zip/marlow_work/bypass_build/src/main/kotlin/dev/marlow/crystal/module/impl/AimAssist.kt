package dev.marlow.crystal.module.impl

import dev.marlow.crystal.module.Module
import dev.marlow.crystal.module.setting.FloatSetting
import dev.marlow.crystal.module.setting.GrimMouseSimulator
import dev.marlow.crystal.module.setting.Randomizer
import net.minecraft.entity.LivingEntity
import net.minecraft.entity.player.PlayerEntity
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket
import net.minecraft.util.math.MathHelper
import kotlin.math.*

/**
 * AimAssist — Grim 2.0 bypass edition
 *
 * Grim detection surfaces patched:
 *
 * [1] AimProcessor / GCD analysis
 *     Grim tracks the GCD of consecutive rotation deltas across 80 ticks.
 *     If a single divisor dominates >15 samples, it flags as aimbot pattern.
 *     Original code used snapToGrid(0.15f) — a fixed GCD step, trivially detected.
 *     Fix: GrimMouseSimulator.snap() uses a session-randomised sensitivity-derived
 *     step with per-call Gaussian noise so no divisor dominates the mode bucket.
 *
 * [2] AimDuplicateLook
 *     Grim flags if consecutive LookAndOnGround packets share identical yaw+pitch.
 *     Fix: GrimMouseSimulator.snap() always adds a sub-step fractional jitter so
 *     the float value drifts every tick even on stationary targets.
 *
 * [3] AimModulo360
 *     Flags yaw delta >320° when last delta was <30°.
 *     Fix: strength cap at 0.15 + smooth interpolation means maximum delta per tick
 *     is bounded well below 320°. No change needed beyond existing clamp.
 *
 * [4] BadPacketsD (pitch out of [-90,90])
 *     Already handled by MathHelper.clamp in original. Preserved.
 *
 * [5] Reach / Hitboxes
 *     AimAssist never attacks; it only adjusts look direction. No reach flag risk.
 */
class AimAssist : Module("AimAssist", "Smooth aim toward nearest entity") {

    val fov      = FloatSetting("FOV",      180f, 90f, 360f)
    val strength = FloatSetting("Strength", 0.07f, 0.01f, 0.15f)
    val range    = FloatSetting("Range",    6.0f,  1.0f, 20.0f)
    val jitter   = FloatSetting("Jitter",   0.25f, 0.0f, 0.8f)

    override fun onEnable() {
        // New session → new synthetic sensitivity so GCD history resets coherently
        GrimMouseSimulator.resetSession()
    }

    override fun onTick(player: PlayerEntity) {
        if (!enabled) return
        val world = mc.world ?: return

        val target = world.entities
            .filterIsInstance<LivingEntity>()
            .filter { it != player && it.isAlive && it.distanceTo(player) <= range.value }
            .filter { isInFov(player, it) }
            .minByOrNull { it.distanceTo(player) } ?: return

        val eyePos = player.eyePos
        val tPos   = target.eyePos
        val dx = tPos.x - eyePos.x
        val dy = tPos.y - eyePos.y
        val dz = tPos.z - eyePos.z
        val hDist  = sqrt(dx * dx + dz * dz)

        val tYaw   = Math.toDegrees(atan2(dz, dx)).toFloat() - 90f
        val tPitch = -Math.toDegrees(atan2(dy, hDist)).toFloat()

        val dYaw   = MathHelper.wrapDegrees(tYaw - player.yaw)
        val dPitch = MathHelper.wrapDegrees(tPitch - player.pitch)

        // Human-noise jitter — same as before
        val jY = Randomizer.jitterF(jitter.value)
        val jP = Randomizer.jitterF(jitter.value * 0.5f)

        var newYaw   = player.yaw   + dYaw   * strength.value + jY
        var newPitch = player.pitch + dPitch * strength.value + jP
        newPitch = MathHelper.clamp(newPitch, -90f, 90f)

        // === Grim bypass: GrimMouseSimulator instead of fixed snapToGrid(0.15f) ===
        // GrimMouseSimulator.snap() uses a session-randomised, noise-perturbed GCD
        // step derived from vanilla sensitivity math so Grim's mode bucket never fills.
        newYaw   = GrimMouseSimulator.snap(newYaw)
        newPitch = GrimMouseSimulator.snap(newPitch)
        // Clamp again after snap — snap adds tiny jitter that stays well within range
        newPitch = MathHelper.clamp(newPitch, -90f, 90f)

        player.yaw   = newYaw
        player.pitch = newPitch

        mc.networkHandler?.sendPacket(
            PlayerMoveC2SPacket.LookAndOnGround(newYaw, newPitch, player.isOnGround, player.horizontalCollision)
        )
    }

    private fun isInFov(player: PlayerEntity, entity: LivingEntity): Boolean {
        if (fov.value >= 360f) return true
        val dx = entity.x - player.x
        val dz = entity.z - player.z
        val angleToEntity = Math.toDegrees(atan2(dz, dx)).toFloat() - 90f
        val diff = abs(MathHelper.wrapDegrees(angleToEntity - player.yaw))
        return diff <= fov.value / 2f
    }
}
