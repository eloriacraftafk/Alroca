plugins {
    kotlin("jvm") version "2.0.21"
    // FIX: 1.13.6 → 1.14-SNAPSHOT
    // 1.21.11 unpick v3 formatını gerektirir; 1.13.6 bunu desteklemiyor
    // Fabric ekosisteminde -SNAPSHOT bu serinin stabil sürümüdür
    id("fabric-loom") version "1.14-SNAPSHOT"
}

version = "1.0.0"
group = "dev.marlow.crystal"

repositories {
    mavenCentral()
    maven("https://maven.fabricmc.net/")
}

dependencies {
    minecraft("com.mojang:minecraft:1.21.11")
    // FIX: build.2 → build.4 (en güncel yarn mappings for 1.21.11)
    mappings("net.fabricmc:yarn:1.21.11+build.4:v2")
    modImplementation("net.fabricmc:fabric-loader:0.16.9")
    modImplementation("net.fabricmc.fabric-api:fabric-api:0.141.5+1.21.11")
    modImplementation("net.fabricmc:fabric-language-kotlin:1.12.3+kotlin.2.0.21")
}

tasks.processResources {
    inputs.property("version", project.version)
    filesMatching("fabric.mod.json") {
        expand(mapOf("version" to project.version))
    }
}

tasks.withType<org.jetbrains.kotlin.gradle.tasks.KotlinCompile> {
    kotlinOptions.jvmTarget = "21"
}
