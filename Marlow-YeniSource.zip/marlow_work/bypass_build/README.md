# Marlow's Crystal Optimizer

Fabric mod for Minecraft 1.21.11 — Crystal PvP utility.

## Modüller & Hotkey'ler

| Modül | Key | Açıklama |
|---|---|---|
| TriggerBot | J | Crosshair'deki hedefe otomatik vurur |
| AimAssist | K | En yakın hedefe smooth aim |
| AttackAura | R | Range içindeki hedefe aura saldırısı |
| FireworkSwap | F | Elytra uçuşunda firework slot'a geçer |
| ElyFix | G | Elytra uçuşu kesilince otomatik tekrar başlatır |
| TargetEsp | T | Aktif hedefe 2D box çizer |

**INSERT** — menüyü aç/kapat

## Build

```bash
./gradlew build
```

Çıktı: `build/libs/marlows-crystal-optimizer-1.0.0.jar`

## Gereksinimler

- Java 21
- Fabric Loader 0.15.11+
- Fabric API 0.100.1+1.21.11
- fabric-language-kotlin 1.10.19+kotlin.1.9.23
