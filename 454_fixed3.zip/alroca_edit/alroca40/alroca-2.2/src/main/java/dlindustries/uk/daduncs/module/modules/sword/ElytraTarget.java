/*
 * Patch: ElytraTarget — Bypass hardening
 * Changes:
 *   1. Velocity is written via setVelocity only when delta > 0.02 m/tick —
 *      zero-delta writes are ElytraFly/teleport flags on NCP and Vulcan.
 *   2. Per-tick speed is capped to Vanilla max glide velocity (~1.8 m/tick
 *      horizontal) so Matrix ElytraSpeed doesn't fire even at speed=3.0.
 *      Above vanilla cap the vector is rescaled, not clamped, preserving
 *      direction.
 *   3. setYaw/setPitch after velocity write uses GCD quantization so
 *      concurrent RotationSmooth + ElytraFly doesn't double-fire.
 *   4. onTick bails early when AntibanbyDaduncs.isActionSent() — no rotation
 *      overwrite after a crystal/mace action in the same tick.
 */

package dlindustries.uk.daduncs.module.modules.sword;

import dlindustries.uk.daduncs.Alroca;
import dlindustries.uk.daduncs.event.events.TickListener;
import dlindustries.uk.daduncs.managers.AntibanbyDaduncs;
import dlindustries.uk.daduncs.module.Category;
import dlindustries.uk.daduncs.module.Module;
import dlindustries.uk.daduncs.module.setting.bool;
import dlindustries.uk.daduncs.module.setting.number;
import dlindustries.uk.daduncs.utils.EncryptedString;
import dlindustries.uk.daduncs.utils.RotationUtils;
import dlindustries.uk.daduncs.utils.rotation.Rotation;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

public final class ElytraTarget extends Module implements TickListener {

    private final number range = new number(EncryptedString.of("Range"), 5, 80, 40, 1)
            .setDescription(EncryptedString.of("Max distance to pick a target"));
    private final number radius = new number(EncryptedString.of("Radius"), 2, 12, 4, 0.5)
            .setDescription(EncryptedString.of("Circle radius around the target"));
    private final number height = new number(EncryptedString.of("Height"), -3, 6, 0.5, 0.5)
            .setDescription(EncryptedString.of("Height offset above the target"));
    private final number speed = new number(EncryptedString.of("Speed"), 0.3, 3, 1, 0.1)
            .setDescription(EncryptedString.of("Flying speed around the target"));
    private final bool overtake = new bool(EncryptedString.of("Overtake"), false)
            .setDescription(EncryptedString.of("Flies ahead of the target in the direction it is moving"));
    private final number overtakeDistance = new number(EncryptedString.of("Overtake Distance"), 1, 20, 6, 1)
            .setDescription(EncryptedString.of("How far ahead of the target to circle"))
            .setVisibility(overtake::getValue);
    private final bool follow = new bool(EncryptedString.of("Follow"), true)
            .setDescription(EncryptedString.of("Chase the target when it flies away"));
    private final bool friendSafe = new bool(EncryptedString.of("Friend Safe"), true)
            .setDescription(EncryptedString.of("Never targets your friends"));

    private PlayerEntity lastTarget;
    private Vec3d lastTargetPos;
    private Vec3d targetMotion = Vec3d.ZERO;

    // GCD carry for rotation quantization
    private final double[] gcdRemainder = {0.0, 0.0};

    // Bypass: Vanilla elytra max horizontal speed ≈ 1.8 m/tick at pitch -30°.
    // Exceeding this triggers ElytraSpeed on Matrix 6.9+ and NCP SurvFly.
    private static final double MAX_HORIZONTAL_SPEED = 1.78;
    // Bypass: skip velocity write if delta below this — avoids ElytraFly/teleport flag.
    private static final double MIN_VELOCITY_DELTA   = 0.02;

    public ElytraTarget() {
        super(EncryptedString.of("Elytra Target"),
                EncryptedString.of("Flies around the nearest player in a perfect circle while you glide with an elytra"),
                -1,
                Category.SWORD);
        addSettings(range, radius, height, speed, overtake, overtakeDistance, follow, friendSafe);
    }

    @Override
    public void onEnable() {
        eventManager.add(TickListener.class, this);
        lastTarget = null;
        lastTargetPos = null;
        targetMotion = Vec3d.ZERO;
        super.onEnable();
    }

    @Override
    public void onDisable() {
        eventManager.remove(TickListener.class, this);
        super.onDisable();
    }

    private PlayerEntity findTarget() {
        PlayerEntity best = null;
        double bestDistance = range.getValue();

        for (PlayerEntity player : mc.world.getPlayers()) {
            if (player == mc.player || !player.isAlive() || player.isSpectator())
                continue;

            if (friendSafe.getValue() && Alroca.INSTANCE.getFriendManager().isFriend(player))
                continue;

            double distance = mc.player.distanceTo(player);

            if (distance <= bestDistance) {
                bestDistance = distance;
                best = player;
            }
        }

        return best;
    }

    @Override
    public void onTick() {
        if (mc.player == null || mc.world == null || mc.currentScreen != null)
            return;

        if (!mc.player.isGliding())
            return;

        // Bypass: skip rotation overwrite if another action fired this tick —
        // concurrent setYaw after attackEntity is a MultiAction signal on Vulcan.
        if (AntibanbyDaduncs.isActionSent())
            return;

        PlayerEntity target = findTarget();
        if (target == null)
            return;

        Vec3d me = mc.player.getEntityPos();
        Vec3d tp = target.getEntityPos();

        if (target != lastTarget || lastTargetPos == null) {
            lastTarget = target;
            targetMotion = Vec3d.ZERO;
        } else {
            targetMotion = targetMotion.multiply(0.5).add(tp.subtract(lastTargetPos).multiply(0.5));
        }
        lastTargetPos = tp;

        if (overtake.getValue()) {
            Vec3d flatMotion = new Vec3d(targetMotion.x, 0, targetMotion.z);
            if (flatMotion.lengthSquared() > 0.0025)
                tp = tp.add(flatMotion.normalize().multiply(overtakeDistance.getValue()));
        }

        tp = tp.add(targetMotion);

        double dx = me.x - tp.x;
        double dz = me.z - tp.z;
        double flat = Math.sqrt(dx * dx + dz * dz);
        double r = radius.getValue();
        double v = speed.getValue();

        Vec3d next;

        if (follow.getValue() && flat > r * 3) {
            Vec3d toTarget = new Vec3d(tp.x - me.x, tp.y + height.getValue() - me.y, tp.z - me.z).normalize();
            next = me.add(toTarget.multiply(v));
        } else {
            double angle = Math.atan2(dz, dx) + v / r;
            double nextRadius = flat + MathHelper.clamp(r - flat, -1.0, 1.0);
            double nextY = me.y + MathHelper.clamp(tp.y + height.getValue() - me.y, -0.5, 0.5);
            next = new Vec3d(tp.x + Math.cos(angle) * nextRadius, nextY, tp.z + Math.sin(angle) * nextRadius);
        }

        Vec3d move = next.subtract(me);

        // Original hard-cap preserved; also apply vanilla horizontal cap.
        if (move.length() > 3.0)
            move = move.normalize().multiply(3.0);

        // Bypass: rescale horizontal component to vanilla ceiling.
        double hLen = Math.sqrt(move.x * move.x + move.z * move.z);
        if (hLen > MAX_HORIZONTAL_SPEED) {
            double scale = MAX_HORIZONTAL_SPEED / hLen;
            move = new Vec3d(move.x * scale, move.y, move.z * scale);
        }

        // Bypass: skip write if change is negligible — zero-delta velocity
        // sets are themselves a flag on some anticheats (ElytraFly:static).
        Vec3d currentVelocity = mc.player.getVelocity();
        if (move.distanceTo(currentVelocity) > MIN_VELOCITY_DELTA) {
            mc.player.setVelocity(move);
        }

        // Bypass: GCD-quantized rotation to avoid AimPattern alongside ElytraFly.
        Rotation raw = RotationUtils.getDirection(mc.player.getEyePos(), mc.player.getEyePos().add(move));
        Rotation quantized = RotationUtils.applyGCD(
                mc.player.getYaw(), mc.player.getPitch(),
                (float) raw.yaw(), (float) raw.pitch(),
                gcdRemainder, true);

        mc.player.setYaw((float) quantized.yaw());
        mc.player.setPitch((float) quantized.pitch());
    }
}
