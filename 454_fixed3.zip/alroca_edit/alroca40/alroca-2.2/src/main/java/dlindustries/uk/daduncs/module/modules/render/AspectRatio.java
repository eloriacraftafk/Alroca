/*
 * This file is part of System Client (https://github.com/daduncs/system)
 * Website: https://download.daduncs.cloud/
 *
 * Copyright (c) 2024 - 2026 DLindustries and project contributors.
 *
 * System Client is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * System Client is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with System Client. If not, see <https://www.gnu.org/licenses/>.
 */

package dlindustries.uk.daduncs.module.modules.render;

import dlindustries.uk.daduncs.module.Category;
import dlindustries.uk.daduncs.module.Module;
import dlindustries.uk.daduncs.module.setting.mode;
import dlindustries.uk.daduncs.utils.EncryptedString;

public final class AspectRatio extends Module {

    public enum Ratio {
        // İsimler GUI'de görünür
        R16_9, R16_10, R4_3
    }

    public final mode<Ratio> ratio = new mode<>(EncryptedString.of("Ratio"), Ratio.R16_9, Ratio.class);

    public AspectRatio() {
        super(EncryptedString.of("Aspect Ratio"),
                EncryptedString.of("Ekranın görüntü oranını değiştirir (16:9, 16:10, 4:3)"),
                -1,
                Category.RENDER);
        addSettings(ratio);
    }

    // Aktif oran değerini döndürür — mixin buradan okur
    public float getRatioValue() {
        return switch (ratio.getMode()) {
            case R16_9  -> 16f / 9f;
            case R16_10 -> 16f / 10f;
            case R4_3   -> 4f / 3f;
        };
    }
}
