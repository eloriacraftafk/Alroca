/*
 * This file is part of System Client (https://github.com/daduncs/system)
 * Website: https://download.daduncs.cloud/
 *
 * Copyright (c) 2024 - 2026 DLindustries and project contributors.
 *
 * System Client is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * System Client is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with System Client. If not, see <https://www.gnu.org/licenses/>.
 */

package dlindustries.uk.daduncs.gui;

import dlindustries.uk.daduncs.render.Draw;
import dlindustries.uk.daduncs.render.Render2D;
import dlindustries.uk.daduncs.utils.TextRenderer;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.util.Identifier;

import java.time.LocalTime;
import java.time.format.DateTimeFormatter;

import static dlindustries.uk.daduncs.c454.mc;

public final class Watermark {

    // c454 logo icon (same namespace as the rest of the project)
    private static final Identifier LOGO = Identifier.of("c454", "textures/gui/client_icon.png");

    // Icon set — reuse existing UI icons from the project
    private static final Identifier ICON_PLAYER  = Identifier.of("c454", "textures/gui/client_icon.png");
    private static final Identifier ICON_FPS     = Identifier.of("c454", "textures/gui/client_icon.png");
    private static final Identifier ICON_CLOCK   = Identifier.of("c454", "textures/gui/client_icon.png");
    private static final Identifier ICON_COORDS  = Identifier.of("c454", "textures/gui/client_icon.png");
    private static final Identifier ICON_SIGNAL  = Identifier.of("c454", "textures/gui/client_icon.png");
    private static final Identifier ICON_TICKS   = Identifier.of("c454", "textures/gui/client_icon.png");
    private static final Identifier ICON_BPS     = Identifier.of("c454", "textures/gui/client_icon.png");

    // Layout constants (matches screenshot proportions)
    private static final int PAD_X     = 4;   // screen edge padding
    private static final int PAD_Y     = 4;
    private static final int ROW_H     = 14;  // height of each row
    private static final int ROW_GAP   = 2;   // gap between row 1 and row 2
    private static final int ICON_SIZE = 8;   // icon width/height
    private static final int ICON_GAP  = 3;   // gap between icon and text
    private static final int SEP_W     = 1;   // separator width
    private static final int COL_GAP   = 8;   // gap between columns (around separator)
    private static final int CORNER    = 4f == 4f ? 4 : 4; // rounded corner radius
    private static final float BG_ALPHA = 0.55f;

    private static final DateTimeFormatter TIME_FMT = DateTimeFormatter.ofPattern("HH:mm:ss");

    private Watermark() {}

    /**
     * Call this from your HUD render event (e.g. inside InGameHudMixin or a HudListener).
     */
    public static void render(DrawContext context) {
        if (mc == null || mc.player == null || mc.world == null) return;

        Draw.warmup(context);

        // ── Collect data ──────────────────────────────────────────────
        String clientName = "c454";
        String nickname   = mc.player.getGameProfile().getName();
        int    fps        = MinecraftClient.currentFps;
        String time       = LocalTime.now().format(TIME_FMT);

        int    posX       = (int) mc.player.getX();
        int    posY       = (int) mc.player.getY();
        int    posZ       = (int) mc.player.getZ();
        String coords     = posX + ", " + posY + ", " + posZ;

        int ping = 0;
        if (mc.getNetworkHandler() != null) {
            PlayerListEntry entry = mc.getNetworkHandler().getPlayerListEntry(mc.player.getUuid());
            if (entry != null) ping = entry.getLatency();
        }

        double tps   = mc.world.getTickManager().getTickRate();  // 20.0 normally
        double bps   = 0.0; // bytes-per-second; wire this up to your network tracker if available

        // ── Build text segments ───────────────────────────────────────
        // Row 1: [logo] c454  |  👤 nickname  |  📈 fps Fps  |  🕐 time
        // Row 2: 📍 x, y, z  |  📶 ping Ping  |  ⏱ tps Ticks  |  📡 bps Bps

        String txtFps    = fps + " Fps";
        String txtPing   = ping + " Ping";
        String txtTicks  = String.format("%.1f Ticks", tps);
        String txtBps    = String.format("%.1f Bps", bps);

        // ── Measure widths ────────────────────────────────────────────
        int wLogo     = ICON_SIZE;
        int wClient   = TextRenderer.smallWidth(clientName);
        int wNick     = TextRenderer.smallWidth(nickname);
        int wFps      = TextRenderer.smallWidth(txtFps);
        int wTime     = TextRenderer.smallWidth(time);

        int wCoords   = TextRenderer.smallWidth(coords);
        int wPing     = TextRenderer.smallWidth(txtPing);
        int wTicks    = TextRenderer.smallWidth(txtTicks);
        int wBps      = TextRenderer.smallWidth(txtBps);

        // Row widths = icon + gap + text, joined by separators
        int sepSlot   = SEP_W + COL_GAP * 2; // space taken by one " | " separator

        int row1W = PAD_X
                + wLogo + ICON_GAP + wClient
                + sepSlot + ICON_SIZE + ICON_GAP + wNick
                + sepSlot + ICON_SIZE + ICON_GAP + wFps
                + sepSlot + ICON_SIZE + ICON_GAP + wTime
                + PAD_X;

        int row2W = PAD_X
                + ICON_SIZE + ICON_GAP + wCoords
                + sepSlot + ICON_SIZE + ICON_GAP + wPing
                + sepSlot + ICON_SIZE + ICON_GAP + wTicks
                + sepSlot + ICON_SIZE + ICON_GAP + wBps
                + PAD_X;

        int totalW = Math.max(row1W, row2W);
        int totalH = PAD_Y + ROW_H + ROW_GAP + ROW_H + PAD_Y;

        int bgX = PAD_X;
        int bgY = PAD_Y;

        // ── Draw background ───────────────────────────────────────────
        Render2D.drawBlurRoundRect(context,
                bgX, bgY, totalW, totalH,
                CORNER, 1f,
                Theme.BLUR * BG_ALPHA,
                Theme.fade(0xC0141414, BG_ALPHA),
                BG_ALPHA);

        // ── Draw Row 1 ────────────────────────────────────────────────
        int textY1 = bgY + PAD_Y + (ROW_H - TextRenderer.smallHeight()) / 2;
        int iconY1 = bgY + PAD_Y + (ROW_H - ICON_SIZE) / 2;
        int x = bgX + PAD_X;

        // [c454 logo]
        Render2D.drawRoundImage(context, x, iconY1, ICON_SIZE, ICON_SIZE, 1f,
                LOGO, Theme.fade(Theme.text, 1f));
        x += ICON_SIZE + ICON_GAP;

        // "c454"
        TextRenderer.drawSmall(clientName, context, x, textY1, Theme.fade(Theme.text, 1f));
        x += wClient;

        // separator
        x += COL_GAP;
        Render2D.drawRoundRect(context, x, bgY + PAD_Y + 2, SEP_W, ROW_H - 4, 0.5f,
                Theme.fade(Theme.muted, 0.4f));
        x += SEP_W + COL_GAP;

        // 👤 nickname
        Render2D.drawRoundImage(context, x, iconY1, ICON_SIZE, ICON_SIZE, 1f,
                ICON_PLAYER, Theme.fade(Theme.muted, 0.9f));
        x += ICON_SIZE + ICON_GAP;
        TextRenderer.drawSmall(nickname, context, x, textY1, Theme.fade(Theme.text, 1f));
        x += wNick;

        // separator
        x += COL_GAP;
        Render2D.drawRoundRect(context, x, bgY + PAD_Y + 2, SEP_W, ROW_H - 4, 0.5f,
                Theme.fade(Theme.muted, 0.4f));
        x += SEP_W + COL_GAP;

        // 📈 fps
        Render2D.drawRoundImage(context, x, iconY1, ICON_SIZE, ICON_SIZE, 1f,
                ICON_FPS, Theme.fade(Theme.muted, 0.9f));
        x += ICON_SIZE + ICON_GAP;
        TextRenderer.drawSmall(txtFps, context, x, textY1, Theme.fade(Theme.text, 1f));
        x += wFps;

        // separator
        x += COL_GAP;
        Render2D.drawRoundRect(context, x, bgY + PAD_Y + 2, SEP_W, ROW_H - 4, 0.5f,
                Theme.fade(Theme.muted, 0.4f));
        x += SEP_W + COL_GAP;

        // 🕐 time
        Render2D.drawRoundImage(context, x, iconY1, ICON_SIZE, ICON_SIZE, 1f,
                ICON_CLOCK, Theme.fade(Theme.muted, 0.9f));
        x += ICON_SIZE + ICON_GAP;
        TextRenderer.drawSmall(time, context, x, textY1, Theme.fade(Theme.text, 1f));

        // ── Draw Row 2 ────────────────────────────────────────────────
        int textY2 = bgY + PAD_Y + ROW_H + ROW_GAP + (ROW_H - TextRenderer.smallHeight()) / 2;
        int iconY2 = bgY + PAD_Y + ROW_H + ROW_GAP + (ROW_H - ICON_SIZE) / 2;
        x = bgX + PAD_X;

        // 📍 coords
        Render2D.drawRoundImage(context, x, iconY2, ICON_SIZE, ICON_SIZE, 1f,
                ICON_COORDS, Theme.fade(Theme.muted, 0.9f));
        x += ICON_SIZE + ICON_GAP;
        TextRenderer.drawSmall(coords, context, x, textY2, Theme.fade(Theme.text, 1f));
        x += wCoords;

        // separator
        x += COL_GAP;
        Render2D.drawRoundRect(context, x, bgY + PAD_Y + ROW_H + ROW_GAP + 2, SEP_W, ROW_H - 4, 0.5f,
                Theme.fade(Theme.muted, 0.4f));
        x += SEP_W + COL_GAP;

        // 📶 ping
        Render2D.drawRoundImage(context, x, iconY2, ICON_SIZE, ICON_SIZE, 1f,
                ICON_SIGNAL, Theme.fade(Theme.muted, 0.9f));
        x += ICON_SIZE + ICON_GAP;
        TextRenderer.drawSmall(txtPing, context, x, textY2, Theme.fade(Theme.text, 1f));
        x += wPing;

        // separator
        x += COL_GAP;
        Render2D.drawRoundRect(context, x, bgY + PAD_Y + ROW_H + ROW_GAP + 2, SEP_W, ROW_H - 4, 0.5f,
                Theme.fade(Theme.muted, 0.4f));
        x += SEP_W + COL_GAP;

        // ⏱ ticks
        Render2D.drawRoundImage(context, x, iconY2, ICON_SIZE, ICON_SIZE, 1f,
                ICON_TICKS, Theme.fade(Theme.muted, 0.9f));
        x += ICON_SIZE + ICON_GAP;
        TextRenderer.drawSmall(txtTicks, context, x, textY2, Theme.fade(Theme.text, 1f));
        x += wTicks;

        // separator
        x += COL_GAP;
        Render2D.drawRoundRect(context, x, bgY + PAD_Y + ROW_H + ROW_GAP + 2, SEP_W, ROW_H - 4, 0.5f,
                Theme.fade(Theme.muted, 0.4f));
        x += SEP_W + COL_GAP;

        // 📡 bps
        Render2D.drawRoundImage(context, x, iconY2, ICON_SIZE, ICON_SIZE, 1f,
                ICON_BPS, Theme.fade(Theme.muted, 0.9f));
        x += ICON_SIZE + ICON_GAP;
        TextRenderer.drawSmall(txtBps, context, x, textY2, Theme.fade(Theme.text, 1f));
    }
}
