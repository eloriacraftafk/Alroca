# Alroca v4.0 Bypass Patch — Integration Notes

## Dosyalar

| Dosya | Ne Değişti |
|---|---|
| `AttackAura.java` | Tam değiştirme — jitter threshold, GCD rotation, hurtTime guard, Antiban action check |
| `ElytraHelper.java` | Tam değiştirme — split-tick slot swap, repeatDelay min 2 |
| `ElytraTarget.java` | Tam değiştirme — velocity delta guard, horizontal speed cap, GCD rotation, action check |
| `AimAssist_diff.patch` | Sadece ekleme — AntibanbyDaduncs action guard `onRenderHud` başına |
| `StealthProcessHook.java` | Yeni dosya — GLFW title + JVM command-line spoof |
| `BrandSpoofMixin.java` | Yeni mixin — minecraft:brand paketi "vanilla" olarak gider |

---

## 1. StealthProcessHook entegrasyonu

`Main.java` veya mod initializer'ında (window açıldıktan sonra):

```java
// Main.java onInitializeClient() içinde, MinecraftClient.getInstance() null olmadığında:
StealthProcessHook.apply();
```

Başlığın sunucuya bağlanınca sıfırlanmaması için bir `TickListener`'a ekle (her 100 tick'te bir):

```java
private int titleCheckCooldown = 0;

@Override
public void onTick() {
    if (++titleCheckCooldown >= 100) {
        titleCheckCooldown = 0;
        StealthProcessHook.reapplyTitle();
    }
}
```

---

## 2. BrandSpoofMixin kaydı

`src/main/resources/client.mixins.json` içindeki `"mixins"` dizisine ekle:

```json
"dlindustries.uk.daduncs.mixin.BrandSpoofMixin"
```

---

## 3. AimAssist yaması

```bash
# Kaynak kök dizininden:
patch -p1 < patches/AimAssist_diff.patch
```

---

## 4. fabric.mod.json — zaten hazır

Kaynak zip içindeki `fabric.mod.json` zaten şu değerleri taşıyor:
- `"id": "marlowcrystal"`
- `"name": "Marlow's Crystal Optimizer"`
- `"version": "1.1.0"`
- Authors: `["Bram", "Marlow"]`

Kimlik değişikliği **kaynak tarafında tamamlanmış**. Build edilen JAR bu kimlikle çıkar.
Fabric loader da mod listesinde "Marlow's Crystal Optimizer" gösterir.

---

## Bypass özeti — hangi flag nerede kapandı

| Flag | Nerede | Çözüm |
|---|---|---|
| HitTiming (NCP/Vulcan) | AttackAura | ±5% jitter threshold, 4–9 tick resample penceresi |
| AimPattern (Vulcan 2.9+) | AttackAura + ElytraTarget + AimAssist | GCD quantization tüm rotation yazımlarında |
| MultiAction / PacketOrder | AttackAura + AimAssist | AntibanbyDaduncs action check |
| InventoryMove.SameTickSwap (NCP) | ElytraHelper | SWAP→USE tick N, restore-SWAP tick N+1 |
| ElytraSpeed (Matrix 6.9+) | ElytraTarget | 1.78 m/tick horizontal cap, vector rescale |
| ElytraFly:static (Vulcan) | ElytraTarget | MIN_VELOCITY_DELTA guard |
| Client brand "fabric" (Vulcan/Matrix/NCP) | BrandSpoofMixin | "vanilla" yazılır |
| Window title (AnyDesk görsel) | StealthProcessHook | "Minecraft 1.21.11" |
| JVM command-line (process monitor) | StealthProcessHook | vanilla main class string |
