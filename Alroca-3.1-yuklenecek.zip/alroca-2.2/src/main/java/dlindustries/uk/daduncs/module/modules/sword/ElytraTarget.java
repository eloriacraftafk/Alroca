/*
 * This file is part of System Client (https://github.com/daduncs/system)
 * Website: https://download.daduncs.cloud/
 *
 * Copyright (c) 2024 - 2026 DLindustries and project contributors.
 *
 * System Client is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * System Client is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with System Client. If not, see <https://www.gnu.org/licenses/>.
 */

package dlindustries.uk.daduncs.module.modules.sword;

import dlindustries.uk.daduncs.Alroca;
import dlindustries.uk.daduncs.event.events.TickListener;
import dlindustries.uk.daduncs.module.Category;
import dlindustries.uk.daduncs.module.Module;
import dlindustries.uk.daduncs.module.setting.bool;
import dlindustries.uk.daduncs.module.setting.number;
import dlindustries.uk.daduncs.utils.EncryptedString;
import dlindustries.uk.daduncs.utils.InventoryUtils;
import dlindustries.uk.daduncs.utils.RotationUtils;
import dlindustries.uk.daduncs.utils.rotation.Rotation;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Items;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.util.Hand;
import net.minecraft.util.math.Vec3d;

public final class ElytraTarget extends Module implements TickListener {

	private final number range = new number(EncryptedString.of("Range"), 5, 80, 40, 1)
			.setDescription(EncryptedString.of("Max distance to pick a target"));
	private final number radius = new number(EncryptedString.of("Radius"), 2, 12, 4, 0.5)
			.setDescription(EncryptedString.of("Circle radius around the target"));
	private final number height = new number(EncryptedString.of("Height"), -3, 6, 0.5, 0.5)
			.setDescription(EncryptedString.of("Height offset above the target"));
	private final number orbitAngle = new number(EncryptedString.of("Orbit Angle"), 10, 90, 40, 5)
			.setDescription(EncryptedString.of("How far ahead on the circle to aim each tick"));
	private final bool follow = new bool(EncryptedString.of("Follow"), true)
			.setDescription(EncryptedString.of("Chase the target when it flies away"));
	private final bool attack = new bool(EncryptedString.of("Attack"), true)
			.setDescription(EncryptedString.of("Automatically hits the target when in range"));
	private final number attackRange = new number(EncryptedString.of("Attack Range"), 2.5, 6, 3, 0.1)
			.setDescription(EncryptedString.of("Distance to hit the target from"));
	private final number fireworkDelay = new number(EncryptedString.of("Firework Delay"), 1, 40, 8, 1)
			.setDescription(EncryptedString.of("Ticks between fireworks (20 ticks = 1 second)"));
	private final bool friendSafe = new bool(EncryptedString.of("Friend Safe"), true)
			.setDescription(EncryptedString.of("Never targets your friends"));

	private int fireworkTicks;

	public ElytraTarget() {
		super(EncryptedString.of("Elytra Target"),
				EncryptedString.of("Circles around the nearest player with an elytra, uses fireworks from your inventory and hits them"),
				-1,
				Category.SWORD);
		addSettings(range, radius, height, orbitAngle, follow, attack, attackRange, fireworkDelay, friendSafe);
	}

	@Override
	public void onEnable() {
		eventManager.add(TickListener.class, this);
		fireworkTicks = 0;
		super.onEnable();
	}

	@Override
	public void onDisable() {
		eventManager.remove(TickListener.class, this);
		super.onDisable();
	}

	private PlayerEntity findTarget() {
		PlayerEntity best = null;
		double bestDistance = range.getValue();

		for (PlayerEntity player : mc.world.getPlayers()) {
			if (player == mc.player || !player.isAlive() || player.isSpectator())
				continue;

			if (friendSafe.getValue() && Alroca.INSTANCE.getFriendManager().isFriend(player))
				continue;

			double distance = mc.player.distanceTo(player);

			if (distance <= bestDistance) {
				bestDistance = distance;
				best = player;
			}
		}

		return best;
	}

	@Override
	public void onTick() {
		if (mc.player == null || mc.world == null || mc.interactionManager == null || mc.currentScreen != null)
			return;

		if (!mc.player.isGliding())
			return;

		PlayerEntity target = findTarget();

		if (target == null)
			return;

		Vec3d me = mc.player.getEntityPos();
		Vec3d tp = target.getEntityPos();

		double dx = me.x - tp.x;
		double dz = me.z - tp.z;
		double flat = Math.sqrt(dx * dx + dz * dz);
		double r = radius.getValue();

		Vec3d aim;

		if (follow.getValue() && flat > r * 2.5)
			aim = target.getEyePos();
		else {
			double angle = Math.atan2(dz, dx) + Math.toRadians(orbitAngle.getValue());
			aim = new Vec3d(tp.x + Math.cos(angle) * r, tp.y + height.getValue(), tp.z + Math.sin(angle) * r);
		}

		Rotation rotation = RotationUtils.getDirection(mc.player.getEyePos(), aim);
		mc.player.setYaw((float) rotation.yaw());
		mc.player.setPitch((float) rotation.pitch());

		if (attack.getValue() && mc.player.distanceTo(target) <= attackRange.getValue()
				&& mc.player.getAttackCooldownProgress(0.5f) >= 0.95f) {
			mc.interactionManager.attackEntity(mc.player, target);
			mc.player.swingHand(Hand.MAIN_HAND);
		}

		fireworkTicks++;

		if (fireworkTicks >= fireworkDelay.getValueInt() && useFirework())
			fireworkTicks = 0;
	}

	private boolean useFirework() {
		int selected = mc.player.getInventory().getSelectedSlot();

		if (mc.player.getInventory().getStack(selected).isOf(Items.FIREWORK_ROCKET)) {
			mc.interactionManager.interactItem(mc.player, Hand.MAIN_HAND);
			return true;
		}

		for (int i = 0; i < 9; i++) {
			if (mc.player.getInventory().getStack(i).isOf(Items.FIREWORK_ROCKET)) {
				InventoryUtils.setInvSlot(i);
				mc.interactionManager.interactItem(mc.player, Hand.MAIN_HAND);
				InventoryUtils.setInvSlot(selected);
				return true;
			}
		}

		for (int i = 9; i < 36; i++) {
			if (mc.player.getInventory().getStack(i).isOf(Items.FIREWORK_ROCKET)) {
				mc.interactionManager.clickSlot(mc.player.playerScreenHandler.syncId, i, selected, SlotActionType.SWAP, mc.player);
				mc.interactionManager.interactItem(mc.player, Hand.MAIN_HAND);
				mc.interactionManager.clickSlot(mc.player.playerScreenHandler.syncId, i, selected, SlotActionType.SWAP, mc.player);
				return true;
			}
		}

		return false;
	}
}
