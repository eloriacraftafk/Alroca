package dev.marlow.crystal.mixin;

import dev.marlow.crystal.module.Module;
import dev.marlow.crystal.module.ModuleManager;
import dev.marlow.crystal.module.impl.Velocity;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientPacketListener;
import net.minecraft.network.protocol.game.ClientboundSetEntityMotionPacket;
import net.minecraft.world.phys.Vec3;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ClientPacketListener.class)
public class MixinClientPacketListener {

    @Inject(method = "handleSetEntityMotion", at = @At("HEAD"), cancellable = true)
    private void onVelocity(ClientboundSetEntityMotionPacket packet, CallbackInfo ci) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null) return;
        if (packet.getId() != mc.player.getId()) return;

        Module mod = ModuleManager.INSTANCE.getByName("Velocity");
        if (!(mod instanceof Velocity vel) || !mod.isEnabled()) return;

        ci.cancel();
        Vec3 motion = packet.getMovement();
        Vec3 scaled = vel.scale(motion);
        mc.player.lerpMotion(scaled);
    }
}
