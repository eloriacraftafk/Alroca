package dev.marlow.crystal.gui;

import dev.marlow.crystal.license.LicenseManager;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

public class LicenseScreen extends Screen {

    private EditBox keyInput;
    private String message = "";
    private int messageColor = 0xFFFFFF;

    public LicenseScreen() {
        super(Component.literal("Crystal License"));
    }

    @Override
    protected void init() {
        keyInput = new EditBox(this.font, this.width / 2 - 100, this.height / 2 - 10,
                200, 20, Component.literal("Key"));
        keyInput.setMaxLength(19);
        keyInput.setHint(Component.literal("XXXX-XXXX-XXXX-XXXX"));
        this.addRenderableWidget(keyInput);

        this.addRenderableWidget(Button.builder(Component.literal("Activate"), btn -> {
            String key = keyInput.getValue().trim();
            LicenseManager.Status s = LicenseManager.INSTANCE.activate(key);
            switch (s) {
                case VALID -> {
                    message = "✔ License activated!";
                    messageColor = 0x55FF55;
                    this.minecraft.setScreen(null);
                }
                case EXPIRED -> {
                    message = "✘ License expired!";
                    messageColor = 0xFF5555;
                }
                case INVALID -> {
                    message = "✘ Invalid key!";
                    messageColor = 0xFF5555;
                }
                default -> {
                    message = "✘ Error!";
                    messageColor = 0xFF5555;
                }
            }
        }).bounds(this.width / 2 - 50, this.height / 2 + 20, 100, 20).build());
    }

    @Override
    public void render(GuiGraphics g, int mx, int my, float delta) {
        this.renderBackground(g, mx, my, delta);

        // Başlık
        g.drawCenteredString(this.font, "§b§lCrystal §r§7License", this.width / 2, this.height / 2 - 40, 0xFFFFFF);
        g.drawCenteredString(this.font, "§7Enter your license key:", this.width / 2, this.height / 2 - 24, 0xAAAAAA);

        super.render(g, mx, my, delta);

        if (!message.isEmpty()) {
            g.drawCenteredString(this.font, message, this.width / 2, this.height / 2 + 46, messageColor);
        }
    }

    @Override
    public boolean shouldCloseOnEsc() { return false; }
}
