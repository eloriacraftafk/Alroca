package dev.marlow.crystal.license;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import java.nio.file.*;
import java.time.LocalDate;
import java.util.Base64;

public class LicenseManager {
    public static final LicenseManager INSTANCE = new LicenseManager();

    private static final String SECRET = "CrystalSecretKey2026!XY";
    private static final Path KEY_FILE = Paths.get(
            System.getProperty("user.home"), ".crystal_license.dat");

    public enum Status { VALID, EXPIRED, INVALID, NOT_FOUND }

    private boolean unlocked = false;

    public boolean isUnlocked() { return unlocked; }

    public Status activate(String key) {
        Status s = verify(key);
        if (s == Status.VALID) {
            try { Files.writeString(KEY_FILE, key.trim()); } catch (Exception ignored) {}
            unlocked = true;
        }
        return s;
    }

    public Status loadSaved() {
        if (!Files.exists(KEY_FILE)) return Status.NOT_FOUND;
        try {
            String key = Files.readString(KEY_FILE).trim();
            Status s = verify(key);
            if (s == Status.VALID) unlocked = true;
            return s;
        } catch (Exception e) {
            return Status.INVALID;
        }
    }

    public Status verify(String raw) {
        if (raw == null) return Status.INVALID;
        String key = raw.trim().toUpperCase();
        String[] parts = key.split("-");
        if (parts.length != 4) return Status.INVALID;
        for (String p : parts) if (p.length() != 4) return Status.INVALID;

        String payload = parts[0] + "-" + parts[1] + "-" + parts[2];
        String expectedSig = hmac4(payload);
        if (!parts[3].equals(expectedSig)) return Status.INVALID;

        if (parts[0].equals("PERM")) return Status.VALID;

        if (parts[0].startsWith("M") && parts[0].length() == 5) {
            try {
                int yy = Integer.parseInt(parts[0].substring(1, 3));
                int mm = Integer.parseInt(parts[0].substring(3, 5));
                LocalDate expiry = LocalDate.of(2000 + yy, mm, 1).plusMonths(1);
                if (LocalDate.now().isBefore(expiry)) return Status.VALID;
                else return Status.EXPIRED;
            } catch (Exception e) {
                return Status.INVALID;
            }
        }

        return Status.INVALID;
    }

    private String hmac4(String data) {
        try {
            Mac mac = Mac.getInstance("HmacSHA256");
            mac.init(new SecretKeySpec(SECRET.getBytes(), "HmacSHA256"));
            byte[] raw = mac.doFinal(data.getBytes());
            String b64 = Base64.getEncoder().encodeToString(raw)
                    .replaceAll("[^A-Z0-9]", "").toUpperCase();
            return b64.substring(0, 4);
        } catch (Exception e) {
            return "0000";
        }
    }
}
