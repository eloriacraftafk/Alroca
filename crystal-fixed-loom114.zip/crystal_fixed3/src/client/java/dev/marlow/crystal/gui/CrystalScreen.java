package dev.marlow.crystal.gui;

import dev.marlow.crystal.module.Module;
import dev.marlow.crystal.module.ModuleManager;
import dev.marlow.crystal.module.setting.BoolSetting;
import dev.marlow.crystal.module.setting.FloatSetting;
import dev.marlow.crystal.module.setting.IntSetting;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

public class CrystalScreen extends Screen {
    private int scrollOffset;

    public CrystalScreen() {
        super(Component.literal("Crystal Optimizer"));
    }

    @Override
    protected void init() {
        int y = 28 - scrollOffset;
        for (Module module : ModuleManager.INSTANCE.getModules()) {
            if (y > 28 && y < this.height - 28) {
                this.addRenderableWidget(Button.builder(
                        Component.literal(module.isEnabled() ? "[ON] " + module.getName() : "[OFF] " + module.getName()),
                        button -> {
                            module.toggle();
                            this.rebuildWidgets();
                        }
                ).bounds(this.width / 2 - 100, y, 200, 20).build());
            }
            y += 24;
        }
    }

    @Override
    public void render(GuiGraphics graphics, int mouseX, int mouseY, float delta) {
        this.renderBackground(graphics, mouseX, mouseY, delta);
        graphics.drawCenteredString(this.font, "Crystal Optimizer", this.width / 2, 8, 0xFFFFFF);
        super.render(graphics, mouseX, mouseY, delta);
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        scrollOffset = Math.max(0, scrollOffset - (int) (verticalAmount * 24));
        this.rebuildWidgets();
        return true;
    }
}