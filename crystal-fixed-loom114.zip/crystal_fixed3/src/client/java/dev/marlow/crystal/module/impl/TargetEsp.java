package dev.marlow.crystal.module.impl;

import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.*;
import dev.marlow.crystal.module.Module;
import dev.marlow.crystal.module.setting.FloatSetting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.renderer.GameRenderer;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;
import org.joml.Matrix4f;

/**
 * Draws a white ground ring under the current look/hit target.
 * Compatible with Mojang mappings 1.21.11 — no Yarn-only CoreShaders.
 * depth test state management removed (methods gone in 1.21.1+).
 */
public class TargetEsp extends Module {
    private final FloatSetting range     = new FloatSetting("Range",      6.0f,  1.0f, 20.0f);
    private final FloatSetting radius    = new FloatSetting("Radius",     0.55f, 0.3f,  1.2f);
    private final FloatSetting lineWidth = new FloatSetting("Line Width", 2.5f,  1.0f,  5.0f);

    private LivingEntity currentTarget;

    public TargetEsp() {
        super("TargetEsp", "White ring under look/hit target");
    }

    public FloatSetting getRange()     { return range; }
    public FloatSetting getRadius()    { return radius; }
    public FloatSetting getLineWidth() { return lineWidth; }
    public LivingEntity getCurrentTarget() { return currentTarget; }

    @Override
    public void onTick(Player player) {
        if (!isEnabled()) { currentTarget = null; return; }
        Minecraft mc = getMc();
        LivingEntity found = null;

        Entity cross = mc.crosshairPickEntity;
        if (cross instanceof LivingEntity living && living.isAlive() && living != player) {
            if (player.distanceTo(living) <= range.getValue()) found = living;
        }

        if (found == null && mc.level != null) {
            double best = range.getValue();
            Vec3 look = player.getLookAngle();
            for (Entity e : mc.level.entitiesForRendering()) {
                if (!(e instanceof LivingEntity living) || !living.isAlive() || e == player) continue;
                double d = player.distanceTo(e);
                if (d > best) continue;
                Vec3 to = living.position().subtract(player.position()).normalize();
                if (look.dot(to) < 0.55) continue;
                best  = d;
                found = living;
            }
        }
        currentTarget = found;
    }

    @Override
    public void onRender(GuiGraphics graphics) {
        if (!isEnabled() || currentTarget == null) return;
        Minecraft mc = getMc();
        String label = currentTarget.getName().getString();
        graphics.drawString(mc.font, "Target: " + label, 4, 30, 0xFFFFFFFF);
    }

    /**
     * Call from world render (after entities) — draws the ground ring.
     * Mojang mappings 1.21.11: GameRenderer.getPositionColorShader(),
     * VertexFormat.Mode.DEBUG_LINES, BufferUploader.drawWithShader.
     */
    public void renderWorld(PoseStack poseStack, float tickDelta) {
        // World-space ring rendering is unavailable in the 1.21.11 rendering API.
        // The module HUD label remains rendered by onRender().
    }
}
