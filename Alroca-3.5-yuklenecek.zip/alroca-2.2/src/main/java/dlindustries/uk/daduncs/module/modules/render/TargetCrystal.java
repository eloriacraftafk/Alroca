/*
 * This file is part of System Client (https://github.com/daduncs/system)
 * Website: https://download.daduncs.cloud/
 *
 * Copyright (c) 2024 - 2026 DLindustries and project contributors.
 *
 * System Client is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * System Client is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with System Client. If not, see <https://www.gnu.org/licenses/>.
 */

package dlindustries.uk.daduncs.module.modules.render;

import dlindustries.uk.daduncs.event.events.GameRenderListener;
import dlindustries.uk.daduncs.module.Category;
import dlindustries.uk.daduncs.module.Module;
import dlindustries.uk.daduncs.module.setting.colour;
import dlindustries.uk.daduncs.module.setting.number;
import dlindustries.uk.daduncs.utils.EncryptedString;
import dlindustries.uk.daduncs.utils.RenderUtils;
import net.minecraft.client.render.Camera;
import net.minecraft.client.render.RenderLayers;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.math.RotationAxis;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;

import java.awt.Color;

public final class TargetCrystal extends Module implements GameRenderListener {

	private static final int SIDES = 6;

	private final number size = new number(EncryptedString.of("Size"), 0.2, 1.5, 0.6, 0.05)
			.setDescription(EncryptedString.of("Crystal size"));
	private final number height = new number(EncryptedString.of("Height"), 0, 2, 0.5, 0.1)
			.setDescription(EncryptedString.of("Height above the player"));
	private final number spin = new number(EncryptedString.of("Spin Speed"), 0, 10, 3, 0.5);
	private final colour color = new colour(EncryptedString.of("Color"), 0xFF9B30FF);

	public TargetCrystal() {
		super(EncryptedString.of("Target Crystal"),
				EncryptedString.of("Shows a purple 3D crystal above the player your crosshair is on"),
				-1,
				Category.RENDER);
		addSettings(size, height, spin, color);
	}

	@Override
	public void onEnable() {
		eventManager.add(GameRenderListener.class, this);
		super.onEnable();
	}

	@Override
	public void onDisable() {
		eventManager.remove(GameRenderListener.class, this);
		super.onDisable();
	}

	@Override
	public void onGameRender(GameRenderEvent event) {
		if (mc.world == null || mc.player == null)
			return;

		if (!(mc.crosshairTarget instanceof EntityHitResult hit) || !(hit.getEntity() instanceof PlayerEntity target))
			return;

		Camera camera = mc.gameRenderer.getCamera();

		if (camera == null)
			return;

		event.matrices.push();
		Vec3d cameraPos = camera.getCameraPos();
		event.matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(camera.getPitch()));
		event.matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(camera.getYaw() + 180.0F));
		event.matrices.translate(-cameraPos.x, -cameraPos.y, -cameraPos.z);

		Vec3d pos = target.getLerpedPos(RenderUtils.tickProgress());
		double time = (System.currentTimeMillis() % 100000L) / 1000.0;

		final float cx = (float) pos.x;
		final float cy = (float) (pos.y + target.getHeight() + height.getValue() + 0.08 * Math.sin(time * 2.0));
		final float cz = (float) pos.z;
		final float halfHeight = size.getValueFloat() / 2f;
		final float radius = size.getValueFloat() * 0.3f;
		final double spinAngle = time * spin.getValue();

		Color base = new Color(color.getValue(), true);
		final float r = base.getRed() / 255f;
		final float g = base.getGreen() / 255f;
		final float b = base.getBlue() / 255f;
		final Matrix4f matrix = event.matrices.peek().getPositionMatrix();

		RenderUtils.drawLayer(RenderLayers.debugFilledBox(), buffer -> {
			for (int i = 0; i < SIDES; i++) {
				double a1 = spinAngle + i * (Math.PI * 2 / SIDES);
				double a2 = spinAngle + (i + 1) * (Math.PI * 2 / SIDES);
				float x1 = cx + (float) Math.cos(a1) * radius;
				float z1 = cz + (float) Math.sin(a1) * radius;
				float x2 = cx + (float) Math.cos(a2) * radius;
				float z2 = cz + (float) Math.sin(a2) * radius;

				double faceAngle = (a1 + a2) / 2.0;
				float light = (float) (0.65 + 0.35 * Math.cos(faceAngle - 0.8));

				float topLight = Math.min(1f, light * 1.1f);
				buffer.vertex(matrix, cx, cy + halfHeight, cz).color(r * topLight, g * topLight, b * topLight, 0.92f);
				buffer.vertex(matrix, x1, cy, z1).color(r * topLight, g * topLight, b * topLight, 0.92f);
				buffer.vertex(matrix, x2, cy, z2).color(r * topLight, g * topLight, b * topLight, 0.92f);
				buffer.vertex(matrix, x2, cy, z2).color(r * topLight, g * topLight, b * topLight, 0.92f);

				float bottomLight = light * 0.7f;
				buffer.vertex(matrix, cx, cy - halfHeight, cz).color(r * bottomLight, g * bottomLight, b * bottomLight, 0.92f);
				buffer.vertex(matrix, x2, cy, z2).color(r * bottomLight, g * bottomLight, b * bottomLight, 0.92f);
				buffer.vertex(matrix, x1, cy, z1).color(r * bottomLight, g * bottomLight, b * bottomLight, 0.92f);
				buffer.vertex(matrix, x1, cy, z1).color(r * bottomLight, g * bottomLight, b * bottomLight, 0.92f);
			}
		});

		event.matrices.pop();
	}
}
