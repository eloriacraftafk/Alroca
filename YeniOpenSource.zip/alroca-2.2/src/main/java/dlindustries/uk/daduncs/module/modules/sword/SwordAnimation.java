/*
 * This file is part of System Client (https://github.com/daduncs/system)
 * Website: https://download.daduncs.cloud/
 *
 * Copyright (c) 2024 - 2026 DLindustries and project contributors.
 *
 * System Client is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * System Client is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with System Client. If not, see <https://www.gnu.org/licenses/>.
 */

package dlindustries.uk.daduncs.module.modules.sword;

import dlindustries.uk.daduncs.event.events.AttackListener;
import dlindustries.uk.daduncs.module.Category;
import dlindustries.uk.daduncs.module.Module;
import dlindustries.uk.daduncs.module.setting.number;
import dlindustries.uk.daduncs.utils.EncryptedString;

/**
 * SwordAnimation — Vuruşta el hareket etmez, elimdeki eşya sola yatar
 * sonra tekrar dik konuma döner. swingProgress sıfırlanarak vanilla kol
 * salınımı tamamen iptal edilir; yerine sadece item rotation animasyonu
 * oynatılır (HeldItemRendererMixin tarafından kullanılır).
 */
public final class SwordAnimation extends Module implements AttackListener {

    // ---- Ayarlar ----
    private final number tiltAngle = new number(
            EncryptedString.of("Tilt Açısı"), 10, 90, 45, 5)
            .setDescription(EncryptedString.of("Vuruşta eşyanın sola ne kadar yatacağı (derece)"));

    private final number tiltSpeed = new number(
            EncryptedString.of("Tilt Hızı"), 0.05, 0.5, 0.18, 0.01)
            .setDescription(EncryptedString.of("Animasyonun ne kadar hızlı oynanacağı"));

    // ---- Durum ----
    /**
     * 0.0 = dik (başlangıç), 1.0 = tam yatık (vuruş anı), sonra 0.0'a döner.
     * HeldItemRendererMixin bu değeri okuyarak eşyayı döndürür.
     */
    private float animProgress = 0f;

    /** true = yatma fazı, false = dikleşme fazı */
    private boolean tilting = false;

    public SwordAnimation() {
        super(EncryptedString.of("Sword Animation"),
                EncryptedString.of("Vuruşta el hareketsiz kalır, eşya sola yatıp tekrar dik döner"),
                -1,
                Category.SWORD);
        addSettings(tiltAngle, tiltSpeed);
    }

    @Override
    public void onEnable() {
        eventManager.add(AttackListener.class, this);
        animProgress = 0f;
        tilting = false;
        super.onEnable();
    }

    @Override
    public void onDisable() {
        eventManager.remove(AttackListener.class, this);
        animProgress = 0f;
        tilting = false;
        super.onDisable();
    }

    /** Vuruş paketi gönderildiğinde animasyonu başlat. */
    @Override
    public void onAttack(AttackEvent event) {
        tilting = true;
        // animProgress sıfırdan yavaşça 1'e çıkacak (HeldItemRendererMixin tick'ler)
    }

    // ---- HeldItemRendererMixin tarafından çağrılan API ----

    /**
     * Her render frame'de çağrılır (HeldItemRendererMixin).
     * tilting=true ise progress 1'e doğru artar, sonra geri 0'a iner.
     */
    public void tickAnim() {
        float speed = tiltSpeed.getValueFloat();
        if (tilting) {
            animProgress = Math.min(1f, animProgress + speed);
            if (animProgress >= 1f) tilting = false; // zirveye ulaştı, geri dön
        } else {
            animProgress = Math.max(0f, animProgress - speed);
        }
    }

    /**
     * @return Şu anki animasyon ilerleme değeri (0.0–1.0).
     *         HeldItemRendererMixin bunu tiltAngle ile çarparak Z rotasyonu uygular.
     */
    public float getAnimProgress() {
        return animProgress;
    }

    /**
     * @return Kullanıcının ayarladığı maksimum tilt açısı (derece).
     */
    public float getTiltAngle() {
        return tiltAngle.getValueFloat();
    }
}
