/*
 * This file is part of System Client (https://github.com/daduncs/system)
 * Website: https://download.daduncs.cloud/
 *
 * Copyright (c) 2024 - 2026 DLindustries and project contributors.
 *
 * System Client is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * System Client is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with System Client. If not, see <https://www.gnu.org/licenses/>.
 */

package dlindustries.uk.daduncs.mixin;

import dlindustries.uk.daduncs.c454;
import dlindustries.uk.daduncs.module.modules.sword.SwordAnimation;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.item.HeldItemRenderer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.item.ItemStack;
import net.minecraft.util.Hand;
import net.minecraft.util.math.RotationAxis;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyArg;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(HeldItemRenderer.class)
public abstract class HeldItemRendererMixin {

    // ------------------------------------------------------------------ //
    //  1) swingProgress sıfırla → kol sallanmaz                           //
    // ------------------------------------------------------------------ //

    /**
     * renderItem(player, itemStack, modelTransformation, hand, matrices,
     *            vertexConsumers, light, swingProgress, equipProgress)
     *
     * swingProgress (index 7 = 8. parametre, 0-indexed 7) sıfırlanıyor.
     * Bu vanilla kol salınım animasyonunu tamamen durdurur.
     */
    @ModifyArg(
            method = "renderItem(Lnet/minecraft/client/network/AbstractClientPlayerEntity;Lnet/minecraft/item/ItemStack;Lnet/minecraft/client/render/model/json/ModelTransformationMode;Lnet/minecraft/util/Hand;Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/VertexConsumerProvider;I)V",
            at = @At(value = "INVOKE",
                    target = "Lnet/minecraft/client/render/item/HeldItemRenderer;renderFirstPersonItem(Lnet/minecraft/client/network/AbstractClientPlayerEntity;FFLnet/minecraft/util/Hand;FLnet/minecraft/item/ItemStack;FLnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/VertexConsumerProvider;I)V"),
            index = 2  // swingProgress, renderFirstPersonItem'in 3. parametresi
    )
    private float cancelSwingProgress(float swingProgress) {
        SwordAnimation mod = getSwordAnim();
        if (mod != null && mod.isEnabled()) {
            return 0f; // kol sallanmaz
        }
        return swingProgress;
    }

    // ------------------------------------------------------------------ //
    //  2) Item rotation animasyonu: sola yat → tekrar dik                 //
    // ------------------------------------------------------------------ //

    /**
     * renderFirstPersonItem çağrısının hemen başına inject ediyoruz.
     * MatrixStack'e Z ekseninde dönüş uygulayarak sadece eşyayı yatırıyoruz.
     * El/kol matrisi etkilenmez çünkü push/pop ile izole ediyoruz.
     */
    @Inject(
            method = "renderFirstPersonItem",
            at = @At("HEAD")
    )
    private void applyItemTiltAnim(
            AbstractClientPlayerEntity player,
            float tickDelta,
            float pitch,
            Hand hand,
            float swingProgress,
            ItemStack item,
            float equipProgress,
            MatrixStack matrices,
            VertexConsumerProvider vertexConsumers,
            int light,
            CallbackInfo ci) {

        SwordAnimation mod = getSwordAnim();
        if (mod == null || !mod.isEnabled()) return;
        if (hand != Hand.MAIN_HAND) return;

        // Animasyonu tick'le (her render frame'de çağrılır)
        mod.tickAnim();

        float progress = mod.getAnimProgress();
        if (progress <= 0f) return;

        // Smooth easing: ease-in-out cubic
        float eased = easeInOutCubic(progress);

        // Sola yatış: Z ekseninde negatif yön (sol)
        float angle = -eased * mod.getTiltAngle();

        // Sadece item transform'una uygulanacak şekilde push/pop
        matrices.push();
        matrices.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(angle));
        // NOT: pop() TAIL'de yapılıyor (aşağıdaki inject)
    }

    @Inject(
            method = "renderFirstPersonItem",
            at = @At("TAIL")
    )
    private void popItemTiltAnim(
            AbstractClientPlayerEntity player,
            float tickDelta,
            float pitch,
            Hand hand,
            float swingProgress,
            ItemStack item,
            float equipProgress,
            MatrixStack matrices,
            VertexConsumerProvider vertexConsumers,
            int light,
            CallbackInfo ci) {

        SwordAnimation mod = getSwordAnim();
        if (mod == null || !mod.isEnabled()) return;
        if (hand != Hand.MAIN_HAND) return;

        // HEAD'de push yaptıysak pop yapıyoruz
        if (mod.getAnimProgress() > 0f) {
            matrices.pop();
        }
    }

    // ------------------------------------------------------------------ //
    //  Yardımcılar                                                        //
    // ------------------------------------------------------------------ //

    private static SwordAnimation getSwordAnim() {
        if (c454.INSTANCE == null || c454.INSTANCE.getModuleManager() == null) return null;
        return c454.INSTANCE.getModuleManager().getModule(SwordAnimation.class);
    }

    /** Smooth animasyon eğrisi (0→1→0 güzel görünmesi için). */
    private static float easeInOutCubic(float t) {
        // t < 0.5 → hızlı başla, t > 0.5 → yavaş bitir
        return t < 0.5f
                ? 4f * t * t * t
                : 1f - (float) Math.pow(-2f * t + 2f, 3) / 2f;
    }
}
