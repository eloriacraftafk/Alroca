/*
 * This file is part of System Client (https://github.com/daduncs/system)
 * Website: https://download.daduncs.cloud/
 *
 * Copyright (c) 2024 - 2026 DLindustries and project contributors.
 *
 * System Client is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * System Client is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with System Client. If not, see <https://www.gnu.org/licenses/>.
 */

package dlindustries.uk.daduncs.argonsui;

import dlindustries.uk.daduncs.utils.Sounds;
import dlindustries.uk.daduncs.Alroca;
import dlindustries.uk.daduncs.argonsui.components.ModuleButton;
import dlindustries.uk.daduncs.argonsui.components.settings.KeybindBox;
import dlindustries.uk.daduncs.argonsui.components.settings.RenderableSetting;
import dlindustries.uk.daduncs.module.Category;
import dlindustries.uk.daduncs.module.modules.client.ClickGUI;
import dlindustries.uk.daduncs.utils.ColorUtils;
import dlindustries.uk.daduncs.utils.RenderUtils;
import dlindustries.uk.daduncs.utils.TextRenderer;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.TitleScreen;
import net.minecraft.client.input.KeyInput;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

import java.awt.*;
import java.util.ArrayList;
import java.util.List;

import static dlindustries.uk.daduncs.Alroca.mc;

public final class ClickGui extends Screen {
	public List<Window> windows = new ArrayList<>();
	public Color currentColor;
	private int lastWidth;
	private static final StackWalker sw = StackWalker.getInstance(StackWalker.Option.RETAIN_CLASS_REFERENCE);

	public ClickGui() {
		super(Text.empty());

		int offsetX = 50;
		for (Category category : Category.values()) {
			windows.add(new Window(offsetX, 50, 190, 30, category, this));
			offsetX += 210;
		}
	}

	@Override
	protected void init() {
		int screenWidth = mc.getWindow().getWidth();
		if (screenWidth == lastWidth)
			return;

		lastWidth = screenWidth;

		int gap = 14;
		int windowWidth = windows.isEmpty() ? 190 : windows.get(0).getWidth();
		int perRow = Math.max(1, (screenWidth - 100 + gap) / (windowWidth + gap));

		int offsetY = 50;
		int index = 0;

		while (index < windows.size()) {
			int inRow = Math.min(perRow, windows.size() - index);
			int rowWidth = inRow * windowWidth + (inRow - 1) * gap;
			int offsetX = Math.max(10, (screenWidth - rowWidth) / 2);
			int tallest = 0;

			for (int i = 0; i < inRow; i++) {
				Window window = windows.get(index + i);
				window.setX(offsetX);
				window.setY(offsetY);

				tallest = Math.max(tallest, window.getHeight() * (window.moduleButtons.size() + 1));
				offsetX += window.getWidth() + gap;
			}

			offsetY += tallest + 20;
			index += inRow;
		}
	}


	private static final int CFG_W = 230;
	private static final int CFG_ROW = 26;

	private java.util.List<dlindustries.uk.daduncs.managers.ConfigManager.Config> cfgList() {
		java.util.List<dlindustries.uk.daduncs.managers.ConfigManager.Config> all = Alroca.INSTANCE.getConfigManager().getConfigs();
		return all.size() > 6 ? all.subList(0, 6) : all;
	}

	private int cfgX() { return mc.getWindow().getWidth() - CFG_W - 20; }

	private int cfgHeight() { return 44 + cfgList().size() * CFG_ROW + 8; }

	private int cfgY() { return mc.getWindow().getHeight() - cfgHeight() - 20; }

	private void renderConfigBox(DrawContext context, int mouseX, int mouseY) {
		int x = cfgX(), y = cfgY(), h = cfgHeight();
		RenderUtils.renderRoundedQuad(context, new Color(22, 13, 36, 215), x, y, x + CFG_W, y + h, 6, 6, 6, 6, 50);

		CharSequence title = "Config Manager";
		TextRenderer.drawString(title, context, x + CFG_W / 2 - TextRenderer.getWidth(title) / 2, y + 12, Color.WHITE.getRGB());

		int rowY = y + 38;
		for (dlindustries.uk.daduncs.managers.ConfigManager.Config config : cfgList()) {
			boolean active = Alroca.INSTANCE.getConfigManager().isActive(config);
			Color rowColor = active ? new Color(78, 44, 122, 210) : new Color(40, 24, 62, 150);
			RenderUtils.renderRoundedQuad(context, rowColor, x + 8, rowY, x + CFG_W - 8, rowY + CFG_ROW - 4, 3, 3, 3, 3, 50);
			TextRenderer.drawString(config.name(), context, x + 16, rowY + 6, Color.WHITE.getRGB());
			rowY += CFG_ROW;
		}
	}

	private boolean clickConfigBox(double mouseX, double mouseY, int button) {
		if (button != 0) return false;
		int x = cfgX();
		int rowY = cfgY() + 38;
		for (dlindustries.uk.daduncs.managers.ConfigManager.Config config : cfgList()) {
			if (mouseX >= x + 8 && mouseX <= x + CFG_W - 8 && mouseY >= rowY && mouseY <= rowY + CFG_ROW - 4) {
				Alroca.INSTANCE.getConfigManager().load(config);
				return true;
			}
			rowY += CFG_ROW;
		}
		return false;
	}

	public boolean isDraggingAlready() {
		for(Window window : windows)
			if(window.dragging)
				return true;

		return false;
	}

	@Override
	protected void setInitialFocus() {
		if (client == null) {
			return;
		}
		super.setInitialFocus();
	}

	@Override
	public void render(DrawContext context, int mouseX, int mouseY, float delta) {
		if (mc.currentScreen == this) {
			if (Alroca.INSTANCE.previousScreen != null)
				Alroca.INSTANCE.previousScreen.render(context, 0, 0, delta);

			if (currentColor == null)
				currentColor = new Color(0, 0, 0, 0);
			else currentColor = new Color(0, 0, 0, currentColor.getAlpha());

			if (currentColor.getAlpha() != 0)
				currentColor = ColorUtils.smoothAlphaTransition(0.05F, 0, currentColor);

			if (mc.currentScreen instanceof ClickGui)
				context.fill(0, 0, mc.getWindow().getWidth(), mc.getWindow().getHeight(), currentColor.getRGB());

			RenderUtils.unscaledProjection(context);
			mouseX *= (int) MinecraftClient.getInstance().getWindow().getScaleFactor();
			mouseY *= (int) MinecraftClient.getInstance().getWindow().getScaleFactor();
			super.render(context, mouseX, mouseY, delta);

			for (Window window : windows) {
				window.render(context, mouseX, mouseY, delta);
				window.updatePosition(mouseX, mouseY, delta);
			}

			renderConfigBox(context, mouseX, mouseY);

			TextRenderer.drawString("@alexnumberone & @TersUga", context, 12, mc.getWindow().getHeight() - 28, 0xFFFFFFFF);

			RenderUtils.scaledProjection(context);
		}
	}

	@Override
	public boolean keyPressed(KeyInput keyInput) {
		int keyCode = keyInput.key();
		int scanCode = keyInput.scancode();
		int modifiers = keyInput.modifiers();

		if (keyCode == GLFW.GLFW_KEY_ESCAPE) {
			for (Window window : windows)
				for (ModuleButton moduleButton : window.moduleButtons)
					for (RenderableSetting setting : moduleButton.settings)
						if (setting instanceof KeybindBox keybindBox && keybindBox.keybind.isListening()) {
							keybindBox.keybind.setListening(false);
							return true;
						}
		}

		for (Window window : windows)
			window.keyPressed(keyCode, scanCode, modifiers);

		return super.keyPressed(keyInput);
	}

	@Override
	public boolean mouseClicked(Click click, boolean doubled) {
		double mouseX = click.x();
		double mouseY = click.y();
		int button = click.button();

		mouseX *= (int) MinecraftClient.getInstance().getWindow().getScaleFactor();
		mouseY *= (int) MinecraftClient.getInstance().getWindow().getScaleFactor();

		if (clickConfigBox(mouseX, mouseY, button))
			return true;

		for (Window window : windows)
			window.mouseClicked(mouseX, mouseY, button);

		return super.mouseClicked(click, doubled);
	}

	@Override
	public boolean mouseDragged(Click click, double deltaX, double deltaY) {
		double mouseX = click.x();
		double mouseY = click.y();
		int button = click.button();

		mouseX *= (int) MinecraftClient.getInstance().getWindow().getScaleFactor();
		mouseY *= (int) MinecraftClient.getInstance().getWindow().getScaleFactor();

		for (Window window : windows)
			window.mouseDragged(mouseX, mouseY, button, deltaX, deltaY);

		return super.mouseDragged(click, deltaX, deltaY);
	}

	@Override
	public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
		MinecraftClient mc = MinecraftClient.getInstance();
		mouseY *= mc.getWindow().getScaleFactor();

		for (Window window : windows)
			window.mouseScrolled(mouseX, mouseY, horizontalAmount, verticalAmount);

		return super.mouseScrolled(mouseX, mouseY, horizontalAmount, verticalAmount);
	}

	@Override
	public boolean shouldPause() {
		return false;
	}

	@Override
	public void close() {
		Alroca.INSTANCE.getModuleManager().getModule(ClickGUI.class).setEnabledStatus(false);
		onGuiClose();
	}

	public void onGuiClose() {
		ClickGUI.uiSound(Sounds.CLOSE_QUICK);
		if (Alroca.INSTANCE.previousScreen instanceof TitleScreen) {
			mc.setScreenAndRender(null);
		} else {
			mc.setScreenAndRender(Alroca.INSTANCE.previousScreen);
		}
		Alroca.INSTANCE.previousScreen = null;
		currentColor = null;

		for (Window window : windows)
			window.onGuiClose();
	}

	@Override
	public boolean mouseReleased(Click click) {
		double mouseX = click.x();
		double mouseY = click.y();
		int button = click.button();

		mouseX *= (int) MinecraftClient.getInstance().getWindow().getScaleFactor();
		mouseY *= (int) MinecraftClient.getInstance().getWindow().getScaleFactor();

		for (Window window : windows)
			window.mouseReleased(mouseX, mouseY, button);

		return super.mouseReleased(click);
	}
}
