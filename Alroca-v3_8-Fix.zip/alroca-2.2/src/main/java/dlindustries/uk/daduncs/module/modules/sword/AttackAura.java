/*
 * This file is part of System Client (https://github.com/daduncs/system)
 * Website: https://download.daduncs.cloud/
 *
 * Copyright (c) 2024 - 2026 DLindustries and project contributors.
 *
 * System Client is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * System Client is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with System Client. If not, see <https://www.gnu.org/licenses/>.
 */

package dlindustries.uk.daduncs.module.modules.sword;

import dlindustries.uk.daduncs.Alroca;
import dlindustries.uk.daduncs.event.events.TickListener;
import dlindustries.uk.daduncs.module.Category;
import dlindustries.uk.daduncs.module.Module;
import dlindustries.uk.daduncs.module.setting.bool;
import dlindustries.uk.daduncs.module.setting.number;
import dlindustries.uk.daduncs.utils.EncryptedString;
import dlindustries.uk.daduncs.utils.RotationUtils;
import dlindustries.uk.daduncs.utils.rotation.Rotation;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.Hand;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

public final class AttackAura extends Module implements TickListener {

	private final number range = new number(EncryptedString.of("Range"), 2, 6, 3.0, 0.1)
			.setDescription(EncryptedString.of("Distance to hit players from"));
	private final number cooldown = new number(EncryptedString.of("Cooldown"), 0.5, 1, 0.95, 0.05)
			.setDescription(EncryptedString.of("Attack strength needed before hitting"));
	private final bool rotate = new bool(EncryptedString.of("Rotate"), true)
			.setDescription(EncryptedString.of("Turns towards the target before hitting"));
	private final bool throughWalls = new bool(EncryptedString.of("Through Walls"), false)
			.setDescription(EncryptedString.of("Also hits players you cannot see"));
	private final bool friendSafe = new bool(EncryptedString.of("Friend Safe"), true)
			.setDescription(EncryptedString.of("Never targets your friends"));

	public AttackAura() {
		super(EncryptedString.of("Attack Aura"),
				EncryptedString.of("Automatically hits the nearest player in range"),
				-1,
				Category.SWORD);
		addSettings(range, cooldown, rotate, throughWalls, friendSafe);
	}

	@Override
	public void onEnable() {
		eventManager.add(TickListener.class, this);
		super.onEnable();
	}

	@Override
	public void onDisable() {
		eventManager.remove(TickListener.class, this);
		super.onDisable();
	}

	private PlayerEntity findTarget() {
		PlayerEntity best = null;
		double reach = Math.min(range.getValue(), 3.0);
		if (mc.player.isGliding())
			reach -= 0.3;
		double bestDistance = reach;
		Vec3d eye = mc.player.getEyePos();

		for (PlayerEntity player : mc.world.getPlayers()) {
			if (player == mc.player || !player.isAlive() || player.isSpectator())
				continue;

			if (friendSafe.getValue() && Alroca.INSTANCE.getFriendManager().isFriend(player))
				continue;

			if (!throughWalls.getValue() && !mc.player.canSee(player))
				continue;

			if (player.hurtTime > 1)
				continue;

			Box box = player.getBoundingBox();
			Vec3d closest = new Vec3d(
					MathHelper.clamp(eye.x, box.minX, box.maxX),
					MathHelper.clamp(eye.y, box.minY, box.maxY),
					MathHelper.clamp(eye.z, box.minZ, box.maxZ));
			double distance = eye.distanceTo(closest);

			if (distance <= bestDistance) {
				bestDistance = distance;
				best = player;
			}
		}

		return best;
	}

	@Override
	public void onTick() {
		if (mc.player == null || mc.world == null || mc.interactionManager == null || mc.currentScreen != null)
			return;

		if (mc.player.getAttackCooldownProgress(0.5f) < cooldown.getValueFloat())
			return;

		PlayerEntity target = findTarget();

		if (target == null)
			return;

		if (rotate.getValue()) {
			Rotation rotation = RotationUtils.getDirection(mc.player.getEyePos(), target.getBoundingBox().getCenter());
			mc.player.setYaw((float) rotation.yaw());
			mc.player.setPitch((float) rotation.pitch());
		}

		mc.interactionManager.attackEntity(mc.player, target);
		mc.player.swingHand(Hand.MAIN_HAND);
	}
}
