/*
 * This file is part of System Client (https://github.com/daduncs/system)
 * Website: https://download.daduncs.cloud/
 *
 * Copyright (c) 2024 - 2026 DLindustries and project contributors.
 *
 * System Client is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * System Client is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with System Client. If not, see <https://www.gnu.org/licenses/>.
 */

package dlindustries.uk.daduncs.module.modules.sword;

import dlindustries.uk.daduncs.Alroca;
import dlindustries.uk.daduncs.event.events.TickListener;
import dlindustries.uk.daduncs.module.Category;
import dlindustries.uk.daduncs.module.Module;
import dlindustries.uk.daduncs.module.setting.bool;
import dlindustries.uk.daduncs.module.setting.number;
import dlindustries.uk.daduncs.utils.EncryptedString;
import dlindustries.uk.daduncs.utils.RotationUtils;
import dlindustries.uk.daduncs.utils.rotation.Rotation;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

public final class ElytraTarget extends Module implements TickListener {

	private final number range = new number(EncryptedString.of("Range"), 5, 80, 40, 1)
			.setDescription(EncryptedString.of("Max distance to pick a target"));
	private final number radius = new number(EncryptedString.of("Radius"), 2, 12, 4, 0.5)
			.setDescription(EncryptedString.of("Circle radius around the target"));
	private final number height = new number(EncryptedString.of("Height"), -3, 6, 0.5, 0.5)
			.setDescription(EncryptedString.of("Height offset above the target"));
	private final number speed = new number(EncryptedString.of("Speed"), 0.3, 3, 1, 0.1)
			.setDescription(EncryptedString.of("Flying speed around the target"));
	private final bool overtake = new bool(EncryptedString.of("Overtake"), false)
			.setDescription(EncryptedString.of("Flies ahead of the target in the direction it is moving"));
	private final number overtakeDistance = new number(EncryptedString.of("Overtake Distance"), 1, 20, 6, 1)
			.setDescription(EncryptedString.of("How far ahead of the target to circle"))
			.setVisibility(overtake::getValue);
	private final bool follow = new bool(EncryptedString.of("Follow"), true)
			.setDescription(EncryptedString.of("Chase the target when it flies away"));
	private final bool friendSafe = new bool(EncryptedString.of("Friend Safe"), true)
			.setDescription(EncryptedString.of("Never targets your friends"));

	private PlayerEntity lastTarget;
	private Vec3d lastTargetPos;
	private Vec3d targetMotion = Vec3d.ZERO;

	public ElytraTarget() {
		super(EncryptedString.of("Elytra Target"),
				EncryptedString.of("Flies around the nearest player in a perfect circle while you glide with an elytra"),
				-1,
				Category.SWORD);
		addSettings(range, radius, height, speed, overtake, overtakeDistance, follow, friendSafe);
	}

	@Override
	public void onEnable() {
		eventManager.add(TickListener.class, this);
		lastTarget = null;
		lastTargetPos = null;
		targetMotion = Vec3d.ZERO;
		super.onEnable();
	}

	@Override
	public void onDisable() {
		eventManager.remove(TickListener.class, this);
		super.onDisable();
	}

	private PlayerEntity findTarget() {
		PlayerEntity best = null;
		double bestDistance = range.getValue();

		for (PlayerEntity player : mc.world.getPlayers()) {
			if (player == mc.player || !player.isAlive() || player.isSpectator())
				continue;

			if (friendSafe.getValue() && Alroca.INSTANCE.getFriendManager().isFriend(player))
				continue;

			double distance = mc.player.distanceTo(player);

			if (distance <= bestDistance) {
				bestDistance = distance;
				best = player;
			}
		}

		return best;
	}

	@Override
	public void onTick() {
		if (mc.player == null || mc.world == null || mc.currentScreen != null)
			return;

		if (!mc.player.isGliding())
			return;

		PlayerEntity target = findTarget();

		if (target == null)
			return;

		Vec3d me = mc.player.getEntityPos();
		Vec3d tp = target.getEntityPos();

		if (target != lastTarget || lastTargetPos == null) {
			lastTarget = target;
			targetMotion = Vec3d.ZERO;
		} else
			targetMotion = targetMotion.multiply(0.5).add(tp.subtract(lastTargetPos).multiply(0.5));

		lastTargetPos = tp;

		if (overtake.getValue()) {
			Vec3d flatMotion = new Vec3d(targetMotion.x, 0, targetMotion.z);

			if (flatMotion.lengthSquared() > 0.0025)
				tp = tp.add(flatMotion.normalize().multiply(overtakeDistance.getValue()));
		}

		tp = tp.add(targetMotion);

		double dx = me.x - tp.x;
		double dz = me.z - tp.z;
		double flat = Math.sqrt(dx * dx + dz * dz);
		double r = radius.getValue();
		double v = speed.getValue();

		Vec3d next;

		if (follow.getValue() && flat > r * 3) {
			Vec3d toTarget = new Vec3d(tp.x - me.x, tp.y + height.getValue() - me.y, tp.z - me.z).normalize();
			next = me.add(toTarget.multiply(v));
		} else {
			double angle = Math.atan2(dz, dx) + v / r;
			double nextRadius = flat + MathHelper.clamp(r - flat, -1.0, 1.0);
			double nextY = me.y + MathHelper.clamp(tp.y + height.getValue() - me.y, -0.5, 0.5);
			next = new Vec3d(tp.x + Math.cos(angle) * nextRadius, nextY, tp.z + Math.sin(angle) * nextRadius);
		}

		Vec3d move = next.subtract(me);

		if (move.length() > 3.0)
			move = move.normalize().multiply(3.0);

		Rotation rotation = RotationUtils.getDirection(mc.player.getEyePos(), mc.player.getEyePos().add(move));
		mc.player.setYaw((float) rotation.yaw());
		mc.player.setPitch((float) rotation.pitch());
		mc.player.setVelocity(move);
	}
}
