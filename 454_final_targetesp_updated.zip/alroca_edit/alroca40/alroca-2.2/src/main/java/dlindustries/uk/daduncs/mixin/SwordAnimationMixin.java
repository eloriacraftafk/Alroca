/*
 * This file is part of System Client (https://github.com/daduncs/system)
 * Website: https://download.daduncs.cloud/
 *
 * Copyright (c) 2024 - 2026 DLindustries and project contributors.
 *
 * System Client is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * System Client is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with System Client. If not, see <https://www.gnu.org/licenses/>.
 */

package dlindustries.uk.daduncs.mixin;

import dlindustries.uk.daduncs.454;
import dlindustries.uk.daduncs.module.modules.render.SwordAnimation;
import net.minecraft.client.render.item.HeldItemRenderer;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.item.ItemStack;
import net.minecraft.util.Hand;
import net.minecraft.util.math.RotationAxis;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyArg;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(HeldItemRenderer.class)
public abstract class SwordAnimationMixin {

    // swingProgress: 0.0 = dinlenim, 0.0->1.0 = sallanıyor
    // Vanilla bu değeri kullanarak eli fırlatır. Biz onu sıfıra çekip
    // yerine sadece tilt uygulayacağız.

    // 1) swingProgress parametresini sıfırla — el ileri gitmesin
    @ModifyArg(
            method = "renderFirstPersonItem",
            at = @At(value = "INVOKE",
                    target = "Lnet/minecraft/client/render/item/HeldItemRenderer;applySwingOffset(Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/util/Arm;F)V"),
            index = 2
    )
    private float cancelSwing(float swingProgress) {
        SwordAnimation mod = getModule();
        if (mod == null || !mod.isEnabled()) return swingProgress;
        // Swing tamamen iptal — el sabit
        return 0f;
    }

    // 2) Swing başladığında tilt uygula
    @Inject(
            method = "renderFirstPersonItem",
            at = @At(value = "INVOKE",
                    target = "Lnet/minecraft/client/render/item/HeldItemRenderer;applySwingOffset(Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/util/Arm;F)V")
    )
    private void applyTilt(AbstractClientPlayerEntity player,
                            float tickDelta, float pitch,
                            Hand hand, float swingProgress,
                            ItemStack item, float equipProgress,
                            MatrixStack matrices, CallbackInfo ci) {
        SwordAnimation mod = getModule();
        if (mod == null || !mod.isEnabled() || swingProgress <= 0f) return;

        // swingProgress: 0 → 1 → 0 döngüsü (vanilla: 0=başlangıç, 0.5=peak, 1=bitiş)
        // sin ile yumuşat: 0'da başlar, ortada max, 1'de biter
        float tiltFactor = (float) Math.sin(swingProgress * Math.PI);
        float angle = tiltFactor * mod.tiltAngle.getValueFloat();

        // Z ekseninde sola yat (negatif = sola)
        matrices.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(-angle));
    }

    // 3) equipProgress (silah değiştirme animasyonu) sıfırla — el yukarı çıkmasın
    @ModifyArg(
            method = "renderFirstPersonItem",
            at = @At(value = "INVOKE",
                    target = "Lnet/minecraft/client/render/item/HeldItemRenderer;applyEquipOffset(Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/util/Arm;F)V"),
            index = 2
    )
    private float cancelEquip(float equipProgress) {
        SwordAnimation mod = getModule();
        if (mod == null || !mod.isEnabled()) return equipProgress;
        return 0f;
    }

    private SwordAnimation getModule() {
        if (454.INSTANCE == null || 454.INSTANCE.getModuleManager() == null) return null;
        return 454.INSTANCE.getModuleManager().getModule(SwordAnimation.class);
    }
}
