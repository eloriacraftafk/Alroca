/*
 * Patch: KnockbackDelay — defer velocity application
 * - Captures EntityVelocityUpdateS2CPacket for local player
 * - Holds for randomized tick window then applies scaled velocity
 * - Stacks cleanly under Velocity (this delays, Velocity can still scale on apply)
 * - Pattern noise via min/max delay + chance
 */

package dlindustries.uk.daduncs.module.modules.misc;

import dlindustries.uk.daduncs.event.events.PacketReceiveListener;
import dlindustries.uk.daduncs.event.events.TickListener;
import dlindustries.uk.daduncs.module.Category;
import dlindustries.uk.daduncs.module.Module;
import dlindustries.uk.daduncs.module.setting.bool;
import dlindustries.uk.daduncs.module.setting.number;
import dlindustries.uk.daduncs.utils.EncryptedString;
import net.minecraft.network.packet.s2c.play.EntityVelocityUpdateS2CPacket;
import net.minecraft.util.math.Vec3d;

import java.util.ArrayDeque;
import java.util.concurrent.ThreadLocalRandom;
import dlindustries.uk.daduncs.mixin.EntityVelocityUpdateS2CPacketAccessor;

public final class KnockbackDelay extends Module implements PacketReceiveListener, TickListener {

    private final number minDelay = new number(EncryptedString.of("Min Delay"), 0, 20, 1, 1)
            .setDescription(EncryptedString.of("Minimum ticks before applying knockback"));
    private final number maxDelay = new number(EncryptedString.of("Max Delay"), 0, 30, 4, 1)
            .setDescription(EncryptedString.of("Maximum ticks before applying knockback"));
    private final number chance = new number(EncryptedString.of("Chance"), 0, 100, 100, 1)
            .setDescription(EncryptedString.of("% chance to delay a given velocity packet"));
    private final number horizontal = new number(EncryptedString.of("Horizontal"), 0, 100, 100, 1)
            .setDescription(EncryptedString.of("% horizontal kept when applied"));
    private final number vertical = new number(EncryptedString.of("Vertical"), 0, 100, 100, 1)
            .setDescription(EncryptedString.of("% vertical kept when applied"));
    private final bool replace = new bool(EncryptedString.of("Replace Queue"), true)
            .setDescription(EncryptedString.of("New velocity packet replaces older pending ones"));
    private final number maxPending = new number(EncryptedString.of("Max Pending"), 1, 8, 2, 1)
            .setDescription(EncryptedString.of("Cap on queued delayed velocities"));

    private final ArrayDeque<Pending> pending = new ArrayDeque<>();

    private record Pending(int ticksLeft, Vec3d velocity) {}

    public KnockbackDelay() {
        super(EncryptedString.of("Knockback Delay"),
                EncryptedString.of("Holds knockback velocity for a short randomized delay before applying"),
                -1,
                Category.MISC);
        addSettings(minDelay, maxDelay, chance, horizontal, vertical, replace, maxPending);
    }

    @Override
    public void onEnable() {
        eventManager.add(PacketReceiveListener.class, this);
        eventManager.add(TickListener.class, this);
        pending.clear();
        super.onEnable();
    }

    @Override
    public void onDisable() {
        // apply remaining so we don't soft-lock movement state
        while (!pending.isEmpty()) {
            apply(pending.pollFirst().velocity);
        }
        eventManager.remove(PacketReceiveListener.class, this);
        eventManager.remove(TickListener.class, this);
        super.onDisable();
    }

    private void apply(Vec3d v) {
        if (mc.player == null) return;
        double hx = horizontal.getValue() / 100.0;
        double vx = vertical.getValue() / 100.0;
        mc.player.setVelocity(v.x * hx, v.y * vx, v.z * hx);
    }

    @Override
    public void onTick() {
        if (mc.player == null) {
            pending.clear();
            return;
        }
        ArrayDeque<Pending> next = new ArrayDeque<>();
        while (!pending.isEmpty()) {
            Pending p = pending.pollFirst();
            if (p.ticksLeft <= 0) {
                apply(p.velocity);
            } else {
                next.addLast(new Pending(p.ticksLeft - 1, p.velocity));
            }
        }
        pending.addAll(next);
    }

    @Override
    public void onPacketReceive(PacketReceiveEvent event) {
        if (mc.player == null) return;
        if (!(event.packet instanceof EntityVelocityUpdateS2CPacket packet)) return;
        if (packet.getEntityId() != mc.player.getId()) return;

        if (ThreadLocalRandom.current().nextDouble() * 100.0 > chance.getValue()) return;

        int min = Math.min(minDelay.getValueInt(), maxDelay.getValueInt());
        int max = Math.max(minDelay.getValueInt(), maxDelay.getValueInt());
        int delay = min + ThreadLocalRandom.current().nextInt(Math.max(1, max - min + 1));

        Vec3d vel = new Vec3d(
            ((EntityVelocityUpdateS2CPacketAccessor) packet).getVelocityX() / 8000.0,
            ((EntityVelocityUpdateS2CPacketAccessor) packet).getVelocityY() / 8000.0,
            ((EntityVelocityUpdateS2CPacketAccessor) packet).getVelocityZ() / 8000.0
        );

        event.cancel();

        if (replace.getValue()) {
            pending.clear();
        }
        while (pending.size() >= maxPending.getValueInt()) {
            Pending dropped = pending.pollFirst();
            if (dropped != null) apply(dropped.velocity);
        }
        pending.addLast(new Pending(delay, vel));
    }
}
