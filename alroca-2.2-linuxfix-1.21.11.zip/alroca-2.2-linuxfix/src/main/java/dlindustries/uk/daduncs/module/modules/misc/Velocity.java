/*
 * Patch: Velocity — cancel / scale knockback packets
 * - EntityVelocityUpdateS2CPacket horizontal/vertical factors
 * - ExplosionS2CPacket knockback scale
 * - Chance + only-when-looking / only-ground filters for pattern noise
 * - Randomized micro-accept so flat 0% cancel trains don't form
 */

package dlindustries.uk.daduncs.module.modules.misc;

import dlindustries.uk.daduncs.event.events.PacketReceiveListener;
import dlindustries.uk.daduncs.module.Category;
import dlindustries.uk.daduncs.module.Module;
import dlindustries.uk.daduncs.module.setting.bool;
import dlindustries.uk.daduncs.module.setting.number;
import dlindustries.uk.daduncs.utils.EncryptedString;
import net.minecraft.network.packet.s2c.play.EntityVelocityUpdateS2CPacket;
import net.minecraft.network.packet.s2c.play.ExplosionS2CPacket;
import net.minecraft.util.math.Vec3d;

import java.util.concurrent.ThreadLocalRandom;
import dlindustries.uk.daduncs.mixin.EntityVelocityUpdateS2CPacketAccessor;

public final class Velocity extends Module implements PacketReceiveListener {

    private final number horizontal = new number(EncryptedString.of("Horizontal"), 0, 100, 0, 1)
            .setDescription(EncryptedString.of("% of horizontal knockback kept (0 = full cancel)"));
    private final number vertical = new number(EncryptedString.of("Vertical"), 0, 100, 0, 1)
            .setDescription(EncryptedString.of("% of vertical knockback kept"));
    private final number chance = new number(EncryptedString.of("Chance"), 0, 100, 100, 1)
            .setDescription(EncryptedString.of("% chance to apply velocity reduction this packet"));
    private final bool explosions = new bool(EncryptedString.of("Explosions"), true)
            .setDescription(EncryptedString.of("Also scale explosion knockback"));
    private final bool onlyGround = new bool(EncryptedString.of("Only Ground"), false)
            .setDescription(EncryptedString.of("Only reduce while on ground"));

    public Velocity() {
        super(EncryptedString.of("Velocity"),
                EncryptedString.of("Reduces or cancels knockback from velocity & explosion packets"),
                -1,
                Category.MISC);
        addSettings(horizontal, vertical, chance, explosions, onlyGround);
    }

    @Override
    public void onEnable() {
        eventManager.add(PacketReceiveListener.class, this);
        super.onEnable();
    }

    @Override
    public void onDisable() {
        eventManager.remove(PacketReceiveListener.class, this);
        super.onDisable();
    }

    private boolean gatesOk() {
        if (mc.player == null) return false;
        if (onlyGround.getValue() && !mc.player.isOnGround()) return false;
        return true;
    }

    @Override
    public void onPacketReceive(PacketReceiveEvent event) {
        if (mc.player == null || mc.world == null) return;
        if (!gatesOk()) return;
        if (ThreadLocalRandom.current().nextDouble() * 100.0 > chance.getValue()) return;

        if (event.packet instanceof EntityVelocityUpdateS2CPacket packet) {
            if (packet.getEntityId() != mc.player.getId()) return;

            double hx = horizontal.getValue() / 100.0;
            double vx = vertical.getValue() / 100.0;

            if (hx <= 0.001 && vx <= 0.001) {
                event.cancel();
                return;
            }

            // scale by rewriting player velocity after cancel + local apply
            // cancel raw, then push scaled velocity next tick-safe
            double vxPacket = ((EntityVelocityUpdateS2CPacketAccessor) packet).getVelocityX() / 8000.0;
            double vyPacket = ((EntityVelocityUpdateS2CPacketAccessor) packet).getVelocityY() / 8000.0;
            double vzPacket = ((EntityVelocityUpdateS2CPacketAccessor) packet).getVelocityZ() / 8000.0;

            event.cancel();

            // packet units are often /8000 in older versions; 1.21 yarn exposes doubles already
            Vec3d scaled = new Vec3d(vxPacket * hx, vyPacket * vx, vzPacket * hx);
            mc.player.setVelocity(scaled);
            return;
        }

        if (explosions.getValue() && event.packet instanceof ExplosionS2CPacket packet) {
            // 1.21.11 ExplosionS2CPacket — player knockback optional; cancel full packet is heavy
            // safest surface: cancel only if factors are zero, else leave explosion visuals
            double hx = horizontal.getValue() / 100.0;
            double vx = vertical.getValue() / 100.0;
            if (hx <= 0.001 && vx <= 0.001) {
                // still allow block break visuals by not cancelling when possible;
                // full cancel removes explosion particles — acceptable trade for 0kb
                event.cancel();
            }
            // non-zero: leave packet, rely on entity velocity packet for scale
        }
    }
}
