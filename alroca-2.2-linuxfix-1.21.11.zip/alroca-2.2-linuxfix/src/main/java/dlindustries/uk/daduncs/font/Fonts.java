/*
 * This file is part of System Client (https://github.com/daduncs/system)
 * Website: https://download.daduncs.cloud/
 *
 * Copyright (c) 2024 - 2026 DLindustries and project contributors.
 *
 * System Client is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * System Client is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with System Client. If not, see <https://www.gnu.org/licenses/>.
 */

package dlindustries.uk.daduncs.font;

import java.awt.Font;

public final class Fonts {
    // All fields null at class-load time — no OpenGL calls until render thread is ready.
    // Getters lazy-init on first use (always on render thread).

    private static GlyphPageFontRenderer QUICKSAND;
    private static GlyphPageFontRenderer BOLD;
    private static GlyphPageFontRenderer LIGHT;
    private static GlyphPageFontRenderer TIP;
    private static GlyphPageFontRenderer SMALL;
    private static GlyphPageFontRenderer SMALLBOLD;
    private static GlyphPageFontRenderer TITLE;
    private static GlyphPageFontRenderer MENU;
    private static GlyphPageFontRenderer TINY;
    private static GlyphPageFontRenderer LABEL;
    private static GlyphPageFontRenderer LABEL_MENU;
    private static GlyphPageFontRenderer LABEL_SMALL;
    private static GlyphPageFontRenderer PRODUCT_SANS_MEDIUM_36;
    private static GlyphPageFontRenderer PRODUCT_SANS_MEDIUM_18;
    private static GlyphPageFontRenderer PRODUCT_SANS_REGULAR_32;
    private static GlyphPageFontRenderer PRODUCT_SANS_REGULAR_16;
    private static GlyphPageFontRenderer CHAKRA;
    private static GlyphPageFontRenderer RAJDHANI;
    private static GlyphPageFontRenderer TITILLIUM;
    private static GlyphPageFontRenderer MICHROMA;
    private static GlyphPageFontRenderer POPPINS;
    private static GlyphPageFontRenderer SUPERHERO;

    public static GlyphPageFontRenderer getQUICKSAND() {
        if (QUICKSAND == null) QUICKSAND = GlyphPageFontRenderer.createFromID("/assets/alroca/font/font.ttf", 40, false, false, false);
        return QUICKSAND;
    }

    public static GlyphPageFontRenderer getBOLD() {
        if (BOLD == null) BOLD = GlyphPageFontRenderer.createStyled("/assets/alroca/font/unbounded.ttf", 40, Font.BOLD);
        return BOLD;
    }

    public static GlyphPageFontRenderer getLIGHT() {
        if (LIGHT == null) LIGHT = GlyphPageFontRenderer.createStyled("/assets/alroca/font/unbounded.ttf", 26, Font.PLAIN);
        return LIGHT;
    }

    public static GlyphPageFontRenderer getTIP() {
        if (TIP == null) TIP = GlyphPageFontRenderer.createStyled("/assets/alroca/font/unbounded.ttf", 31, Font.PLAIN);
        return TIP;
    }

    public static GlyphPageFontRenderer getSMALL() {
        if (SMALL == null) SMALL = GlyphPageFontRenderer.createStyled("/assets/alroca/font/unbounded.ttf", 18, Font.PLAIN);
        return SMALL;
    }

    public static GlyphPageFontRenderer getSMALLBOLD() {
        if (SMALLBOLD == null) SMALLBOLD = GlyphPageFontRenderer.createStyled("/assets/alroca/font/unbounded.ttf", 20, Font.BOLD);
        return SMALLBOLD;
    }

    public static GlyphPageFontRenderer getTITLE() {
        if (TITLE == null) TITLE = GlyphPageFontRenderer.createStyled("/assets/alroca/font/unbounded.ttf", 30, Font.BOLD);
        return TITLE;
    }

    public static GlyphPageFontRenderer getMENU() {
        if (MENU == null) MENU = GlyphPageFontRenderer.createStyled("/assets/alroca/font/unbounded.ttf", 24, Font.BOLD);
        return MENU;
    }

    public static GlyphPageFontRenderer getTINY() {
        if (TINY == null) TINY = GlyphPageFontRenderer.createStyled("/assets/alroca/font/unbounded.ttf", 15, Font.PLAIN);
        return TINY;
    }

    public static GlyphPageFontRenderer getLABEL() {
        if (LABEL == null) LABEL = GlyphPageFontRenderer.createStyled("/assets/alroca/font/misans.ttf", 30, Font.PLAIN);
        return LABEL;
    }

    public static GlyphPageFontRenderer getLABEL_MENU() {
        if (LABEL_MENU == null) LABEL_MENU = GlyphPageFontRenderer.createStyled("/assets/alroca/font/misans.ttf", 26, Font.PLAIN);
        return LABEL_MENU;
    }

    public static GlyphPageFontRenderer getLABEL_SMALL() {
        if (LABEL_SMALL == null) LABEL_SMALL = GlyphPageFontRenderer.createStyled("/assets/alroca/font/misans.ttf", 18, Font.PLAIN);
        return LABEL_SMALL;
    }

    public static GlyphPageFontRenderer getPRODUCT_SANS_MEDIUM_36() {
        if (PRODUCT_SANS_MEDIUM_36 == null) PRODUCT_SANS_MEDIUM_36 = GlyphPageFontRenderer.createStyled("/assets/alroca/font/product_sans_medium.ttf", 36, Font.PLAIN);
        return PRODUCT_SANS_MEDIUM_36;
    }

    public static GlyphPageFontRenderer getPRODUCT_SANS_MEDIUM_18() {
        if (PRODUCT_SANS_MEDIUM_18 == null) PRODUCT_SANS_MEDIUM_18 = GlyphPageFontRenderer.createStyled("/assets/alroca/font/product_sans_medium.ttf", 18, Font.PLAIN);
        return PRODUCT_SANS_MEDIUM_18;
    }

    public static GlyphPageFontRenderer getPRODUCT_SANS_REGULAR_32() {
        if (PRODUCT_SANS_REGULAR_32 == null) PRODUCT_SANS_REGULAR_32 = GlyphPageFontRenderer.createStyled("/assets/alroca/font/product_sans_regular.ttf", 32, Font.PLAIN);
        return PRODUCT_SANS_REGULAR_32;
    }

    public static GlyphPageFontRenderer getPRODUCT_SANS_REGULAR_16() {
        if (PRODUCT_SANS_REGULAR_16 == null) PRODUCT_SANS_REGULAR_16 = GlyphPageFontRenderer.createStyled("/assets/alroca/font/product_sans_regular.ttf", 16, Font.PLAIN);
        return PRODUCT_SANS_REGULAR_16;
    }

    public static GlyphPageFontRenderer getCHAKRA() {
        if (CHAKRA == null) CHAKRA = GlyphPageFontRenderer.createStyled("/assets/alroca/font/chakrapetch.ttf", 18, Font.PLAIN);
        return CHAKRA;
    }

    public static GlyphPageFontRenderer getRAJDHANI() {
        if (RAJDHANI == null) RAJDHANI = GlyphPageFontRenderer.createStyled("/assets/alroca/font/rajdhani.ttf", 21, Font.PLAIN);
        return RAJDHANI;
    }

    public static GlyphPageFontRenderer getTITILLIUM() {
        if (TITILLIUM == null) TITILLIUM = GlyphPageFontRenderer.createStyled("/assets/alroca/font/titilliumweb.ttf", 18, Font.PLAIN);
        return TITILLIUM;
    }

    public static GlyphPageFontRenderer getMICHROMA() {
        if (MICHROMA == null) MICHROMA = GlyphPageFontRenderer.createStyled("/assets/alroca/font/michroma.ttf", 15, Font.PLAIN);
        return MICHROMA;
    }

    public static GlyphPageFontRenderer getPOPPINS() {
        if (POPPINS == null) POPPINS = GlyphPageFontRenderer.createStyled("/assets/alroca/font/poppins.ttf", 18, Font.PLAIN);
        return POPPINS;
    }

    public static GlyphPageFontRenderer getSUPERHERO() {
        if (SUPERHERO == null) SUPERHERO = GlyphPageFontRenderer.createStyled("/assets/alroca/font/superherotufffont.ttf", 80, Font.PLAIN);
        return SUPERHERO;
    }

    /** Call on render thread to warm all fonts before first frame. Optional but prevents first-use stutter. */
    public static void preload() {
        getQUICKSAND(); getBOLD(); getLIGHT(); getTIP(); getSMALL(); getSMALLBOLD();
        getTITLE(); getMENU(); getTINY(); getLABEL(); getLABEL_MENU(); getLABEL_SMALL();
        getPRODUCT_SANS_MEDIUM_36(); getPRODUCT_SANS_MEDIUM_18();
        getPRODUCT_SANS_REGULAR_32(); getPRODUCT_SANS_REGULAR_16();
        getCHAKRA(); getRAJDHANI(); getTITILLIUM(); getMICHROMA(); getPOPPINS(); getSUPERHERO();
    }
}
