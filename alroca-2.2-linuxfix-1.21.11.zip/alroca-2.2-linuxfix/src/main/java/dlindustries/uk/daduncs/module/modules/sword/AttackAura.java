// Java 17 + Fabric 1.21.11
// File: AttackAura.java — full replacement
// Runtime: Fabric ModLoader, MinecraftClient tick thread
// Deps: AntibanbyDaduncs, RotatorManager, SilentAim, RotationUtils — all present in this repo

package dlindustries.uk.daduncs.module.modules.sword;

import dlindustries.uk.daduncs.Alroca;
import dlindustries.uk.daduncs.event.events.TickListener;
import dlindustries.uk.daduncs.managers.AntibanbyDaduncs;
import dlindustries.uk.daduncs.module.Category;
import dlindustries.uk.daduncs.module.Module;
import dlindustries.uk.daduncs.module.setting.bool;
import dlindustries.uk.daduncs.module.setting.number;
import dlindustries.uk.daduncs.utils.EncryptedString;
import dlindustries.uk.daduncs.utils.RotationUtils;
import dlindustries.uk.daduncs.utils.rotation.Rotation;
import dlindustries.uk.daduncs.utils.rotation.RotatorManager;
import dlindustries.uk.daduncs.utils.rotation.SilentRot;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.Hand;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

import java.util.concurrent.ThreadLocalRandom;

public final class AttackAura extends Module implements TickListener {

    private final number range = new number(EncryptedString.of("Range"), 2, 6, 3.0, 0.1)
            .setDescription(EncryptedString.of("Distance to hit players from"));
    private final number cooldown = new number(EncryptedString.of("Cooldown"), 0.5, 1, 0.95, 0.05)
            .setDescription(EncryptedString.of("Attack strength needed before hitting"));
    // rotatesiz: default OFF
    private final bool rotate = new bool(EncryptedString.of("Rotate"), false)
            .setDescription(EncryptedString.of("Sends rotations toward target (off = rotatesiz)"));
    private final bool throughWalls = new bool(EncryptedString.of("Through Walls"), false)
            .setDescription(EncryptedString.of("Also hits players you cannot see"));
    private final bool friendSafe = new bool(EncryptedString.of("Friend Safe"), true)
            .setDescription(EncryptedString.of("Never targets your friends"));
    private final bool onlyWeapon = new bool(EncryptedString.of("Only Weapon"), false)
            .setDescription(EncryptedString.of("Only attack while holding a weapon-class item"));

    // Jitter state
    private float jitteredThreshold = 0.95f;
    private int jitterRefreshCooldown = 0;

    // GCD state — persists across ticks for realistic aim smoothing
    private final double[] gcdRemainder = {0.0, 0.0};

    public AttackAura() {
        super(EncryptedString.of("Attack Aura"),
                EncryptedString.of("Automatically hits the nearest player in range — rotatesiz by default"),
                -1,
                Category.SWORD);
        addSettings(range, cooldown, rotate, throughWalls, friendSafe, onlyWeapon);
    }

    @Override
    public void onEnable() {
        eventManager.add(TickListener.class, this);
        jitteredThreshold = cooldown.getValueFloat();
        jitterRefreshCooldown = 0;
        super.onEnable();
    }

    @Override
    public void onDisable() {
        eventManager.remove(TickListener.class, this);
        // Release any pending silent rotation so we don't leave a stale lock
        Alroca.INSTANCE.rotatorManager.disable();
        super.onDisable();
    }

    private void refreshJitter() {
        float base = cooldown.getValueFloat();
        // ±5% variance — enough to break timing analysis, not enough to miss crits
        float variance = base * 0.05f;
        float delta = (float) (ThreadLocalRandom.current().nextDouble() * variance * 2 - variance);
        jitteredThreshold = MathHelper.clamp(base + delta, 0.5f, 1.0f);
        // Refresh every 4–9 ticks — aperiodic so Polar's timing FFT doesn't lock it
        jitterRefreshCooldown = 4 + ThreadLocalRandom.current().nextInt(6);
    }

    private PlayerEntity findTarget() {
        if (mc.world == null || mc.player == null) return null;

        PlayerEntity best = null;
        // Cap at 3.0 on ground, 2.7 while gliding — both under Polar's default
        // 3.0-block reach flag threshold (which triggers at ~3.1+ after hitbox)
        double reach = Math.min(range.getValue(), mc.player.isGliding() ? 2.7 : 3.0);
        double bestDistance = reach;
        Vec3d eye = mc.player.getEyePos();

        for (PlayerEntity player : mc.world.getPlayers()) {
            if (player == mc.player || !player.isAlive() || player.isSpectator()) continue;
            if (friendSafe.getValue() && Alroca.INSTANCE.getFriendManager().isFriend(player)) continue;
            if (!throughWalls.getValue() && !mc.player.canSee(player)) continue;
            // Skip targets in iframes — same-tick multi-hit is a flag
            if (player.hurtTime >= 2) continue;

            Box box = player.getBoundingBox();
            Vec3d closest = new Vec3d(
                    MathHelper.clamp(eye.x, box.minX, box.maxX),
                    MathHelper.clamp(eye.y, box.minY, box.maxY),
                    MathHelper.clamp(eye.z, box.minZ, box.maxZ));
            double distance = eye.distanceTo(closest);

            if (distance <= bestDistance) {
                bestDistance = distance;
                best = player;
            }
        }
        return best;
    }

    @Override
    public void onTick() {
        if (mc.player == null || mc.world == null || mc.interactionManager == null
                || mc.currentScreen != null) return;

        // ── Polar RotationOrder fix ──────────────────────────────────────────
        // Attack must arrive BEFORE movement in the same tick.
        // isAttackSent() means we already fired one; don't double-attack.
        // isMovementSent() means movement already went out this tick —
        // sending an attack now would be post-movement, which Polar flags.
        // We wait for next tick if movement already sent.
        if (AntibanbyDaduncs.isAttackSent()
                || AntibanbyDaduncs.isActionSent()
                || AntibanbyDaduncs.isMovementSent()) return;
        // ────────────────────────────────────────────────────────────────────

        if (jitterRefreshCooldown <= 0) {
            refreshJitter();
        } else {
            jitterRefreshCooldown--;
        }

        if (mc.player.getAttackCooldownProgress(0.5f) < jitteredThreshold) return;

        if (onlyWeapon.getValue()) {
            var stack = mc.player.getMainHandStack();
            if (stack.isEmpty()) return;
            String path = stack.getItem().toString().toLowerCase();
            if (!(path.contains("sword") || path.contains("axe") || path.contains("mace")
                    || path.contains("trident") || path.contains("spear"))) return;
        }

        PlayerEntity target = findTarget();
        if (target == null) return;

        // ── Rotation handling ────────────────────────────────────────────────
        if (rotate.getValue()) {
            Rotation raw = RotationUtils.getDirection(
                    mc.player.getEyePos(), target.getBoundingBox().getCenter());

            // GCD-quantized rotation — simulates discrete mouse movement steps.
            // applyGCD mutates gcdRemainder to accumulate sub-step error across
            // ticks, making the trajectory look like real mouse input.
            Rotation quantized = RotationUtils.applyGCD(
                    mc.player.getYaw(), mc.player.getPitch(),
                    (float) raw.yaw(), (float) raw.pitch(),
                    gcdRemainder, true);

            // SilentRot: queues the rotation into the NEXT PlayerMoveC2SPacket
            // without touching mc.player.yaw/pitch (client view stays).
            // The server sees the rotated look packet, then the attack packet
            // in correct order. RotatorManager releases after one movement tick.
            SilentRot.set((float) quantized.yaw(), (float) quantized.pitch(), this);
            Alroca.INSTANCE.rotatorManager.enable();
        }
        // rotate=false (rotatesiz): server sees attack from whatever direction
        // the player was actually looking. No rotation packets injected.
        // ────────────────────────────────────────────────────────────────────

        mc.interactionManager.attackEntity(mc.player, target);
        mc.player.swingHand(Hand.MAIN_HAND);
    }
}
