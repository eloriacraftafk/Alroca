package dev.marlow.crystal.module.impl

import dev.marlow.crystal.module.Module
import dev.marlow.crystal.module.setting.BoolSetting
import dev.marlow.crystal.module.setting.FloatSetting
import dev.marlow.crystal.module.setting.Randomizer
import net.minecraft.entity.LivingEntity
import net.minecraft.entity.player.PlayerEntity
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket
import net.minecraft.util.Hand
import net.minecraft.util.math.MathHelper
import kotlin.math.*

class AttackAura : Module("AttackAura", "Auto attacks nearest entity in range") {

    val range  = FloatSetting("Range",  3.0f, 1.0f, 3.2f)
    val rotate = BoolSetting("Rotate", true)

    private var lastSwing = 0L
    private var nextDelay = 0L

    override fun onEnable() { scheduleDelay() }

    private fun scheduleDelay() {
        nextDelay = Randomizer.gaussianLong(55L, 95L)
    }

    override fun onTick(player: PlayerEntity) {
        if (!enabled) return
        val world = mc.world ?: return
        val now   = System.currentTimeMillis()

        val cd = player.getAttackCooldownProgress(mc.tickDelta)
        if (cd < 0.98f) return
        if (now - lastSwing < nextDelay) return

        val target = world.entities
            .filterIsInstance<LivingEntity>()
            .filter { it != player && it.isAlive && dist(player, it) <= range.value }
            .minByOrNull { dist(player, it) } ?: return

        if (rotate.value) {
            val (yaw, pitch) = calcAngles(player, target)
            mc.networkHandler?.sendPacket(
                PlayerMoveC2SPacket.LookAndOnGround(yaw, pitch, player.isOnGround)
            )
        }

        player.swingHand(Hand.MAIN_HAND)
        mc.interactionManager?.attackEntity(player, target)

        lastSwing = now
        scheduleDelay()
    }

    private fun calcAngles(player: PlayerEntity, target: LivingEntity): Pair<Float, Float> {
        val dx = target.x - player.x
        val dy = target.eyeY - player.eyeY
        val dz = target.z - player.z
        val hDist = sqrt(dx * dx + dz * dz)
        val yaw   = Math.toDegrees(atan2(dz, dx)).toFloat() - 90f
        val pitch = -Math.toDegrees(atan2(dy, hDist)).toFloat()
        return Pair(yaw, MathHelper.clamp(pitch, -90f, 90f))
    }

    private fun dist(a: PlayerEntity, b: LivingEntity): Double {
        val dx = a.x - b.x; val dy = a.y - b.y; val dz = a.z - b.z
        return sqrt(dx * dx + dy * dy + dz * dz)
    }
}
