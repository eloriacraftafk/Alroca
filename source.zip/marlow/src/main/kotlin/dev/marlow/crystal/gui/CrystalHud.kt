package dev.marlow.crystal.gui

import dev.marlow.crystal.module.ModuleManager
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents
import net.minecraft.client.MinecraftClient
import net.minecraft.client.gui.DrawContext
import net.minecraft.client.option.KeyBinding
import net.minecraft.client.util.InputUtil
import org.lwjgl.glfw.GLFW

object CrystalHud {
    private val mc get() = MinecraftClient.getInstance()
    private lateinit var toggleKey: KeyBinding

    fun init() {
        toggleKey = KeyBindingHelper.registerKeyBinding(
            KeyBinding("key.crystal.menu", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_INSERT, "category.crystal")
        )
        ClientTickEvents.END_CLIENT_TICK.register {
            while (toggleKey.wasPressed()) {
                if (mc.currentScreen is CrystalScreen) mc.setScreen(null)
                else mc.setScreen(CrystalScreen())
            }
        }
    }

    fun render(drawContext: DrawContext) {
        if (mc.currentScreen is CrystalScreen) return

        // sol üst aktif modül listesi
        var y = 4
        ModuleManager.modules.filter { it.enabled }.forEach {
            drawContext.drawTextWithShadow(mc.textRenderer, "§5${it.name}", 4, y, 0xFFFFFF)
            y += 10
        }

        // toast bildirimleri
        ToastManager.render(drawContext)

        // TargetEsp ve diğer onRender modülleri
        ModuleManager.onRender(drawContext)
    }
}
