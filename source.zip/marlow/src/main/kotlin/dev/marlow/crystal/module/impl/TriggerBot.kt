package dev.marlow.crystal.module.impl

import dev.marlow.crystal.module.Module
import dev.marlow.crystal.module.setting.IntSetting
import dev.marlow.crystal.module.setting.Randomizer
import net.minecraft.entity.LivingEntity
import net.minecraft.entity.player.PlayerEntity
import net.minecraft.util.Hand

class TriggerBot : Module("TriggerBot", "Auto attack on crosshair target") {

    val minDelay = IntSetting("Min Delay", 85,  40, 300)
    val maxDelay = IntSetting("Max Delay", 145, 80, 500)

    private var lastAttack = 0L
    private var nextDelay  = 0L

    override fun onEnable() { scheduleNext() }

    private fun scheduleNext() {
        nextDelay = Randomizer.gaussianLong(
            minDelay.value.toLong(),
            maxDelay.value.toLong()
        )
    }

    override fun onTick(player: PlayerEntity) {
        if (!enabled) return
        val now = System.currentTimeMillis()
        if (now - lastAttack < nextDelay) return

        val entity = mc.targetedEntity ?: return
        if (entity !is LivingEntity || !entity.isAlive || entity == player) return

        val cd = player.getAttackCooldownProgress(mc.tickDelta)
        if (cd < 0.98f) return

        player.swingHand(Hand.MAIN_HAND)
        mc.interactionManager?.attackEntity(player, entity)

        lastAttack = now
        scheduleNext()
    }
}
