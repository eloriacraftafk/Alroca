package dev.marlow.crystal.module.impl

import dev.marlow.crystal.module.Module
import dev.marlow.crystal.module.setting.FloatSetting
import dev.marlow.crystal.module.setting.Randomizer
import net.minecraft.entity.LivingEntity
import net.minecraft.entity.player.PlayerEntity
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket
import net.minecraft.util.math.MathHelper
import kotlin.math.*

class AimAssist : Module("AimAssist", "Smooth aim toward nearest entity") {

    val fov      = FloatSetting("FOV",      180f, 90f, 360f)
    val strength = FloatSetting("Strength", 0.07f, 0.01f, 0.15f)
    val range    = FloatSetting("Range",    6.0f,  1.0f, 20.0f)
    val jitter   = FloatSetting("Jitter",   0.25f, 0.0f, 0.8f)

    private val GCD_STEP = 0.15f

    override fun onTick(player: PlayerEntity) {
        if (!enabled) return
        val world = mc.world ?: return

        val target = world.entities
            .filterIsInstance<LivingEntity>()
            .filter { it != player && it.isAlive && it.distanceTo(player) <= range.value }
            .filter { isInFov(player, it) }
            .minByOrNull { it.distanceTo(player) } ?: return

        val eyePos = player.eyePos
        val tPos   = target.eyePos
        val dx = tPos.x - eyePos.x
        val dy = tPos.y - eyePos.y
        val dz = tPos.z - eyePos.z
        val hDist  = sqrt(dx * dx + dz * dz)

        val tYaw   = Math.toDegrees(atan2(dz, dx)).toFloat() - 90f
        val tPitch = -Math.toDegrees(atan2(dy, hDist)).toFloat()

        val dYaw   = MathHelper.wrapDegrees(tYaw - player.yaw)
        val dPitch = MathHelper.wrapDegrees(tPitch - player.pitch)

        val jY = Randomizer.jitterF(jitter.value)
        val jP = Randomizer.jitterF(jitter.value * 0.5f)

        var newYaw   = player.yaw   + dYaw   * strength.value + jY
        var newPitch = player.pitch + dPitch * strength.value + jP
        newPitch = MathHelper.clamp(newPitch, -90f, 90f)

        newYaw   = snapToGrid(newYaw,   GCD_STEP)
        newPitch = snapToGrid(newPitch, GCD_STEP)

        player.yaw   = newYaw
        player.pitch = newPitch

        mc.networkHandler?.sendPacket(
            PlayerMoveC2SPacket.LookAndOnGround(newYaw, newPitch, player.isOnGround)
        )
    }

    private fun snapToGrid(value: Float, step: Float): Float =
        (value / step).roundToInt() * step

    private fun isInFov(player: PlayerEntity, entity: LivingEntity): Boolean {
        if (fov.value >= 360f) return true
        val dx = entity.x - player.x
        val dz = entity.z - player.z
        val angleToEntity = Math.toDegrees(atan2(dz, dx)).toFloat() - 90f
        val diff = abs(MathHelper.wrapDegrees(angleToEntity - player.yaw))
        return diff <= fov.value / 2f
    }
}
