package dev.marlow.crystal.mixin

import dev.marlow.crystal.module.ModuleManager
import net.minecraft.client.render.GameRenderer
import net.minecraft.client.gui.DrawContext
import org.spongepowered.asm.mixin.Mixin
import org.spongepowered.asm.mixin.injection.At
import org.spongepowered.asm.mixin.injection.Inject
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo

@Mixin(GameRenderer::class)
class MixinGameRenderer {

    @Inject(
        method = ["render"],
        at = [At("TAIL")]
    )
    private fun onRenderTail(tickDelta: Float, startTime: Long, tick: Boolean, ci: CallbackInfo) {
        // render hook — TargetEsp buradan beslenir
    }
}
