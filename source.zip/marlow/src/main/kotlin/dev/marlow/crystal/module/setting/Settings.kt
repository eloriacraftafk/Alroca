package dev.marlow.crystal.module.setting

class IntSetting(val name: String, default: Int, val min: Int, val max: Int) {
    var value: Int = default
}

class FloatSetting(val name: String, default: Float, val min: Float, val max: Float) {
    var value: Float = default
}

class BoolSetting(val name: String, default: Boolean) {
    var value: Boolean = default
}

object Randomizer {
    private val rng = java.util.Random()

    fun gaussian(): Double = rng.nextGaussian().coerceIn(-2.0, 2.0)

    fun gaussianLong(min: Long, max: Long): Long {
        val range = (max - min).toDouble()
        val g = (gaussian() + 2.0) / 4.0
        return min + (g * range).toLong()
    }

    fun uniform(min: Double, max: Double): Double = min + rng.nextDouble() * (max - min)

    fun jitterF(scale: Float): Float = (rng.nextGaussian() * scale).toFloat()
}
