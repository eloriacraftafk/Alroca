package dev.marlow.crystal

import dev.marlow.crystal.module.ModuleManager
import dev.marlow.crystal.gui.CrystalHud
import net.fabricmc.api.ClientModInitializer
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback
import net.minecraft.client.MinecraftClient

object CrystalMod : ClientModInitializer {
    val mc: MinecraftClient get() = MinecraftClient.getInstance()

    override fun onInitializeClient() {
        ModuleManager.init()
        CrystalHud.init()

        ClientTickEvents.END_CLIENT_TICK.register {
            ModuleManager.onTick()
        }

        HudRenderCallback.EVENT.register { drawContext, _ ->
            CrystalHud.render(drawContext)
        }
    }
}
