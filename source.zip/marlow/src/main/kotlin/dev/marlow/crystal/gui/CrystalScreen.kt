package dev.marlow.crystal.gui

import dev.marlow.crystal.module.Module
import dev.marlow.crystal.module.ModuleManager
import dev.marlow.crystal.module.setting.BoolSetting
import dev.marlow.crystal.module.setting.FloatSetting
import dev.marlow.crystal.module.setting.IntSetting
import net.minecraft.client.MinecraftClient
import net.minecraft.client.gui.DrawContext
import net.minecraft.client.gui.screen.Screen
import net.minecraft.text.Text
import org.lwjgl.glfw.GLFW

// CrystalScreen — 2 kolon GUI
// Sol tık: toggle | Sağ tık: ayarlar paneli | Orta tık: bind ekranı
class CrystalScreen : Screen(Text.literal("Crystal Optimizer")) {
    private val mc get() = MinecraftClient.getInstance()

    private val panelW = 260; private val panelH = 220
    private val colW   = 120; private val rowH   = 28; private val padding = 10

    private var settingsTarget: Module? = null
    private var bindTarget: Module?     = null
    private var waitingForBind          = false

    private val leftCol  get() = ModuleManager.modules.take(3)
    private val rightCol get() = ModuleManager.modules.drop(3).take(3)

    // slider drag state
    private var draggingSetting: Any?    = null
    private var dragStartX:      Double  = 0.0
    private var dragStartVal:    Float   = 0f

    // ---- RENDER ----

    override fun render(context: DrawContext, mouseX: Int, mouseY: Int, delta: Float) {
        val px = (width - panelW) / 2; val py = (height - panelH) / 2

        // arka plan
        context.fill(px, py, px + panelW, py + panelH, 0xE01a1a2e.toInt())
        context.fill(px, py, px + panelW, py + 20, 0xFF6a0dad.toInt())
        context.drawTextWithShadow(textRenderer, "§l§5Marlow's Crystal Optimizer", px + 8, py + 6, 0xFFFFFF)
        context.drawTextWithShadow(textRenderer, "§7Combat / Utility",   px + padding,             py + 24, 0xAAAAAA)
        context.drawTextWithShadow(textRenderer, "§7Movement / Visual",  px + padding + colW + 10, py + 24, 0xAAAAAA)

        leftCol.forEachIndexed  { i, m -> drawBtn(context, m, px + padding,             py + 36 + i * rowH, mouseX, mouseY) }
        rightCol.forEachIndexed { i, m -> drawBtn(context, m, px + padding + colW + 10, py + 36 + i * rowH, mouseX, mouseY) }

        settingsTarget?.let { drawSettings(context, it, px, py, mouseX, mouseY) }
        bindTarget?.let     { drawBind(context, it) }

        super.render(context, mouseX, mouseY, delta)
    }

    private fun drawBtn(context: DrawContext, mod: Module, x: Int, y: Int, mx: Int, my: Int) {
        val hovered = mx in x..(x + colW) && my in y..(y + rowH - 2)
        val bg = when { mod.enabled && hovered -> 0xFF8B00FF.toInt(); mod.enabled -> 0xFF6a0dad.toInt(); hovered -> 0xFF2a2a4e.toInt(); else -> 0xFF1e1e38.toInt() }
        context.fill(x, y, x + colW, y + rowH - 2, bg)
        context.fill(x + colW - 10, y + 10, x + colW - 5, y + 15, if (mod.enabled) 0xFF00FF88.toInt() else 0xFF555577.toInt())
        context.drawTextWithShadow(textRenderer, mod.name, x + 6, y + 10, 0xFFFFFF)
        val bLabel = if (mod.key != -1) "§8[${GLFW.glfwGetKeyName(mod.key, 0)?.uppercase() ?: "?"}]" else "§8[--]"
        context.drawTextWithShadow(textRenderer, bLabel, x + 6, y + 19, 0x888888)
    }

    private fun drawSettings(context: DrawContext, mod: Module, px: Int, py: Int, mx: Int, my: Int) {
        val sx = px + panelW + 4; val sy = py
        val sw = 150
        val settings = mod.settings
        val sh = 20 + settings.size * 22 + 10

        context.fill(sx, sy, sx + sw, sy + sh, 0xEE1a1a2e.toInt())
        context.fill(sx, sy, sx + sw, sy + 16, 0xFF6a0dad.toInt())
        context.drawTextWithShadow(textRenderer, "§l${mod.name}", sx + 4, sy + 4, 0xFFFFFF)

        settings.forEachIndexed { i, setting ->
            val ey = sy + 20 + i * 22
            when (setting) {
                is BoolSetting -> {
                    val col = if (setting.value) 0xFF00FF88.toInt() else 0xFF555577.toInt()
                    context.fill(sx + 4, ey, sx + sw - 4, ey + 16, 0xFF1e1e38.toInt())
                    context.drawTextWithShadow(textRenderer, setting.name, sx + 8, ey + 4, 0xFFFFFF)
                    context.fill(sx + sw - 20, ey + 3, sx + sw - 4, ey + 13, col)
                }
                is IntSetting -> {
                    context.fill(sx + 4, ey, sx + sw - 4, ey + 16, 0xFF1e1e38.toInt())
                    context.drawTextWithShadow(textRenderer, "${setting.name}: §a${setting.value}", sx + 8, ey + 4, 0xFFFFFF)
                    // slider bar
                    val barX = sx + 4; val barW = sw - 8
                    val fill = ((setting.value - setting.min).toFloat() / (setting.max - setting.min) * barW).toInt()
                    context.fill(barX, ey + 13, barX + barW, ey + 16, 0xFF333355.toInt())
                    context.fill(barX, ey + 13, barX + fill, ey + 16, 0xFF6a0dad.toInt())
                }
                is FloatSetting -> {
                    context.fill(sx + 4, ey, sx + sw - 4, ey + 16, 0xFF1e1e38.toInt())
                    context.drawTextWithShadow(textRenderer, "${setting.name}: §a${"%.2f".format(setting.value)}", sx + 8, ey + 4, 0xFFFFFF)
                    val barX = sx + 4; val barW = sw - 8
                    val fill = ((setting.value - setting.min) / (setting.max - setting.min) * barW).toInt()
                    context.fill(barX, ey + 13, barX + barW, ey + 16, 0xFF333355.toInt())
                    context.fill(barX, ey + 13, barX + fill, ey + 16, 0xFF6a0dad.toInt())
                }
            }
        }
    }

    private fun drawBind(context: DrawContext, mod: Module) {
        val bx = (width - 160) / 2; val by = (height - 60) / 2
        context.fill(bx, by, bx + 160, by + 60, 0xEE0d0d1a.toInt())
        context.fill(bx, by, bx + 160, by + 16, 0xFF6a0dad.toInt())
        context.drawTextWithShadow(textRenderer, "§lBind: ${mod.name}", bx + 4, by + 4, 0xFFFFFF)
        val label = if (waitingForBind) "§eBir tuşa bas..." else "§aBağlı: §f${if (mod.key != -1) GLFW.glfwGetKeyName(mod.key, 0)?.uppercase() ?: "?" else "--"}"
        context.drawTextWithShadow(textRenderer, label, bx + 4, by + 22, 0xFFFFFF)
        context.drawTextWithShadow(textRenderer, "§7[ESC = iptal  DEL = kaldır]", bx + 4, by + 44, 0x888888)
    }

    // ---- INPUT ----

    override fun mouseClicked(mouseX: Double, mouseY: Double, button: Int): Boolean {
        val px = (width - panelW) / 2; val py = (height - panelH) / 2
        if (bindTarget != null) return true

        // settings panel tıklaması
        settingsTarget?.let { mod ->
            val sx = px + panelW + 4; val sy = py; val sw = 150
            val settings = mod.settings
            if (mouseX >= sx && mouseX <= sx + sw) {
                settings.forEachIndexed { i, setting ->
                    val ey = sy + 20 + i * 22
                    if (mouseY >= ey && mouseY <= ey + 16) {
                        when (setting) {
                            is BoolSetting -> if (button == GLFW.GLFW_MOUSE_BUTTON_LEFT) setting.value = !setting.value
                            is IntSetting, is FloatSetting -> {
                                draggingSetting = setting
                                dragStartX  = mouseX
                                dragStartVal = when (setting) { is IntSetting -> setting.value.toFloat(); is FloatSetting -> setting.value; else -> 0f }
                            }
                        }
                        return true
                    }
                }
                return true
            }
        }

        // modül buton tıklaması
        val allWithPos = buildList {
            leftCol.forEachIndexed  { i, m -> add(Triple(m, px + padding,             py + 36 + i * rowH)) }
            rightCol.forEachIndexed { i, m -> add(Triple(m, px + padding + colW + 10, py + 36 + i * rowH)) }
        }
        for ((mod, bx, by) in allWithPos) {
            if (mouseX >= bx && mouseX <= bx + colW && mouseY >= by && mouseY <= by + rowH - 2) {
                when (button) {
                    GLFW.GLFW_MOUSE_BUTTON_LEFT   -> { if (settingsTarget == mod) settingsTarget = null else { mod.toggle(); settingsTarget = null }; return true }
                    GLFW.GLFW_MOUSE_BUTTON_RIGHT  -> { settingsTarget = if (settingsTarget == mod) null else mod; return true }
                    GLFW.GLFW_MOUSE_BUTTON_MIDDLE -> { bindTarget = mod; waitingForBind = true; return true }
                }
            }
        }
        if (button == GLFW.GLFW_MOUSE_BUTTON_LEFT && (mouseX < px || mouseX > px + panelW || mouseY < py || mouseY > py + panelH)) {
            if (settingsTarget == null) { mc.setScreen(null); return true }
            settingsTarget = null
        }
        return super.mouseClicked(mouseX, mouseY, button)
    }

    override fun mouseDragged(mouseX: Double, mouseY: Double, button: Int, deltaX: Double, deltaY: Double): Boolean {
        val setting = draggingSetting ?: return super.mouseDragged(mouseX, mouseY, button, deltaX, deltaY)
        val mod     = settingsTarget ?: return super.mouseDragged(mouseX, mouseY, button, deltaX, deltaY)
        val px      = (width - panelW) / 2; val sx = px + panelW + 4; val sw = 150
        val barW    = sw - 8
        val ratio   = ((mouseX - (sx + 4)) / barW).coerceIn(0.0, 1.0).toFloat()
        when (setting) {
            is IntSetting   -> setting.value   = (setting.min + ratio * (setting.max - setting.min)).toInt()
            is FloatSetting -> setting.value   = setting.min + ratio * (setting.max - setting.min)
        }
        return true
    }

    override fun mouseReleased(mouseX: Double, mouseY: Double, button: Int): Boolean {
        draggingSetting = null
        return super.mouseReleased(mouseX, mouseY, button)
    }

    override fun keyPressed(keyCode: Int, scanCode: Int, modifiers: Int): Boolean {
        if (bindTarget != null && waitingForBind) {
            when (keyCode) {
                GLFW.GLFW_KEY_ESCAPE -> { bindTarget = null; waitingForBind = false }
                GLFW.GLFW_KEY_DELETE -> { bindTarget!!.key = -1; bindTarget = null; waitingForBind = false }
                else                 -> { bindTarget!!.key = keyCode; bindTarget = null; waitingForBind = false }
            }
            return true
        }
        if (keyCode == GLFW.GLFW_KEY_ESCAPE) {
            if (settingsTarget != null) { settingsTarget = null; return true }
            mc.setScreen(null); return true
        }
        return super.keyPressed(keyCode, scanCode, modifiers)
    }

    override fun renderBackground(context: DrawContext, mouseX: Int, mouseY: Int, delta: Float) {
        context.fill(0, 0, width, height, 0x88000000.toInt())
    }
    override fun shouldPause() = false
}
