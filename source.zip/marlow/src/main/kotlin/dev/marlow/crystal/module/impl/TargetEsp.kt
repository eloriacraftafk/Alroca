package dev.marlow.crystal.module.impl

import dev.marlow.crystal.module.Module
import dev.marlow.crystal.module.setting.FloatSetting
import net.minecraft.client.gui.DrawContext
import net.minecraft.entity.LivingEntity
import net.minecraft.entity.player.PlayerEntity
import net.minecraft.util.math.Vec3d
import kotlin.math.*

// TargetEsp — hedefin ayakları altında beyaz/renkli circle
// baktığımızda veya vurduğumuzda çember belirir, 2 saniye sonra (120 tick) solar
// boyut ayarlanabilir, solar animasyon smooth
class TargetEsp : Module("TargetEsp", "Circle under target, fades after 2s") {

    val circleSize  = FloatSetting("Size",     1.0f, 0.3f, 3.0f)
    val fadeSeconds = FloatSetting("Fade",     2.0f, 0.5f, 5.0f)

    var currentTarget: LivingEntity? = null
    private var lastSeenTick  = 0L   // ms timestamp
    private val range         = 6.0
    private val CIRCLE_STEPS  = 32

    // dışarıdan da set edilebilir (AttackAura vurunca çağırır)
    fun notifyHit(entity: LivingEntity) {
        currentTarget = entity
        lastSeenTick  = System.currentTimeMillis()
    }

    override fun onTick(player: PlayerEntity) {
        if (!enabled) { currentTarget = null; return }
        val world = mc.world ?: return

        // bakış hedefi
        val looked = mc.targetedEntity
        if (looked is LivingEntity && looked != player && looked.isAlive) {
            currentTarget = looked
            lastSeenTick  = System.currentTimeMillis()
        }

        // 2 saniye (ayarlanabilir) geçtiyse hedefi unut
        val fadeDur = (fadeSeconds.value * 1000).toLong()
        if (System.currentTimeMillis() - lastSeenTick > fadeDur) {
            currentTarget = null
        }
    }

    override fun onRender(drawContext: DrawContext) {
        if (!enabled) return
        val target = currentTarget ?: return
        val camera = mc.gameRenderer.camera ?: return
        val window = mc.window

        val elapsed  = System.currentTimeMillis() - lastSeenTick
        val fadeDur  = (fadeSeconds.value * 1000).toLong()
        // alpha: 1.0 → 0.0 smooth solar
        val alpha    = (1.0 - elapsed.toDouble() / fadeDur).coerceIn(0.0, 1.0)
        val alphaInt = (alpha * 255).toInt()
        if (alphaInt <= 0) return

        val white = (alphaInt shl 24) or 0xFFFFFF

        // circle noktalarını world-to-screen çevir
        val baseY    = target.y                   // ayak seviyesi
        val cx       = target.x
        val cz       = target.z
        val r        = circleSize.value.toDouble()

        val screenW  = window.scaledWidth
        val screenH  = window.scaledHeight

        val points = mutableListOf<Pair<Int, Int>>()
        for (i in 0 until CIRCLE_STEPS) {
            val angle = 2.0 * Math.PI * i / CIRCLE_STEPS
            val wx    = cx + cos(angle) * r
            val wz    = cz + sin(angle) * r
            val sp    = worldToScreen(Vec3d(wx, baseY, wz), camera, screenW, screenH) ?: continue
            points.add(Pair(sp.first.toInt(), sp.second.toInt()))
        }

        if (points.size < 2) return

        // noktalar arası çizgi — drawContext.fill ile 1px segment
        for (i in points.indices) {
            val a = points[i]
            val b = points[(i + 1) % points.size]
            drawLine(drawContext, a.first, a.second, b.first, b.second, white)
        }
    }

    // Bresenham line — drawContext.fill ile 1px çizgi
    private fun drawLine(ctx: DrawContext, x0: Int, y0: Int, x1: Int, y1: Int, color: Int) {
        var dx = abs(x1 - x0); var dy = abs(y1 - y0)
        var x  = x0; var y = y0
        val sx = if (x0 < x1) 1 else -1
        val sy = if (y0 < y1) 1 else -1
        var err = dx - dy
        var steps = 0
        while (steps++ < 200) { // sonsuz döngü güvencesi
            ctx.fill(x, y, x + 1, y + 1, color)
            if (x == x1 && y == y1) break
            val e2 = 2 * err
            if (e2 > -dy) { err -= dy; x += sx }
            if (e2 < dx)  { err += dx; y += sy }
        }
    }

    private fun worldToScreen(worldPos: Vec3d, camera: net.minecraft.client.render.Camera, screenW: Int, screenH: Int): Pair<Double, Double>? {
        val camPos = camera.pos
        val rx = worldPos.x - camPos.x; val ry = worldPos.y - camPos.y; val rz = worldPos.z - camPos.z
        val pitch  = Math.toRadians(camera.pitch.toDouble())
        val yaw    = Math.toRadians(camera.yaw.toDouble())
        val sinY   = sin(yaw); val cosY = cos(yaw); val sinP = sin(pitch); val cosP = cos(pitch)
        val x      =  rx * cosY - rz * sinY
        val y      =  ry * cosP + (rx * sinY + rz * cosY) * sinP
        val z      = -ry * sinP + (rx * sinY + rz * cosY) * cosP
        if (z <= 0.0) return null
        val fov    = Math.toRadians(mc.options.fov.value.toDouble())
        val scale  = (screenH / 2.0) / tan(fov / 2.0)
        return Pair(screenW / 2.0 + (x / z) * scale, screenH / 2.0 - (y / z) * scale)
    }
}
