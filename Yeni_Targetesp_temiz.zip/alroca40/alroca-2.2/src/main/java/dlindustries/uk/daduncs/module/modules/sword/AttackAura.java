package dlindustries.uk.daduncs.module.modules.sword;

import dlindustries.uk.daduncs.event.events.TickListener;
import dlindustries.uk.daduncs.module.Category;
import dlindustries.uk.daduncs.module.Module;
import dlindustries.uk.daduncs.module.setting.bool;
import dlindustries.uk.daduncs.module.setting.mode;
import dlindustries.uk.daduncs.module.setting.number;
import dlindustries.uk.daduncs.utils.EncryptedString;
import dlindustries.uk.daduncs.utils.rotation.SilentRot;

import net.minecraft.client.gui.screen.ingame.HandledScreen;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.entity.passive.AnimalEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.AxeItem;
import net.minecraft.network.packet.c2s.play.ClientCommandC2SPacket;
import net.minecraft.util.Hand;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;

import java.util.Comparator;

public final class AttackAura extends Module implements TickListener {

    // ── Enums ────────────────────────────────────────────────────────────────

    public enum SortMode    { Smart, FOV, Distance, Health }
    public enum RotMode     { Funtime, Matrix, Snap, SpookyTime }
    public enum SprintBypass{ Funtime, Legit, Snap, SpookyTime }
    public enum MoveMode    { Silent, Strict, Target, Free }

    // ── Settings ─────────────────────────────────────────────────────────────

    private final mode<SortMode>     sort          = new mode<>(EncryptedString.of("Sort"),           SortMode.Smart,          SortMode.class);
    private final mode<RotMode>      rotMode       = new mode<>(EncryptedString.of("Rotation Mode"),  RotMode.Funtime,         RotMode.class);
    private final mode<SprintBypass> sprintBypass  = new mode<>(EncryptedString.of("Sprint Bypass"),  SprintBypass.Funtime,    SprintBypass.class);
    private final mode<MoveMode>     moveMode      = new mode<>(EncryptedString.of("Move Mode"),      MoveMode.Silent,         MoveMode.class);

    private final number reach      = new number(EncryptedString.of("Reach"),        1.0, 6.0, 3.0, 0.1);
    private final number aimExtra   = new number(EncryptedString.of("Aim Extra"),    0.0, 32.0, 0.0, 0.5);

    private final bool onlyCrits       = new bool(EncryptedString.of("Only Crits"),          true);
    private final bool walls           = new bool(EncryptedString.of("Through Walls"),        true);
    private final bool breakShield     = new bool(EncryptedString.of("Break Shield"),         true);
    private final bool hitShield       = new bool(EncryptedString.of("Hit Through Shield"),   true);
    private final bool stopUse         = new bool(EncryptedString.of("Stop While Using"),     false);
    private final bool stopContainer   = new bool(EncryptedString.of("Stop In Container"),    false);
    private final bool onlySpace       = new bool(EncryptedString.of("Only With Space"),      false);
    private final bool aimBow          = new bool(EncryptedString.of("Target Bow/Crossbow"),  false);

    private final bool tPlayers  = new bool(EncryptedString.of("Players"),    true);
    private final bool tNaked    = new bool(EncryptedString.of("Naked"),       true);
    private final bool tMobs     = new bool(EncryptedString.of("Mobs"),        true);
    private final bool tAnimals  = new bool(EncryptedString.of("Animals"),     false);
    private final bool tInvis    = new bool(EncryptedString.of("Invisible"),   true);

    // ── State ─────────────────────────────────────────────────────────────────

    private static AttackAura inst;

    private LivingEntity target;
    private float spookyProg;
    private boolean wantAttack;
    private int savedSlot = -1;

    // ── Constructor ───────────────────────────────────────────────────────────

    public AttackAura() {
        super(EncryptedString.of("Attack Aura"),
              EncryptedString.of("Automatically attacks nearby entities"),
              -1,
              Category.SWORD);

        addSettings(sort, rotMode, sprintBypass, moveMode,
                    reach, aimExtra,
                    onlyCrits, walls, breakShield, hitShield,
                    stopUse, stopContainer, onlySpace, aimBow,
                    tPlayers, tNaked, tMobs, tAnimals, tInvis);

        inst = this;
    }

    // ── Lifecycle ─────────────────────────────────────────────────────────────

    @Override
    public void onEnable() {
        eventManager.add(TickListener.class, this);
        super.onEnable();
    }

    @Override
    public void onDisable() {
        eventManager.remove(TickListener.class, this);
        target = null;
        wantAttack = false;
        SilentRot.stop(this);
        restoreSlot();
        super.onDisable();
    }

    // ── Public API ────────────────────────────────────────────────────────────

    public static LivingEntity target() {
        return inst != null && inst.isEnabled() ? inst.target : null;
    }

    // ── Tick ──────────────────────────────────────────────────────────────────

    @Override
    public void onTick() {
        var p = mc.player;
        if (p == null || mc.world == null) return;

        wantAttack = false;

        if ((stopUse.getValue() && p.isUsingItem()) ||
            (stopContainer.getValue() && mc.currentScreen instanceof HandledScreen<?>)) {
            target = null;
            SilentRot.stop(this);
            return;
        }

        double totalRange = reach.getValue() + aimExtra.getValue();
        LivingEntity best = pick(totalRange);

        if (target == null || !valid(target, totalRange) ||
            (!walls.getValue() && !p.canSee(target)) ||
            sort.index != 0) {
            target = best;
        }

        if (target == null) {
            SilentRot.stop(this);
            spookyProg = 0;
            restoreSlot();
            return;
        }

        double dist = Math.sqrt(p.squaredDistanceTo(target));
        boolean cd       = p.getAttackCooldownProgress(0.5f) >= 0.93f;
        boolean crit     = !onlyCrits.getValue() || critReady();
        boolean shieldOk = hitShield.getValue() || !(target instanceof PlayerEntity pe && pe.isBlocking());
        boolean ready    = dist <= reach.getValue() && cd && crit && shieldOk;

        computeRotation(target, ready);
        shieldSwap(target);
        wantAttack = ready;

        if (wantAttack && SilentRot.on() && hits(target, SilentRot.yaw(), SilentRot.pitch())) {
            doAttack(target);
            wantAttack = false;
            if (rotMode.index == 2) SilentRot.stop(this); // Snap
        }
    }

    // ── Targeting ─────────────────────────────────────────────────────────────

    private boolean valid(Entity e, double range) {
        if (!(e instanceof LivingEntity le) || e == mc.player || !le.isAlive() || le.getHealth() <= 0) return false;
        if (mc.player.squaredDistanceTo(le) > range * range) return false;
        if (le.isInvisible() && !tInvis.getValue()) return false;
        if (le instanceof PlayerEntity pe) {
            if (!tPlayers.getValue()) return false;
            if (!tNaked.getValue() &&
                pe.getEquippedStack(net.minecraft.entity.EquipmentSlot.CHEST).isEmpty() &&
                pe.getEquippedStack(net.minecraft.entity.EquipmentSlot.LEGS).isEmpty()) return false;
            return true;
        }
        if (le instanceof AnimalEntity) return tAnimals.getValue();
        if (le instanceof MobEntity)    return tMobs.getValue();
        return false;
    }

    private LivingEntity pick(double range) {
        Comparator<LivingEntity> cmp = switch (sort.index) {
            case 1 -> Comparator.comparingDouble(this::angleTo);
            case 2 -> Comparator.comparingDouble(e -> mc.player.squaredDistanceTo(e));
            case 3 -> Comparator.comparingDouble(LivingEntity::getHealth);
            default -> Comparator.comparingDouble(e ->
                    mc.player.squaredDistanceTo(e) * 0.6 + e.getHealth() * 0.8 + angleTo(e) * 0.05);
        };
        LivingEntity best = null;
        for (Entity e : mc.world.getEntities()) {
            if (!valid(e, range)) continue;
            if (!walls.getValue() && !mc.player.canSee(e)) continue;
            LivingEntity le = (LivingEntity) e;
            if (best == null || cmp.compare(le, best) < 0) best = le;
        }
        return best;
    }

    // ── Rotation ──────────────────────────────────────────────────────────────

    private float[] rotsTo(Entity e) {
        Vec3d eye = mc.player.getEyePos();
        Box b = e.getBoundingBox();
        double dx = (b.minX + b.maxX) / 2.0 - eye.x;
        double dy = (b.minY + b.maxY) / 2.0 - eye.y;
        double dz = (b.minZ + b.maxZ) / 2.0 - eye.z;
        double h  = Math.sqrt(dx * dx + dz * dz);
        float yaw   = (float)(Math.toDegrees(Math.atan2(dz, dx)) - 90.0);
        float pitch = (float)-Math.toDegrees(Math.atan2(dy, h));
        return new float[]{yaw, MathHelper.clamp(pitch, -90f, 90f)};
    }

    private float angleTo(Entity e) {
        float[] r = rotsTo(e);
        return Math.abs(MathHelper.wrapDegrees(r[0] - mc.player.getYaw()))
             + Math.abs(r[1] - mc.player.getPitch());
    }

    private float[] bestAim(LivingEntity t, float curYaw, float curPitch) {
        Box b  = t.getBoundingBox();
        double in = 0.08;
        Vec3d eye = mc.player.getEyePos();
        float[] best = null;
        double bestD = Double.MAX_VALUE;
        for (int iy = 0; iy <= 12; iy++) {
            double y = b.minY + in + (b.maxY - b.minY - 2 * in) * iy / 12.0;
            for (int k = 0; k <= 8; k++) {
                double f = k / 8.0;
                double[][] pts = {
                    {b.minX + in + (b.maxX - b.minX - 2 * in) * f, b.minZ + in},
                    {b.minX + in + (b.maxX - b.minX - 2 * in) * f, b.maxZ - in},
                    {b.minX + in, b.minZ + in + (b.maxZ - b.minZ - 2 * in) * f},
                    {b.maxX - in, b.minZ + in + (b.maxZ - b.minZ - 2 * in) * f}
                };
                for (double[] p : pts) {
                    double dx = p[0] - eye.x, dy2 = y - eye.y, dz = p[1] - eye.z;
                    double h  = Math.sqrt(dx * dx + dz * dz);
                    float yw  = (float)(Math.toDegrees(Math.atan2(dz, dx)) - 90.0);
                    float pt  = (float)-Math.toDegrees(Math.atan2(dy2, h));
                    double dist = Math.abs(MathHelper.wrapDegrees(yw - curYaw)) + Math.abs(pt - curPitch);
                    if (dist < bestD) { bestD = dist; best = new float[]{yw, pt}; }
                }
            }
        }
        return best != null ? best : rotsTo(t);
    }

    private static float step(float cur, float want, float max) {
        float d = MathHelper.wrapDegrees(want - cur);
        if (max < 0) return cur + d;
        return cur + MathHelper.clamp(d, -max, max);
    }

    private static float rnd(float a) {
        return (float)((Math.random() * 2 - 1) * a);
    }

    private void computeRotation(LivingEntity t, boolean attackNow) {
        float curY = SilentRot.on() ? SilentRot.yaw()   : mc.player.getYaw();
        float curP = SilentRot.on() ? SilentRot.pitch()  : mc.player.getPitch();
        float[] aim = bestAim(t, curY, curP);
        int tick = mc.player.age;
        float ny, np;
        switch (rotMode.index) {
            case 2 -> { // Snap
                if (!attackNow) { SilentRot.stop(this); return; }
                ny = aim[0]; np = aim[1];
            }
            case 1 -> { // Matrix
                float ty = aim[0] + (float)(Math.sin(tick) * 3.0) + rnd(0.5f);
                float tp = aim[1] + (float)(Math.cos(tick) * 0.5) + rnd(0.5f);
                ny = step(curY, ty, 52f);
                np = step(curP, tp, hits(t, curY, curP) ? 5f : -1f);
            }
            case 3 -> { // SpookyTime
                spookyProg = Math.min(1f, spookyProg + 0.12f + (float)Math.random() / 20f);
                float k = (float)Math.sin(spookyProg * Math.PI / 2.0);
                ny = curY + MathHelper.wrapDegrees(aim[0] - curY) * k;
                np = curP + (aim[1] - curP) * k;
            }
            default -> { // Funtime
                ny = step(curY, aim[0], 50f);
                np = step(curP, aim[1], 10f);
            }
        }
        double f   = mc.options.getMouseSensitivity().getValue() * 0.6 + 0.2;
        double gcd = f * f * f * 8.0 * 0.15;
        ny = curY + (float)(Math.round((ny - curY) / gcd) * gcd);
        np = curP + (float)(Math.round((np - curP) / gcd) * gcd);
        SilentRot.set(ny, MathHelper.clamp(np, -90f, 90f), this);
    }

    private boolean hits(LivingEntity t, float yaw, float pitch) {
        Vec3d eye = mc.player.getEyePos();
        double yr = Math.toRadians(yaw), pr = Math.toRadians(pitch);
        Vec3d dir = new Vec3d(-Math.sin(yr) * Math.cos(pr), -Math.sin(pr), Math.cos(yr) * Math.cos(pr));
        Vec3d end = eye.add(dir.multiply(reach.getValue()));
        var hit = t.getBoundingBox().raycast(eye, end);
        if (hit.isEmpty()) return false;
        if (walls.getValue()) return true;
        var bh = mc.world.raycast(new RaycastContext(eye, hit.get(),
                RaycastContext.ShapeType.COLLIDER, RaycastContext.FluidHandling.NONE, mc.player));
        return bh.getType() == net.minecraft.util.hit.HitResult.Type.MISS;
    }

    // ── Combat helpers ────────────────────────────────────────────────────────

    private boolean critReady() {
        var p = mc.player;
        if (onlySpace.getValue() && !mc.options.jumpKey.isPressed()) return true;
        return !p.isOnGround() && p.fallDistance > 0.0
            && !p.isClimbing() && !p.isTouchingWater()
            && !p.hasStatusEffect(StatusEffects.BLINDNESS) && !p.hasVehicle();
    }

    private void doAttack(LivingEntity t) {
        var p = mc.player;
        boolean sprint = p.isSprinting() && sprintBypass.index != 1;
        if (sprint) {
            p.networkHandler.sendPacket(new ClientCommandC2SPacket(p, ClientCommandC2SPacket.Mode.STOP_SPRINTING));
            p.setSprinting(false);
        }
        mc.interactionManager.attackEntity(p, t);
        p.swingHand(Hand.MAIN_HAND);
        if (sprint) {
            p.networkHandler.sendPacket(new ClientCommandC2SPacket(p, ClientCommandC2SPacket.Mode.START_SPRINTING));
            p.setSprinting(true);
        }
    }

    private void shieldSwap(LivingEntity t) {
        if (!breakShield.getValue() || !(t instanceof PlayerEntity pe) || !pe.isBlocking()) {
            restoreSlot();
            return;
        }
        var inv = mc.player.getInventory();
        for (int i = 0; i < 9; i++) {
            if (inv.getStack(i).getItem() instanceof AxeItem) {
                if (savedSlot < 0) savedSlot = inv.getSelectedSlot();
                inv.setSelectedSlot(i);
                return;
            }
        }
    }

    private void restoreSlot() {
        if (savedSlot >= 0 && mc.player != null)
            mc.player.getInventory().setSelectedSlot(savedSlot);
        savedSlot = -1;
    }
}
