/*
 * This file is part of System Client (https://github.com/daduncs/system)
 * Copyright (c) 2024 - 2026 DLindustries and project contributors.
 * Licensed under GNU GPLv3
 */

package dlindustries.uk.daduncs.mixin;

import org.spongepowered.asm.mixin.Mixin;
import net.minecraft.client.render.WorldRenderer;

@Mixin(WorldRenderer.class)
public class WorldRendererMixin {

}
