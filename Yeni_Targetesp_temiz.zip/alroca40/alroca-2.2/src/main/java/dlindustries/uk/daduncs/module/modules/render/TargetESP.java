/*
 * This file is part of System Client (https://github.com/daduncs/system)
 * Website: https://download.daduncs.cloud/
 *
 * Copyright (c) 2024 - 2026 DLindustries and project contributors.
 *
 * System Client is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * System Client is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with System Client. If not, see <https://www.gnu.org/licenses/>.
 */

package dlindustries.uk.daduncs.module.modules.render;

import dlindustries.uk.daduncs.event.events.AttackListener;
import dlindustries.uk.daduncs.event.events.GameRenderListener;
import dlindustries.uk.daduncs.event.events.TickListener;
import dlindustries.uk.daduncs.module.Category;
import dlindustries.uk.daduncs.module.Module;
import dlindustries.uk.daduncs.utils.EncryptedString;
import dlindustries.uk.daduncs.utils.RenderUtils;

import net.minecraft.client.render.Camera;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RotationAxis;
import net.minecraft.util.math.Vec3d;

import java.awt.*;

public final class TargetESP extends Module implements GameRenderListener, TickListener, AttackListener {

    // Hedef yok olmasından itibaren fade-out için timeout: 2 saniye
    private static final long TIMEOUT_MS = 2000L;

    // Halka segmenti sayısı (pürüzsüzlük)
    private static final int SEGMENTS = 64;

    private PlayerEntity target = null;
    private long lastInteractTime = 0L;

    // Fade animasyonu için alpha (0.0 → 1.0)
    private float fadeAlpha = 0f;

    public TargetESP() {
        super(
            EncryptedString.of("Target ESP"),
            EncryptedString.of("Shows a subtle ring under the player you're looking at or hitting"),
            -1,
            Category.RENDER
        );
    }

    @Override
    public void onEnable() {
        eventManager.add(GameRenderListener.class, this);
        eventManager.add(TickListener.class, this);
        eventManager.add(AttackListener.class, this);
        super.onEnable();
    }

    @Override
    public void onDisable() {
        eventManager.remove(GameRenderListener.class, this);
        eventManager.remove(TickListener.class, this);
        eventManager.remove(AttackListener.class, this);
        target = null;
        fadeAlpha = 0f;
        super.onDisable();
    }

    // Her tick'te crosshair'e baktığımız oyuncuyu güncelle
    @Override
    public void onTick() {
        if (mc.world == null || mc.player == null) return;

        PlayerEntity looked = getLookedPlayer();
        if (looked != null) {
            target = looked;
            lastInteractTime = System.currentTimeMillis();
        }

        // 2 saniye geçtiyse hedefi unut
        if (target != null && System.currentTimeMillis() - lastInteractTime > TIMEOUT_MS) {
            target = null;
        }

        // Hedef ölmüşse unut
        if (target != null && (!target.isAlive() || target.isRemoved())) {
            target = null;
        }
    }

    // Vurduğumuzda da lastInteractTime'ı güncelle
    @Override
    public void onAttack(AttackListener.AttackEvent event) {
        if (mc.crosshairTarget instanceof EntityHitResult hit
                && hit.getEntity() instanceof PlayerEntity player
                && player != mc.player) {
            target = player;
            lastInteractTime = System.currentTimeMillis();
        }
    }

    @Override
    public void onGameRender(GameRenderListener.GameRenderEvent event) {
        if (mc.world == null || mc.player == null) return;

        // Hedef var mı ve süresi dolmadı mı
        boolean hasTarget = target != null
                && System.currentTimeMillis() - lastInteractTime <= TIMEOUT_MS
                && target.isAlive()
                && !target.isRemoved();

        // Fade animasyonu: hedef varsa alpha artır, yoksa azalt
        float delta = (float) RenderUtils.deltaTime();
        if (hasTarget) {
            fadeAlpha = Math.min(1f, fadeAlpha + delta * 4f); // ~250ms fade-in
        } else {
            fadeAlpha = Math.max(0f, fadeAlpha - delta * 2f); // ~500ms fade-out
        }

        if (fadeAlpha <= 0f) return;

        PlayerEntity renderTarget = hasTarget ? target : target; // animasyon bitene kadar son hedefi kullan
        if (renderTarget == null) return;

        Camera camera = mc.gameRenderer.getCamera();
        if (camera == null) return;

        MatrixStack matrices = event.matrices;
        matrices.push();

        Vec3d camPos = camera.getCameraPos();
        matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(camera.getPitch()));
        matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(camera.getYaw() + 180f));
        matrices.translate(-camPos.x, -camPos.y, -camPos.z);

        // Hitbox'ın tam tabanına yerleştir (lerp ile pürüzsüz)
        float td = event.delta;
        double px = MathHelper.lerp(td, renderTarget.lastX, renderTarget.getX());
        double py = MathHelper.lerp(td, renderTarget.lastY, renderTarget.getY());
        double pz = MathHelper.lerp(td, renderTarget.lastZ, renderTarget.getZ());

        double halfW = renderTarget.getBoundingBox().getLengthX() / 2.0;

        // Halka rengi: beyaz, hafif şeffaf
        // fadeAlpha ile çarp, maksimum alpha 60 (yaklaşık %24) → "hafiften belli"
        int alpha = (int) (fadeAlpha * 60f);
        Color ringColor = new Color(255, 255, 255, alpha);

        drawRing(matrices, px, py, pz, halfW, ringColor);

        matrices.pop();
    }

    /**
     * Yatay bir halka çizer. centerY = tabanın Y'si, radius = hitbox yarı genişliği.
     */
    private void drawRing(MatrixStack matrices, double cx, double centerY, double cz,
                           double radius, Color color) {
        double step = (2 * Math.PI) / SEGMENTS;
        for (int i = 0; i < SEGMENTS; i++) {
            double angle1 = i * step;
            double angle2 = (i + 1) * step;

            double x1 = cx + Math.cos(angle1) * radius;
            double z1 = cz + Math.sin(angle1) * radius;
            double x2 = cx + Math.cos(angle2) * radius;
            double z2 = cz + Math.sin(angle2) * radius;

            // Y'yi tabanın biraz üstüne koy (0.02) ki zeminden geçmesin
            RenderUtils.renderLine(
                matrices,
                color,
                new Vec3d(x1, centerY + 0.02, z1),
                new Vec3d(x2, centerY + 0.02, z2),
                1.0f
            );
        }
    }

    private PlayerEntity getLookedPlayer() {
        if (!(mc.crosshairTarget instanceof EntityHitResult hit)) return null;
        if (!(hit.getEntity() instanceof PlayerEntity player)) return null;
        if (player == mc.player) return null;
        if (!player.isAlive()) return null;
        return player;
    }
}
