/*
 * Patch: ElytraHelper — Bypass hardening
 * Changes:
 *   1. Slot-swap-use-swap triple within one tick is a known flag on NCP
 *      InventoryMove (InventoryMove.SameTickSwap). Added 1-tick defer on
 *      the restore SWAP so the sequence spans two ticks: SWAP tick N,
 *      USE + restore-SWAP tick N+1.
 *   2. Firework use while gliding skips the slot-based path when offhand
 *      or mainhand already holds a rocket — no inventory touch, no flag.
 *   3. repeatDelay lower bound enforced at 2 ticks (was 1) to avoid
 *      ItemUse speed flags on servers with UseItemSpam thresholds.
 */

package dlindustries.uk.daduncs.module.modules.sword;

import dlindustries.uk.daduncs.event.events.TickListener;
import dlindustries.uk.daduncs.module.Category;
import dlindustries.uk.daduncs.module.Module;
import dlindustries.uk.daduncs.module.setting.bind;
import dlindustries.uk.daduncs.module.setting.bool;
import dlindustries.uk.daduncs.module.setting.number;
import dlindustries.uk.daduncs.utils.EncryptedString;
import dlindustries.uk.daduncs.utils.KeyUtils;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.item.Items;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.util.Hand;

/**
 * ElytraHelper — Uses a firework from your inventory on key press without
 * permanently holding it. The slot-swap sequence is split across two ticks
 * to avoid NCP InventoryMove.SameTickSwap flags.
 */
public final class ElytraHelper extends Module implements TickListener {

    private final bind fireworkKey = new bind(EncryptedString.of("Firework Key"), -1, false)
            .setDescription(EncryptedString.of("Press this key to use a firework from your inventory"));

    private final bool onlyWhileGliding = new bool(EncryptedString.of("Only While Gliding"), false)
            .setDescription(EncryptedString.of("Only use the firework while flying with an elytra"));

    private final bool holdToRepeat = new bool(EncryptedString.of("Hold To Repeat"), false)
            .setDescription(EncryptedString.of("Keep using fireworks while the key is held"));

    private final number repeatDelay = new number(EncryptedString.of("Repeat Delay"), 2, 40, 10, 1)
            .setDescription(EncryptedString.of("Ticks between fireworks when holding the key (20 ticks = 1 second)"));

    private boolean wasPressed;
    private int cooldown;

    // Bypass: deferred restore state — slotId to restore, 0 = none pending
    private int pendingRestoreSlotId   = -1;
    private int pendingRestoreTargetSlot = -1;

    public ElytraHelper() {
        super(EncryptedString.of("Elytra Helper"),
                EncryptedString.of("Uses a firework from your inventory when you press the key, without holding it"),
                -1,
                Category.SWORD);
        addSettings(fireworkKey, onlyWhileGliding, holdToRepeat, repeatDelay);
    }

    @Override
    public void onEnable() {
        eventManager.add(TickListener.class, this);
        wasPressed = false;
        cooldown = 0;
        pendingRestoreSlotId = -1;
        super.onEnable();
    }

    @Override
    public void onDisable() {
        eventManager.remove(TickListener.class, this);
        wasPressed = false;
        cooldown = 0;
        pendingRestoreSlotId = -1;
        super.onDisable();
    }

    @Override
    public void onTick() {
        if (mc.player == null || mc.world == null || mc.interactionManager == null) {
            wasPressed = false;
            return;
        }
        if (mc.currentScreen != null) {
            wasPressed = false;
            return;
        }

        // Bypass: tick N+1 — flush the deferred restore SWAP before anything else.
        // This completes the split-tick sequence: SWAP→USE on tick N,
        // restore-SWAP on tick N+1. NCP InventoryMove.SameTickSwap requires all
        // three to land in the same tick to flag; this survives it.
        if (pendingRestoreSlotId != -1) {
            int syncId = mc.player.playerScreenHandler.syncId;
            mc.interactionManager.clickSlot(syncId, pendingRestoreSlotId,
                    pendingRestoreTargetSlot, SlotActionType.SWAP, mc.player);
            pendingRestoreSlotId = -1;
            pendingRestoreTargetSlot = -1;
            // Don't process key this tick — give the server one clean tick
            // to see the restore before the next use.
            return;
        }

        if (cooldown > 0) cooldown--;

        int key = fireworkKey.getKey();
        if (key == -1) return;

        boolean pressed = KeyUtils.isKeyPressed(key);

        if (pressed && !wasPressed) {
            useFirework();
            cooldown = Math.max(2, repeatDelay.getValueInt());
        } else if (pressed && holdToRepeat.getValue() && cooldown <= 0) {
            useFirework();
            cooldown = Math.max(2, repeatDelay.getValueInt());
        }

        wasPressed = pressed;
    }

    private void useFirework() {
        if (onlyWhileGliding.getValue() && !mc.player.isGliding()) return;

        ClientPlayerEntity player = mc.player;
        int selected = player.getInventory().getSelectedSlot();

        // Fast path — mainhand already has rocket, no inventory touch.
        if (player.getInventory().getStack(selected).isOf(Items.FIREWORK_ROCKET)) {
            mc.interactionManager.interactItem(player, Hand.MAIN_HAND);
            return;
        }

        // Fast path — offhand has rocket, no inventory touch.
        if (player.getOffHandStack().isOf(Items.FIREWORK_ROCKET)) {
            mc.interactionManager.interactItem(player, Hand.OFF_HAND);
            return;
        }

        // Scan inventory for a rocket slot.
        int from = -1;
        for (int i = 0; i < 36; i++) {
            if (i == selected) continue;
            if (player.getInventory().getStack(i).isOf(Items.FIREWORK_ROCKET)) {
                from = i;
                break;
            }
        }
        if (from == -1) return;

        // Container slot id: hotbar 0–8 → 36–44; main inventory 9–35 → 9–35
        int slotId = from < 9 ? 36 + from : from;
        int syncId = player.playerScreenHandler.syncId;

        // Bypass: split tick — SWAP + USE this tick, restore SWAP next tick.
        mc.interactionManager.clickSlot(syncId, slotId, selected, SlotActionType.SWAP, player);
        mc.interactionManager.interactItem(player, Hand.MAIN_HAND);

        // Queue restore for tick N+1 instead of issuing it now.
        pendingRestoreSlotId    = slotId;
        pendingRestoreTargetSlot = selected;
    }
}
