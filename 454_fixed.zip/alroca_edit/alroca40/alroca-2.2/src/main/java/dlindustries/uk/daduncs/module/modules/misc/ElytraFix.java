/*
 * This file is part of System Client (https://github.com/daduncs/system)
 * Website: https://download.daduncs.cloud/
 *
 * Copyright (c) 2024 - 2026 DLindustries and project contributors.
 *
 * System Client is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * System Client is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with System Client. If not, see <https://www.gnu.org/licenses/>.
 */

package dlindustries.uk.daduncs.module.modules.misc;

import dlindustries.uk.daduncs.event.events.ItemUseListener;
import dlindustries.uk.daduncs.event.events.PacketSendListener;
import dlindustries.uk.daduncs.event.events.TickListener;
import dlindustries.uk.daduncs.module.Category;
import dlindustries.uk.daduncs.module.Module;
import dlindustries.uk.daduncs.module.setting.bool;
import dlindustries.uk.daduncs.utils.EncryptedString;

import net.minecraft.entity.EquipmentSlot;
import net.minecraft.item.Items;
import net.minecraft.network.packet.Packet;
import net.minecraft.network.packet.c2s.play.ClientCommandC2SPacket;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.EntityHitResult;

public final class ElytraFix extends Module implements TickListener, PacketSendListener, ItemUseListener {

    private final bool antiStop = new bool(EncryptedString.of("Anti Stop"), true)
            .setDescription(EncryptedString.of("Prevents elytra from stopping when taking damage"));
    private final bool autoStart = new bool(EncryptedString.of("Auto Start"), true)
            .setDescription(EncryptedString.of("Automatically starts gliding when falling with elytra equipped"));
    private final bool noFallDamage = new bool(EncryptedString.of("No Fall Damage"), false)
            .setDescription(EncryptedString.of("Sends stop-gliding packet on landing to cancel fall damage"));
    private final bool fireworkOnEntity = new bool(EncryptedString.of("Firework On Entity"), true)
            .setDescription(EncryptedString.of("Forces firework use even when aiming at an entity while gliding"));

    private boolean wasGliding = false;

    public ElytraFix() {
        super(
                EncryptedString.of("Elytra Fix"),
                EncryptedString.of("Fixes elytra flight issues such as random stops and fall damage"),
                -1,
                Category.MISC
        );
        addSettings(antiStop, autoStart, noFallDamage, fireworkOnEntity);
    }

    @Override
    public void onEnable() {
        eventManager.add(TickListener.class, this);
        eventManager.add(PacketSendListener.class, this);
        eventManager.add(ItemUseListener.class, this);
        wasGliding = false;
        super.onEnable();
    }

    @Override
    public void onDisable() {
        eventManager.remove(TickListener.class, this);
        eventManager.remove(PacketSendListener.class, this);
        eventManager.remove(ItemUseListener.class, this);
        wasGliding = false;
        super.onDisable();
    }

    @Override
    public void onTick() {
        if (mc.player == null || mc.world == null) return;

        boolean hasElytra = mc.player.getEquippedStack(EquipmentSlot.CHEST).isOf(Items.ELYTRA);
        boolean isGliding = mc.player.isGliding();
        boolean isFalling = mc.player.getVelocity().y < -0.1;
        boolean isOnGround = mc.player.isOnGround();

        // Auto Start: falling with elytra but not gliding -> start glide
        if (autoStart.getValue() && hasElytra && !isGliding && isFalling && !isOnGround) {
            mc.player.networkHandler.sendPacket(
                new ClientCommandC2SPacket(mc.player, ClientCommandC2SPacket.Mode.START_FALL_FLYING)
            );
        }

        // No Fall Damage: just landed after gliding -> cancel fall damage via stop packet
        if (noFallDamage.getValue() && wasGliding && isOnGround) {
            mc.player.networkHandler.sendPacket(
                new ClientCommandC2SPacket(mc.player, ClientCommandC2SPacket.Mode.START_FALL_FLYING)
            );
        }

        wasGliding = isGliding;
    }

    @Override
    public void onItemUse(ItemUseEvent event) {
        if (mc.player == null || mc.interactionManager == null) return;
        if (!fireworkOnEntity.getValue()) return;
        if (!mc.player.isGliding()) return;

        // Sadece firework tutarken çalış
        boolean mainHasFirework = mc.player.getMainHandStack().isOf(Items.FIREWORK_ROCKET);
        boolean offHasFirework  = mc.player.getOffHandStack().isOf(Items.FIREWORK_ROCKET);
        if (!mainHasFirework && !offHasFirework) return;

        // Crosshair bir entity'ye bakıyorsa oyun doItemUse'u çağırmaz, biz zorla çağırıyoruz
        if (mc.crosshairTarget instanceof EntityHitResult) {
            Hand hand = mainHasFirework ? Hand.MAIN_HAND : Hand.OFF_HAND;
            mc.interactionManager.interactItem(mc.player, hand);
            // orijinal event'i iptal et ki çift paket gitmesin
            event.cancel();
        }
    }

    @Override
    public void onPacketSend(PacketSendEvent event) {
        if (mc.player == null) return;

        Packet<?> packet = event.packet;

        // Anti Stop: hasar alınca oyun tarafından gönderilen stop-gliding paketini iptal et
        if (antiStop.getValue() && mc.player.isGliding()) {
            if (packet instanceof ClientCommandC2SPacket cmd) {
                if (cmd.getMode() == ClientCommandC2SPacket.Mode.START_FALL_FLYING) {
                    if (!mc.player.isOnGround() && mc.player.getVelocity().y < 0) {
                        event.cancel();
                    }
                }
            }
        }
    }
}
