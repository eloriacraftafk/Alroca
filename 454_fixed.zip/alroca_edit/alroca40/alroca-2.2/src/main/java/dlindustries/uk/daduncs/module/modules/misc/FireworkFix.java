/*
 * This file is part of System Client (https://github.com/daduncs/system)
 * Website: https://download.daduncs.cloud/
 *
 * Copyright (c) 2024 - 2026 DLindustries and project contributors.
 *
 * System Client is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * System Client is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with System Client. If not, see <https://www.gnu.org/licenses/>.
 */

package dlindustries.uk.daduncs.module.modules.misc;

import dlindustries.uk.daduncs.event.events.PacketSendListener;
import dlindustries.uk.daduncs.event.events.TickListener;
import dlindustries.uk.daduncs.module.Category;
import dlindustries.uk.daduncs.module.Module;
import dlindustries.uk.daduncs.module.setting.bool;
import dlindustries.uk.daduncs.module.setting.number;
import dlindustries.uk.daduncs.utils.EncryptedString;
import dlindustries.uk.daduncs.utils.TimerUtils;

import net.minecraft.item.Items;
import net.minecraft.network.packet.Packet;
import net.minecraft.network.packet.c2s.play.PlayerInteractItemC2SPacket;
import net.minecraft.util.Hand;

public final class FireworkFix extends Module implements TickListener, PacketSendListener {

    private final bool antiSpam = new bool(EncryptedString.of("Anti Spam"), true)
            .setDescription(EncryptedString.of("Prevents sending duplicate firework use packets in the same tick"));
    private final bool requireGliding = new bool(EncryptedString.of("Require Gliding"), true)
            .setDescription(EncryptedString.of("Only allow firework use while actually gliding with elytra"));
    private final number cooldown = new number(EncryptedString.of("Cooldown"), 0, 10, 2, 1)
            .setDescription(EncryptedString.of("Minimum ticks between firework uses (0 = no limit)"));

    private final TimerUtils timer = new TimerUtils();
    private boolean firedThisTick = false;

    public FireworkFix() {
        super(
                EncryptedString.of("Firework Fix"),
                EncryptedString.of("Fixes firework rocket usage issues while flying with elytra"),
                -1,
                Category.MISC
        );
        addSettings(antiSpam, requireGliding, cooldown);
    }

    @Override
    public void onEnable() {
        eventManager.add(TickListener.class, this);
        eventManager.add(PacketSendListener.class, this);
        firedThisTick = false;
        timer.reset();
        super.onEnable();
    }

    @Override
    public void onDisable() {
        eventManager.remove(TickListener.class, this);
        eventManager.remove(PacketSendListener.class, this);
        firedThisTick = false;
        super.onDisable();
    }

    @Override
    public void onTick() {
        // Reset per-tick flag each tick
        firedThisTick = false;
    }

    @Override
    public void onPacketSend(PacketSendEvent event) {
        if (mc.player == null) return;

        Packet<?> packet = event.packet;

        if (!(packet instanceof PlayerInteractItemC2SPacket)) return;

        // Check if player is holding a firework rocket
        boolean mainHasFirework = mc.player.getMainHandStack().isOf(Items.FIREWORK_ROCKET);
        boolean offHasFirework = mc.player.getOffHandStack().isOf(Items.FIREWORK_ROCKET);
        if (!mainHasFirework && !offHasFirework) return;

        // Require Gliding: block firework use if not gliding
        if (requireGliding.getValue() && !mc.player.isGliding()) {
            event.cancel();
            return;
        }

        // Anti Spam: block duplicate firework packets in same tick
        if (antiSpam.getValue() && firedThisTick) {
            event.cancel();
            return;
        }

        // Cooldown: block if fired too recently
        long cooldownMs = cooldown.getValueLong() * 50L;
        if (cooldownMs > 0 && !timer.hasReached(cooldownMs)) {
            event.cancel();
            return;
        }

        firedThisTick = true;
        timer.reset();
    }
}
