/*
 * This file is part of System Client (https://github.com/daduncs/system)
 * Website: https://download.daduncs.cloud/
 *
 * Copyright (c) 2024 - 2026 DLindustries and project contributors.
 *
 * System Client is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * System Client is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with System Client. If not, see <https://www.gnu.org/licenses/>.
 */

package dlindustries.uk.daduncs.module.modules.render;

import dlindustries.uk.daduncs.module.Category;
import dlindustries.uk.daduncs.module.Module;
import dlindustries.uk.daduncs.module.setting.number;
import dlindustries.uk.daduncs.utils.EncryptedString;

public final class SwordAnimation extends Module {

    // Maksimum tilt açısı (sola yatma)
    public final number tiltAngle = new number(EncryptedString.of("Tilt Açısı"), 5, 60, 25, 1)
            .setDescription(EncryptedString.of("Salınımın sola yatma açısı"));

    // Animasyon hızı (ne kadar hızlı yatıp geri gelecek)
    public final number speed = new number(EncryptedString.of("Hız"), 1, 20, 8, 1)
            .setDescription(EncryptedString.of("Animasyon hızı"));

    public SwordAnimation() {
        super(EncryptedString.of("Sword Animation"),
                EncryptedString.of("Vururken el sabit kalır, sadece sola yatıp geri gelir"),
                -1,
                Category.RENDER);
        addSettings(tiltAngle, speed);
    }
}
