/*
 * This file is part of System Client (https://github.com/daduncs/system)
 * Website: https://download.daduncs.cloud/
 *
 * Copyright (c) 2024 - 2026 DLindustries and project contributors.
 *
 * System Client is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * System Client is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with System Client. If not, see <https://www.gnu.org/licenses/>.
 */

package dlindustries.uk.daduncs.module.modules.render;

import dlindustries.uk.daduncs.event.events.AttackListener;
import dlindustries.uk.daduncs.event.events.GameRenderListener;
import dlindustries.uk.daduncs.module.Category;
import dlindustries.uk.daduncs.module.Module;
import dlindustries.uk.daduncs.module.setting.colour;
import dlindustries.uk.daduncs.module.setting.number;
import dlindustries.uk.daduncs.utils.EncryptedString;
import dlindustries.uk.daduncs.utils.RenderUtils;
import net.minecraft.client.render.Camera;
import net.minecraft.client.render.RenderLayers;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.math.RotationAxis;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;

import java.awt.Color;

public final class TargetESP extends Module implements GameRenderListener, AttackListener {

    private static final int RING_SEGMENTS = 48;
    private static final long TARGET_TIMEOUT = 2000; // 2 saniye

    private final number size = new number(EncryptedString.of("Boyut"), 0.5, 3.0, 1.1, 0.05)
            .setDescription(EncryptedString.of("ESP halkasının boyutu"));
    private final number spin = new number(EncryptedString.of("Dönüş Hızı"), 0.0, 10.0, 2.5, 0.5)
            .setDescription(EncryptedString.of("Halkaların dönüş hızı"));
    private final number alpha = new number(EncryptedString.of("Opaklık"), 0, 255, 180, 5)
            .setDescription(EncryptedString.of("ESP'nin saydamlığı"));
    private final colour color = new colour(EncryptedString.of("Renk"), 0xFFD050FF)
            .setDescription(EncryptedString.of("ESP rengi"));
    private final colour color2 = new colour(EncryptedString.of("İkinci Renk"), 0xFFFF50C8)
            .setDescription(EncryptedString.of("İkinci halka rengi"));

    // Son vurduğumuz hedef ve vuruş zamanı
    private PlayerEntity attackedTarget = null;
    private long lastAttackTime = 0;

    public TargetESP() {
        super(EncryptedString.of("Target ESP"),
                EncryptedString.of("Baktığın ve vurduğun oyuncunun üstünde dönen renkli halka gösterir"),
                -1,
                Category.RENDER);
        addSettings(size, spin, alpha, color, color2);
    }

    @Override
    public void onEnable() {
        eventManager.add(GameRenderListener.class, this);
        eventManager.add(AttackListener.class, this);
        super.onEnable();
    }

    @Override
    public void onDisable() {
        eventManager.remove(GameRenderListener.class, this);
        eventManager.remove(AttackListener.class, this);
        attackedTarget = null;
        super.onDisable();
    }

    // Sol tık vurulduğunda hedefi ve zamanı kaydet
    @Override
    public void onAttack(AttackEvent event) {
        if (mc.crosshairTarget instanceof EntityHitResult hit && hit.getEntity() instanceof PlayerEntity p) {
            attackedTarget = p;
            lastAttackTime = System.currentTimeMillis();
        }
    }

    @Override
    public void onGameRender(GameRenderEvent event) {
        if (mc.world == null || mc.player == null) return;

        PlayerEntity target = null;

        // 1. Baktığımız oyuncu varsa — sönmez
        if (mc.crosshairTarget instanceof EntityHitResult hit && hit.getEntity() instanceof PlayerEntity p) {
            target = p;
            // Baktığımız sürece attack timer'ı da sıfırla (bakıyorken zamanlayıcı dolmasın)
            if (attackedTarget == p) {
                lastAttackTime = System.currentTimeMillis();
            }
        }
        // 2. Bakılmıyor ama son 2sn içinde vurulmuşsa
        else if (attackedTarget != null
                && attackedTarget.isAlive()
                && !attackedTarget.isRemoved()
                && System.currentTimeMillis() - lastAttackTime < TARGET_TIMEOUT) {
            target = attackedTarget;
        }

        // Hedef ölmüşse temizle
        if (attackedTarget != null && (!attackedTarget.isAlive() || attackedTarget.isRemoved())) {
            attackedTarget = null;
        }

        if (target == null) return;

        Camera camera = mc.gameRenderer.getCamera();
        if (camera == null) return;

        event.matrices.push();
        Vec3d cameraPos = camera.getCameraPos();
        event.matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(camera.getPitch()));
        event.matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(camera.getYaw() + 180.0F));
        event.matrices.translate(-cameraPos.x, -cameraPos.y, -cameraPos.z);

        Vec3d pos = target.getLerpedPos(RenderUtils.tickProgress());
        double time = (System.currentTimeMillis() % 100000L) / 1000.0;

        final float px = (float) pos.x;
        final float py = (float) pos.y;
        final float pz = (float) pos.z;
        final float playerHeight = target.getHeight();
        final float playerWidth = target.getWidth();
        final double spinAngle = time * spin.getValue();
        final float a = alpha.getValueInt() / 255f;
        final float baseRadius = (playerWidth * 0.5f + 0.15f) * size.getValueFloat();

        Color c1 = new Color(color.getValue(), true);
        final float r1 = c1.getRed() / 255f;
        final float g1 = c1.getGreen() / 255f;
        final float b1 = c1.getBlue() / 255f;

        Color c2 = new Color(color2.getValue(), true);
        final float r2 = c2.getRed() / 255f;
        final float g2 = c2.getGreen() / 255f;
        final float b2 = c2.getBlue() / 255f;

        final Matrix4f matrix = event.matrices.peek().getPositionMatrix();

        // Halka 1: ayak altı
        drawRing(matrix, px, pz, baseRadius, py + 0.03f,
                12.0, spinAngle, 1.0, 0.055f, r1, g1, b1, a);

        // Halka 2: bel hizası, ters döner
        drawRing(matrix, px, pz, baseRadius * 0.75f, py + playerHeight * 0.5f,
                20.0, -spinAngle * 1.3, 0.5, 0.04f, r2, g2, b2, a * 0.9f);

        // Halka 3: boyun hizası, gradient
        drawRingGradient(matrix, px, pz, baseRadius * 0.55f, py + playerHeight * 0.85f,
                8.0, spinAngle * 1.8, 0.03f, r1, g1, b1, r2, g2, b2, a, time);

        event.matrices.pop();
    }

    private void drawRing(Matrix4f matrix,
                          float px, float pz, float radius, float centerY,
                          double tiltDeg, double spinAngle, double phaseSpeed, float half,
                          float r, float g, float b, float a) {
        float tilt = (float) Math.toRadians(tiltDeg);
        RenderUtils.drawLayer(RenderLayers.debugFilledBox(), buffer -> {
            for (int i = 0; i < RING_SEGMENTS; i++) {
                double t1 = spinAngle + i * (Math.PI * 2.0 / RING_SEGMENTS);
                double t2 = spinAngle + (i + 1) * (Math.PI * 2.0 / RING_SEGMENTS);
                float ro = radius + half, ri = radius - half;
                float ox1 = px + (float) Math.cos(t1) * ro, oz1 = pz + (float) Math.sin(t1) * ro;
                float ox2 = px + (float) Math.cos(t2) * ro, oz2 = pz + (float) Math.sin(t2) * ro;
                float ix1 = px + (float) Math.cos(t1) * ri, iz1 = pz + (float) Math.sin(t1) * ri;
                float ix2 = px + (float) Math.cos(t2) * ri, iz2 = pz + (float) Math.sin(t2) * ri;
                float y1 = centerY + (float) (Math.sin(t1 - spinAngle * phaseSpeed) * Math.sin(tilt) * radius);
                float y2 = centerY + (float) (Math.sin(t2 - spinAngle * phaseSpeed) * Math.sin(tilt) * radius);
                float glow = (float) (0.6 + 0.4 * Math.cos(t1 - spinAngle));
                buffer.vertex(matrix, ox1, y1, oz1).color(r * glow, g * glow, b * glow, a);
                buffer.vertex(matrix, ox2, y2, oz2).color(r * glow, g * glow, b * glow, a);
                buffer.vertex(matrix, ix2, y2, iz2).color(r * glow, g * glow, b * glow, a * 0.2f);
                buffer.vertex(matrix, ix1, y1, iz1).color(r * glow, g * glow, b * glow, a * 0.2f);
            }
        });
    }

    private void drawRingGradient(Matrix4f matrix,
                                   float px, float pz, float radius, float centerY,
                                   double tiltDeg, double spinAngle, float half,
                                   float r1, float g1, float b1,
                                   float r2, float g2, float b2,
                                   float a, double time) {
        float tilt = (float) Math.toRadians(tiltDeg);
        RenderUtils.drawLayer(RenderLayers.debugFilledBox(), buffer -> {
            for (int i = 0; i < RING_SEGMENTS; i++) {
                double t1 = spinAngle + i * (Math.PI * 2.0 / RING_SEGMENTS);
                double t2 = spinAngle + (i + 1) * (Math.PI * 2.0 / RING_SEGMENTS);
                float ro = radius + half, ri = radius - half;
                float ox1 = px + (float) Math.cos(t1) * ro, oz1 = pz + (float) Math.sin(t1) * ro;
                float ox2 = px + (float) Math.cos(t2) * ro, oz2 = pz + (float) Math.sin(t2) * ro;
                float ix1 = px + (float) Math.cos(t1) * ri, iz1 = pz + (float) Math.sin(t1) * ri;
                float ix2 = px + (float) Math.cos(t2) * ri, iz2 = pz + (float) Math.sin(t2) * ri;
                float y1 = centerY + (float) (Math.sin(t1) * Math.sin(tilt) * radius);
                float y2 = centerY + (float) (Math.sin(t2) * Math.sin(tilt) * radius);
                float mix = (float) (0.5 + 0.5 * Math.sin(t1 + time));
                float rr = r1 * mix + r2 * (1f - mix);
                float rg = g1 * mix + g2 * (1f - mix);
                float rb = b1 * mix + b2 * (1f - mix);
                float glow = (float) (0.7 + 0.3 * Math.cos(t1 - spinAngle));
                buffer.vertex(matrix, ox1, y1, oz1).color(rr * glow, rg * glow, rb * glow, a);
                buffer.vertex(matrix, ox2, y2, oz2).color(rr * glow, rg * glow, rb * glow, a);
                buffer.vertex(matrix, ix2, y2, iz2).color(rr * glow, rg * glow, rb * glow, a * 0.15f);
                buffer.vertex(matrix, ix1, y1, iz1).color(rr * glow, rg * glow, rb * glow, a * 0.15f);
            }
        });
    }
}
