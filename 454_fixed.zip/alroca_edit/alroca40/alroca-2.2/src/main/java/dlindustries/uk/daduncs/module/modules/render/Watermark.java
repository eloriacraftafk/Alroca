/*
 * This file is part of System Client (https://github.com/daduncs/system)
 * Website: https://download.daduncs.cloud/
 *
 * Copyright (c) 2024 - 2026 DLindustries and project contributors.
 *
 * System Client is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * System Client is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with System Client. If not, see <https://www.gnu.org/licenses/>.
 */

package dlindustries.uk.daduncs.module.modules.render;

import dlindustries.uk.daduncs.event.events.HudListener;
import dlindustries.uk.daduncs.event.events.PacketReceiveListener;
import dlindustries.uk.daduncs.gui.Frame;
import dlindustries.uk.daduncs.gui.HudEditor;
import dlindustries.uk.daduncs.gui.Theme;
import dlindustries.uk.daduncs.module.Category;
import dlindustries.uk.daduncs.module.Module;
import dlindustries.uk.daduncs.module.modules.client.ClickGUI;
import dlindustries.uk.daduncs.module.setting.bool;
import dlindustries.uk.daduncs.module.setting.number;
import dlindustries.uk.daduncs.render.Render2D;
import dlindustries.uk.daduncs.utils.EncryptedString;
import dlindustries.uk.daduncs.utils.TextRenderer;
import dlindustries.uk.daduncs.utils.Utils;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.network.packet.s2c.play.WorldTimeUpdateS2CPacket;
import net.minecraft.util.Identifier;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;

/**
 * Watermark: [logo 454 | nick | fps | ping | time] / [x y z | bps | tps]
 */
public final class Watermark extends Module implements HudListener, PacketReceiveListener {

	private static final String CLIENT_NAME = "454";
	private static final Identifier LOGO       = Identifier.of("454", "textures/gui/client_icon.png");
	private static final Identifier ICO_USER   = Identifier.of("454", "textures/gui/wm_user.png");
	private static final Identifier ICO_FPS    = Identifier.of("454", "textures/gui/wm_fps.png");
	private static final Identifier ICO_PING   = Identifier.of("454", "textures/gui/wm_ping.png");
	private static final Identifier ICO_CLOCK  = Identifier.of("454", "textures/gui/wm_clock.png");
	private static final Identifier ICO_COORDS = Identifier.of("454", "textures/gui/wm_coords.png");
	private static final Identifier ICO_BPS    = Identifier.of("454", "textures/gui/wm_bps.png");

	private static final DateTimeFormatter TIME_FMT = DateTimeFormatter.ofPattern("HH:mm:ss");

	private final number size = new number(EncryptedString.of("Size"), 50, 200, 100, 5);
	private final bool showPing = new bool(EncryptedString.of("Ping"), true);
	private final bool showTps = new bool(EncryptedString.of("TPS"), true);
	private final bool showCoords = new bool(EncryptedString.of("Coords"), true);
	private final bool showBps = new bool(EncryptedString.of("BPS"), true);
	private final bool showTime = new bool(EncryptedString.of("Time"), true);

	private long lastTimePacket = -1L;
	private float tps = 20f;
	private double bps;
	private double lastX, lastZ;
	private long lastBpsNano;

	public Watermark() {
		super(EncryptedString.of("Watermark"),
				EncryptedString.of("Shows the client name, nick, fps, ping, tps and coords"),
				-1,
				Category.RENDER);
		addSettings(size, showPing, showTps, showCoords, showBps, showTime);
		HudEditor.register(this);
	}

	@Override
	public void onEnable() {
		eventManager.add(HudListener.class, this);
		eventManager.add(PacketReceiveListener.class, this);
		lastTimePacket = -1L;
		super.onEnable();
	}

	@Override
	public void onDisable() {
		eventManager.remove(HudListener.class, this);
		eventManager.remove(PacketReceiveListener.class, this);
		super.onDisable();
	}

	// TPS: sunucu ~1 sn'de bir zaman paketi gonderir (20 tick).
	@Override
	public void onPacketReceive(PacketReceiveEvent event) {
		if (!(event.packet instanceof WorldTimeUpdateS2CPacket)) return;
		long now = System.nanoTime();
		if (lastTimePacket > 0) {
			float seconds = (now - lastTimePacket) / 1_000_000_000f;
			if (seconds > 0.05f) {
				float sample = Math.max(0f, Math.min(20f, 20f / seconds));
				tps = tps * 0.7f + sample * 0.3f;
			}
		}
		lastTimePacket = now;
	}

	private void updateBps() {
		if (mc.player == null) { bps = 0; return; }
		long now = System.nanoTime();
		if (lastBpsNano == 0) {
			lastBpsNano = now; lastX = mc.player.getX(); lastZ = mc.player.getZ();
			return;
		}
		if (now - lastBpsNano >= 250_000_000L) {
			double dx = mc.player.getX() - lastX;
			double dz = mc.player.getZ() - lastZ;
			double dt = (now - lastBpsNano) / 1_000_000_000.0;
			bps = Math.sqrt(dx * dx + dz * dz) / dt;
			lastX = mc.player.getX(); lastZ = mc.player.getZ(); lastBpsNano = now;
		}
	}

	@Override
	public void onRenderHud(HudEvent event) {
		if (mc.player == null) return;
		DrawContext context = event.context;
		int x = HudEditor.x(this, 8);
		int y = HudEditor.y(this, 8);

		updateBps();
		HudEditor.push(context, size.getValueFloat() / 100f, x, y);

		final int tall    = 20;
		final int pad     = 8;
		final int gap     = 4;
		final int div     = 5;   // divider boşluğu
		final int icoSize = 10;  // ikon boyutu
		final int icoGap  = 3;   // ikon-metin arası
		final int logoSz  = 12;

		// ── üst pill: segment genişlikleri ───────────────────────────────
		int nameW = TextRenderer.menuWidth(CLIENT_NAME);
		int logoPart = logoSz + 5 + nameW; // logo + gap + "454"

		String nick    = mc.getSession().getUsername();
		int nickW      = icoSize + icoGap + TextRenderer.menuWidth(nick);

		String fpsStr  = mc.getCurrentFps() + "fps";
		int fpsW       = icoSize + icoGap + TextRenderer.smallWidth(fpsStr);

		String pingStr = showPing.getValue() ? Utils.getPing(mc.player) + "ms" : null;
		int pingW      = pingStr != null ? icoSize + icoGap + TextRenderer.smallWidth(pingStr) : 0;

		String timeStr = showTime.getValue() ? LocalTime.now().format(TIME_FMT) : null;
		int timeW      = timeStr != null ? icoSize + icoGap + TextRenderer.smallWidth(timeStr) : 0;

		// toplam üst pill genişliği
		int w1 = pad + logoPart + (div + 1 + div) + nickW + (div + 1 + div) + fpsW;
		if (pingStr != null) w1 += (div + 1 + div) + pingW;
		if (timeStr != null) w1 += (div + 1 + div) + timeW;
		w1 += pad;

		pill(context, x, y, w1, tall);

		int cx = x + pad;
		int icoY = y + (tall - icoSize) / 2;
		int textY = y + tall / 2 - 2;
		int smallY = y + tall / 2 - 1;

		// logo + "454"
		Render2D.drawLogo(context, cx, y + (tall - logoSz) / 2f, logoSz, logoSz, LOGO, Theme.fade(Theme.accent, 1f));
		cx += logoSz + 5;
		TextRenderer.drawMenu(CLIENT_NAME, context, cx, textY, Theme.text);
		cx += nameW;

		// | 👤 nick
		cx += div;
		Render2D.drawRoundRect(context, cx, y + 6, 1, 8, 0.5f, Theme.fade(Theme.divider, 0.8f));
		cx += 1 + div;
		Render2D.drawRoundImage(context, cx, icoY, icoSize, icoSize, 0f, ICO_USER, Theme.fade(Theme.accent, 1f));
		cx += icoSize + icoGap;
		TextRenderer.drawMenu(nick, context, cx, textY, Theme.text);
		cx += TextRenderer.menuWidth(nick);

		// | ⚡ fps
		cx += div;
		Render2D.drawRoundRect(context, cx, y + 6, 1, 8, 0.5f, Theme.fade(Theme.divider, 0.8f));
		cx += 1 + div;
		Render2D.drawRoundImage(context, cx, icoY, icoSize, icoSize, 0f, ICO_FPS, Theme.fade(Theme.accent, 1f));
		cx += icoSize + icoGap;
		TextRenderer.drawSmall(fpsStr, context, cx, smallY, Theme.muted);
		cx += TextRenderer.smallWidth(fpsStr);

		// | 📡 ping
		if (pingStr != null) {
			cx += div;
			Render2D.drawRoundRect(context, cx, y + 6, 1, 8, 0.5f, Theme.fade(Theme.divider, 0.8f));
			cx += 1 + div;
			Render2D.drawRoundImage(context, cx, icoY, icoSize, icoSize, 0f, ICO_PING, Theme.fade(Theme.accent, 1f));
			cx += icoSize + icoGap;
			TextRenderer.drawSmall(pingStr, context, cx, smallY, Theme.muted);
			cx += TextRenderer.smallWidth(pingStr);
		}

		// | 🕐 saat
		if (timeStr != null) {
			cx += div;
			Render2D.drawRoundRect(context, cx, y + 6, 1, 8, 0.5f, Theme.fade(Theme.divider, 0.8f));
			cx += 1 + div;
			Render2D.drawRoundImage(context, cx, icoY, icoSize, icoSize, 0f, ICO_CLOCK, Theme.fade(Theme.accent, 1f));
			cx += icoSize + icoGap;
			TextRenderer.drawSmall(timeStr, context, cx, smallY, Theme.muted);
		}

		int totalW = w1;
		int totalH = tall;

		// ── alt pill: 📍 coords | 💨 bps | ⚡ tps ───────────────────────
		boolean hasBottom = showCoords.getValue() || showBps.getValue() || showTps.getValue();
		if (hasBottom) {
			int y2  = y + tall + gap;
			int cx2 = x + pad;

			// genişlik hesapla
			int w2 = pad;
			if (showCoords.getValue()) {
				String coordStr = "x" + (int) Math.floor(mc.player.getX())
						+ " y" + (int) Math.floor(mc.player.getY())
						+ " z" + (int) Math.floor(mc.player.getZ());
				w2 += icoSize + icoGap + TextRenderer.smallWidth(coordStr);
				if (showBps.getValue() || showTps.getValue()) w2 += div + 1 + div;
			}
			if (showBps.getValue()) {
				String bpsStr2 = String.format(java.util.Locale.ROOT, "%.1fbps", bps);
				w2 += icoSize + icoGap + TextRenderer.smallWidth(bpsStr2);
				if (showTps.getValue()) w2 += div + 1 + div;
			}
			if (showTps.getValue()) {
				String tpsStr2 = String.format(java.util.Locale.ROOT, "%.1ftps", tps);
				w2 += icoSize + icoGap + TextRenderer.smallWidth(tpsStr2);
			}
			w2 += pad;

			pill(context, x, y2, w2, tall);
			int icoY2   = y2 + (tall - icoSize) / 2;
			int smallY2 = y2 + tall / 2 - 1;

			if (showCoords.getValue()) {
				String coordStr = "x" + (int) Math.floor(mc.player.getX())
						+ " y" + (int) Math.floor(mc.player.getY())
						+ " z" + (int) Math.floor(mc.player.getZ());
				Render2D.drawRoundImage(context, cx2, icoY2, icoSize, icoSize, 0f, ICO_COORDS, Theme.fade(Theme.accent, 1f));
				cx2 += icoSize + icoGap;
				TextRenderer.drawSmall(coordStr, context, cx2, smallY2, Theme.text);
				cx2 += TextRenderer.smallWidth(coordStr);
				if (showBps.getValue() || showTps.getValue()) {
					cx2 += div;
					Render2D.drawRoundRect(context, cx2, y2 + 6, 1, 8, 0.5f, Theme.fade(Theme.divider, 0.8f));
					cx2 += 1 + div;
				}
			}
			if (showBps.getValue()) {
				String bpsStr2 = String.format(java.util.Locale.ROOT, "%.1fbps", bps);
				Render2D.drawRoundImage(context, cx2, icoY2, icoSize, icoSize, 0f, ICO_BPS, Theme.fade(Theme.accent, 1f));
				cx2 += icoSize + icoGap;
				TextRenderer.drawSmall(bpsStr2, context, cx2, smallY2, Theme.text);
				cx2 += TextRenderer.smallWidth(bpsStr2);
				if (showTps.getValue()) {
					cx2 += div;
					Render2D.drawRoundRect(context, cx2, y2 + 6, 1, 8, 0.5f, Theme.fade(Theme.divider, 0.8f));
					cx2 += 1 + div;
				}
			}
			if (showTps.getValue()) {
				String tpsStr2 = String.format(java.util.Locale.ROOT, "%.1ftps", tps);
				Render2D.drawRoundImage(context, cx2, icoY2, icoSize, icoSize, 0f, ICO_FPS, Theme.fade(Theme.accent, 1f));
				cx2 += icoSize + icoGap;
				TextRenderer.drawSmall(tpsStr2, context, cx2, smallY2, Theme.text);
			}

			totalH = tall * 2 + gap;
			totalW = Math.max(totalW, w2);
		}

		HudEditor.bounds(this, x, y, totalW, totalH);
		HudEditor.pop(context);
	}

	private void pill(DrawContext context, int x, int y, int width, int tall) {
		if (ClickGUI.hudGlass.getValue()) {
			Render2D.drawBubble(context, x, y, width, tall, tall / 2f, Theme.SHEEN, 7f, 0.35f, 0x66101010, 1f);
		} else {
			Render2D.drawGlassRoundRect(context, x, y, width, tall, tall / 2f, Theme.SHEEN, Theme.BLUR, Theme.surface, 1f);
		}
	}
}
