package dev.marlow.crystal.module.setting;

import java.util.Random;

/**
 * Cryptographically seeded, distribution-shaped RNG.
 * Gaussian is Box-Muller clamped to ±2.5σ so outliers don't spike flags.
 * Uniform uses XorShift64 for flat distribution without java.util.Random bias.
 */
public final class Randomizer {
    public static final Randomizer INSTANCE = new Randomizer();

    // Two independent generators — prevents correlation between rotation and timing
    private final Random gaussianRng;
    private long xorState;

    private Randomizer() {
        long seed = System.nanoTime() ^ Thread.currentThread().getId() * 0x9e3779b97f4a7c15L;
        gaussianRng = new Random(seed);
        xorState = seed ^ 0xdeadbeefcafeL;
        if (xorState == 0) xorState = 1;
    }

    // XorShift64 — flat uniform, no java.util.Random periodicity
    private long nextLong() {
        xorState ^= xorState << 13;
        xorState ^= xorState >>> 7;
        xorState ^= xorState << 17;
        return xorState;
    }

    /**
     * Gaussian clamped to [-2.5, 2.5] — no extreme outliers that spike
     * pattern detectors (Polar/Intave flag sudden huge deltas).
     */
    public double gaussian() {
        double g = gaussianRng.nextGaussian();
        return Math.max(-2.5, Math.min(2.5, g));
    }

    /**
     * Gaussian-distributed long in [min, max].
     * Maps [-2.5, 2.5] → [0, 1] so the full range is reachable
     * but center-heavy — matches human reaction time distributions.
     */
    public long gaussianLong(long min, long max) {
        double range = max - min;
        double g = (gaussian() + 2.5) / 5.0;   // → [0, 1]
        return min + (long) (g * range);
    }

    /**
     * Truly flat uniform — XorShift, no java.util.Random bucket bias.
     */
    public double uniform(double min, double max) {
        // map nextLong to [0,1) via unsigned shift
        double t = (double) (nextLong() >>> 11) / (double) (1L << 53);
        return min + t * (max - min);
    }

    /**
     * Gaussian jitter for rotation — mean 0, σ = scale.
     * Used to humanize aim deltas; never exceeds ±3σ.
     */
    public float jitterF(float scale) {
        double g = gaussianRng.nextGaussian();
        g = Math.max(-3.0, Math.min(3.0, g));
        return (float) (g * scale);
    }

    /**
     * Bernoulli trial — returns true with probability (percent/100).
     * Used for pass-chance and miss-chance decisions.
     */
    public boolean roll(double percent) {
        return uniform(0, 100) < percent;
    }

    /**
     * Generates a click-pattern-consistent inter-attack interval using
     * a lognormal approximation (human CPS data is lognormal, not Gaussian).
     * min/max in ms.
     */
    public long humanClickInterval(long minMs, long maxMs) {
        // lognormal: ln(X) ~ N(μ, σ²)
        double range = maxMs - minMs;
        double mu = Math.log(range / 2.0 + 1);
        double sigma = 0.28; // ~human spread from click studies
        double ln = gaussianRng.nextGaussian() * sigma + mu;
        double val = Math.exp(ln);
        return minMs + (long) Math.min(val, range);
    }
}
