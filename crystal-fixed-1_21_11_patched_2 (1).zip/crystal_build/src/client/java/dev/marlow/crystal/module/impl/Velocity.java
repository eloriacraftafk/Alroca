package dev.marlow.crystal.module.impl;

import dev.marlow.crystal.module.Module;
import dev.marlow.crystal.module.setting.BoolSetting;
import dev.marlow.crystal.module.setting.FloatSetting;
import dev.marlow.crystal.module.setting.IntSetting;
import dev.marlow.crystal.module.setting.Randomizer;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;

/**
 * Velocity — multi-AC bypass layer.
 *
 * Grim KnockbackHandler (grim source: KnockbackHandler.java):
 *   - Predicts exact KB from attack direction + attacker speed
 *   - Compares actual player motion vs predicted at next tick
 *   - Perfect 0.0x/0.0z → flag ("VelocityH") unless player is on ground + stationary
 *   - Perfect 1.0 vertical reduction → flag ("VelocityV")
 *   - Requires residual: horizontal floor ~0.14, vertical floor ~0.10
 *
 * Polar / Intave:
 *   - Track consistency: same reduction % every hit → flag (too mechanical)
 *   - Per-hit variance required: ±12–18% variance on multiplier
 *   - Occasional full pass: ~20% of hits must be unmodified (legitimate KB)
 *
 * Badlion AC / Themis:
 *   - Checks velocity relative to expected server-side KB
 *   - passChance of 20% matches observed passing threshold
 *
 * Spartan:
 *   - Monitors Δvelocity; zero or near-zero reduction flags
 *   - Minimum residual enforced below
 */
public class Velocity extends Module {
    private final FloatSetting horizontal = new FloatSetting("Horizontal", 38f,  10f, 100f);
    private final FloatSetting vertical   = new FloatSetting("Vertical",   42f,  10f, 100f);
    private final BoolSetting  soft       = new BoolSetting ("Soft",       true);
    private final IntSetting   passChance = new IntSetting  ("Pass %",     20,   8,   40);

    // Grim residual minimums (from prediction analysis)
    private static final double HORIZONTAL_FLOOR = 0.14;
    private static final double VERTICAL_FLOOR   = 0.10;

    public Velocity() { super("Velocity", "Multi-AC knockback reduce"); }

    public FloatSetting getHorizontal() { return horizontal; }
    public FloatSetting getVertical()   { return vertical; }
    public BoolSetting  getSoft()       { return soft; }
    public IntSetting   getPassChance() { return passChance; }

    public Vec3 scale(Vec3 motion) {
        if (!isEnabled()) return motion;

        // Full KB pass (Polar/Intave/Themis consistency break)
        if (Randomizer.INSTANCE.roll(passChance.getValue())) return motion;

        double hMult = horizontal.getValue() / 100.0;
        double vMult = vertical.getValue()   / 100.0;

        if (soft.getValue()) {
            // Per-hit variance ±15% (Polar mechanical detection)
            hMult *= Randomizer.INSTANCE.uniform(0.85, 1.15);
            vMult *= Randomizer.INSTANCE.uniform(0.85, 1.15);

            // Grim floor: never go below minimum residual
            hMult = Math.max(hMult, HORIZONTAL_FLOOR + Randomizer.INSTANCE.uniform(0, 0.06));
            vMult = Math.max(vMult, VERTICAL_FLOOR   + Randomizer.INSTANCE.uniform(0, 0.05));
        }

        return new Vec3(motion.x * hMult, motion.y * vMult, motion.z * hMult);
    }

    @Override
    public void onTick(Player player) {
        if (!isEnabled()) return;
        Vec3 v = player.getDeltaMovement();
        // Only intercept genuine knockback spikes (not normal motion noise)
        if (Math.abs(v.x) > 0.40 || Math.abs(v.z) > 0.40) {
            player.setDeltaMovement(scale(v));
        }
    }
}
