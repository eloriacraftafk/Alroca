package dev.marlow.crystal.gui;

import dev.marlow.crystal.bypass.ConfigManager;
import dev.marlow.crystal.module.Module;
import dev.marlow.crystal.module.ModuleManager;
import dev.marlow.crystal.module.impl.NameHider;
import dev.marlow.crystal.module.setting.BoolSetting;
import dev.marlow.crystal.module.setting.FloatSetting;
import dev.marlow.crystal.module.setting.IntSetting;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.util.Mth;
import org.lwjgl.glfw.GLFW;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class CrystalScreen extends Screen {

    private static final int BTN_W      = 120;
    private static final int BTN_H      = 24;
    private static final int GAP        = 5;
    private static final int COL_GAP    = 12;
    private static final int PAD        = 10;
    private static final int SETTINGS_W = 178;

    private static final int CFG_H      = 44;
    private static final int CFG_BTN_W  = 50;
    private static final int CFG_BTN_H  = 16;

    private Module  selected;
    private Module  waitingBindModule;
    private boolean waitingForBind;
    private Object  draggingSetting;

    private float openAnim;
    private float settingsAnim;
    private final Map<String, Float> hoverAnim  = new HashMap<>();
    private final Map<String, Float> enableAnim = new HashMap<>();
    private long lastFrameNs = System.nanoTime();

    private String  profileInput      = ConfigManager.INSTANCE.getCurrentProfile();
    private boolean profileFocused    = false;
    private float   saveFeedbackTimer = 0f;
    private float   loadFeedbackTimer = 0f;
    private boolean hoverSave, hoverLoad, hoverProfileField;

    public CrystalScreen() {
        super(Component.literal("Crystal"));
        openAnim = settingsAnim = 0f;
    }

    private List<Module> mods() { return ModuleManager.INSTANCE.getModules(); }

    private float dt() {
        long now = System.nanoTime();
        float d = (now - lastFrameNs) / 1_000_000_000f;
        lastFrameNs = now;
        return Mth.clamp(d, 0.001f, 0.05f);
    }

    private float approach(float cur, float target, float speed, float dt) {
        return cur + (target - cur) * Math.min(1f, speed * dt);
    }

    private int settingsPanelHeight(Module mod) {
        if (mod == null) return 0;
        var settings = mod.getSettings();
        int extra = (mod instanceof NameHider) ? 28 : 0;
        int sh = 42 + settings.size() * 36 + 16 + extra;
        return Math.max(sh, 96);
    }

    private int[] origin(boolean withSettings) {
        List<Module> list = mods();
        int count  = list.size();
        int half   = (count + 1) / 2;
        int totalW = BTN_W * 2 + COL_GAP + PAD * 2;
        int totalH = BTN_H * half + GAP * Math.max(0, half - 1) + PAD * 2;
        int ox = (width - totalW) / 2;
        if (withSettings) ox = (width - totalW - SETTINGS_W - 14) / 2;
        int oy = Math.max(24, (height - totalH) / 2);
        return new int[]{ox, oy, totalW, totalH, half};
    }

    // 1.21.11 — render coords int
    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float delta) {
        float d = dt();
        openAnim    = approach(openAnim,    1f,                     8f,  d);
        settingsAnim= approach(settingsAnim,selected != null ? 1f : 0f, 10f, d);
        if (saveFeedbackTimer > 0) saveFeedbackTimer -= d;
        if (loadFeedbackTimer > 0) loadFeedbackTimer -= d;

        int[] o = origin(settingsAnim > 0.3f);
        int originX = o[0], originY = o[1];
        int totalW  = o[2], half    = o[4];
        int totalH  = o[3];

        originY += (int)((1f - openAnim) * 12);

        int alpha    = (int)(openAnim * 0xC0);
        int panelBg  = (alpha << 24) | 0x141418;
        int accent   = ((int)(openAnim * 255) << 24) | 0x982689;

        fillRound(g, originX,                originY, BTN_W + PAD * 2, totalH, panelBg);
        fillRound(g, originX + BTN_W + COL_GAP, originY, BTN_W + PAD * 2, totalH, panelBg);
        g.fill(originX + 4, originY, originX + BTN_W + PAD * 2 - 4, originY + 1, accent);
        g.fill(originX + BTN_W + COL_GAP + 4, originY, originX + totalW - 4, originY + 1, accent);

        List<Module> list = mods();
        int count = list.size();
        int mx = mouseX, my = mouseY;
        for (int i = 0; i < count; i++) {
            boolean left = i < half;
            int row = left ? i : i - half;
            int x = left ? originX + PAD : originX + BTN_W + COL_GAP + PAD;
            int y = originY + PAD + row * (BTN_H + GAP);
            drawButton(g, list.get(i), x, y, mx, my, d);
        }

        if (settingsAnim > 0.02f && selected != null) {
            int sx = originX + totalW + 10;
            sx += (int)((1f - settingsAnim) * 30);
            int sh = settingsPanelHeight(selected);
            drawSettings(g, selected, sx, originY, mx, my, settingsAnim);
            if (settingsAnim > 0.5f) {
                drawConfigBar(g, sx, originY + sh + 6, mx, my, settingsAnim);
            }
        }

        if (waitingForBind && waitingBindModule != null) drawBindOverlay(g);

        int tipA = (int)(openAnim * 0x88);
        g.drawString(font, ".name <nick>", 6, height - 14, (tipA << 24) | 0xAAAAAA, false);

        super.render(g, mouseX, mouseY, delta);
    }

    private void drawConfigBar(GuiGraphics g, int sx, int cy, int mouseX, int mouseY, float anim) {
        int a = (int)(anim * 0xE0);
        fillRound(g, sx, cy, SETTINGS_W, CFG_H, (a << 24) | 0x0E0E12);
        int ba = (int)(anim * 255);
        drawRectOutline(g, sx, cy, SETTINGS_W, CFG_H, (ba << 24) | 0x44344A);

        g.drawString(font, "Config", sx + 8, cy + 5, (ba << 24) | 0x888899);

        int fx = sx + 8, fy = cy + 15, fw = SETTINGS_W - 20, fh = 11;
        hoverProfileField = mouseX >= fx && mouseX <= fx + fw && mouseY >= fy && mouseY <= fy + fh;
        int fieldBg  = profileFocused ? 0xFF1A1A22 : 0xFF131318;
        int fieldBdr = profileFocused ? 0xFF982689 : (hoverProfileField ? 0xFF555566 : 0xFF2A2A32);
        g.fill(fx, fy, fx + fw, fy + fh, (a << 24) | (fieldBg & 0x00FFFFFF));
        g.fill(fx, fy + fh, fx + fw, fy + fh + 1, fieldBdr);
        String display = profileInput.isEmpty() ? "default" : profileInput;
        int textCol = profileInput.isEmpty() ? 0x44666677 : 0xFFCCCCDD;
        if (profileFocused) {
            long ms = System.currentTimeMillis();
            String cur = (ms / 500) % 2 == 0 ? display + "|" : display;
            g.drawString(font, cur, fx + 2, fy + 2, (ba << 24) | (textCol & 0x00FFFFFF));
        } else {
            g.drawString(font, display, fx + 2, fy + 2, (ba << 24) | (textCol & 0x00FFFFFF));
        }

        int bx = sx + 8;
        int by = cy + CFG_H - CFG_BTN_H - 5;
        hoverSave = mouseX >= bx && mouseX <= bx + CFG_BTN_W && mouseY >= by && mouseY <= by + CFG_BTN_H;
        boolean saveFlash = saveFeedbackTimer > 0;
        int saveBg  = saveFlash ? 0xFF1A4A1A : (hoverSave ? 0xFF2A2A3A : 0xFF1A1A28);
        int saveBdr = saveFlash ? 0xFF55FF55 : (hoverSave ? 0xFF982689 : 0xFF44344A);
        fillRound(g, bx, by, CFG_BTN_W, CFG_BTN_H, (a << 24) | (saveBg & 0x00FFFFFF));
        drawRectOutline(g, bx, by, CFG_BTN_W, CFG_BTN_H, (ba << 24) | (saveBdr & 0x00FFFFFF));
        String saveLabel = saveFlash ? "saved!" : "Save";
        int saveLabelCol = saveFlash ? 0xFF55FF55 : 0xFFCCCCDD;
        g.drawString(font, saveLabel, bx + (CFG_BTN_W - font.width(saveLabel)) / 2, by + 4, (ba << 24) | (saveLabelCol & 0x00FFFFFF));

        int lx = bx + CFG_BTN_W + 6;
        hoverLoad = mouseX >= lx && mouseX <= lx + CFG_BTN_W && mouseY >= by && mouseY <= by + CFG_BTN_H;
        boolean loadFlash = loadFeedbackTimer > 0;
        int loadBg  = loadFlash ? 0xFF1A2A4A : (hoverLoad ? 0xFF2A2A3A : 0xFF1A1A28);
        int loadBdr = loadFlash ? 0xFF5599FF : (hoverLoad ? 0xFF982689 : 0xFF44344A);
        fillRound(g, lx, by, CFG_BTN_W, CFG_BTN_H, (a << 24) | (loadBg & 0x00FFFFFF));
        drawRectOutline(g, lx, by, CFG_BTN_W, CFG_BTN_H, (ba << 24) | (loadBdr & 0x00FFFFFF));
        String loadLabel = loadFlash ? "loaded!" : "Load";
        int loadLabelCol = loadFlash ? 0xFF5599FF : 0xFFCCCCDD;
        g.drawString(font, loadLabel, lx + (CFG_BTN_W - font.width(loadLabel)) / 2, by + 4, (ba << 24) | (loadLabelCol & 0x00FFFFFF));
    }

    private boolean clickConfigBar(int sx, int cy, double mouseX, double mouseY) {
        int sh = settingsPanelHeight(selected);
        cy = cy + sh + 6;

        int fx = sx + 8, fy = cy + 15, fw = SETTINGS_W - 20, fh = 11;
        if (mouseX >= fx && mouseX <= fx + fw && mouseY >= fy && mouseY <= fy + fh) {
            profileFocused = true;
            return true;
        }
        profileFocused = false;

        int bx = sx + 8;
        int by = cy + CFG_H - CFG_BTN_H - 5;

        if (mouseX >= bx && mouseX <= bx + CFG_BTN_W && mouseY >= by && mouseY <= by + CFG_BTN_H) {
            String prof = profileInput.isBlank() ? "default" : profileInput.trim();
            ConfigManager.INSTANCE.setCurrentProfile(prof);
            ConfigManager.INSTANCE.save();
            saveFeedbackTimer = 1.4f;
            return true;
        }
        int lx = bx + CFG_BTN_W + 6;
        if (mouseX >= lx && mouseX <= lx + CFG_BTN_W && mouseY >= by && mouseY <= by + CFG_BTN_H) {
            String prof = profileInput.isBlank() ? "default" : profileInput.trim();
            ConfigManager.INSTANCE.setCurrentProfile(prof);
            ConfigManager.INSTANCE.load();
            loadFeedbackTimer = 1.4f;
            return true;
        }
        return false;
    }

    private void drawButton(GuiGraphics g, Module mod, int x, int y, int mouseX, int mouseY, float d) {
        String key     = mod.getName();
        boolean hover  = mouseX >= x && mouseX <= x + BTN_W && mouseY >= y && mouseY <= y + BTN_H;
        boolean enabled= mod.isEnabled();
        boolean isSel  = mod == selected;

        float h = hoverAnim.getOrDefault(key, 0f);
        h = approach(h, hover ? 1f : 0f, 14f, d);
        hoverAnim.put(key, h);

        float e = enableAnim.getOrDefault(key, enabled ? 1f : 0f);
        e = approach(e, enabled ? 1f : 0f, 10f, d);
        enableAnim.put(key, e);

        int r  = (int)(0x1A + e * 0x12 + h * 0x10);
        int gr = (int)(0x1A + e * 0x28 + h * 0x08);
        int b  = (int)(0x1E + (isSel ? 0x28 : 0) + h * 0x0C);
        int bg = (0xE0 << 24) | (r << 16) | (gr << 8) | b;

        fillRound(g, x, y, BTN_W, BTN_H, bg);

        int border = enabled ? 0xFF000000 | ((int)(0x3A + e * 0x30) << 8) | 0x3A : 0xFF2A2A32;
        if (isSel) border = 0xFF982689;
        drawRectOutline(g, x, y, BTN_W, BTN_H, border);

        if (h > 0.05f) {
            int ga = (int)(h * 90);
            g.fill(x, y + 2, x + 2, y + BTN_H - 2, (ga << 24) | 0xFFFFFF);
        }

        int textColor = enabled ? 0xFF55FF55 : 0xFFB0B0B8;
        if (h > 0.3f && !enabled) textColor = 0xFFDDDDDD;
        g.drawString(font, mod.getName(), x + 8, y + 8, textColor);

        int barX   = x + BTN_W - 6;
        int barCol = enabled ? 0xFFFFFFFF : 0xFF555566;
        int barH2  = (int)(4 + e * (BTN_H - 12));
        int barY   = y + (BTN_H - barH2) / 2;
        g.fill(barX, barY, barX + 2, barY + barH2, barCol);
    }

    private void drawSettings(GuiGraphics g, Module mod, int sx, int sy, int mouseX, int mouseY, float anim) {
        var settings = mod.getSettings();
        int extra = (mod instanceof NameHider) ? 28 : 0;
        int sh = 42 + settings.size() * 36 + 16 + extra;
        if (sh < 96) sh = 96;

        int a = (int)(anim * 0xE8);
        fillRound(g, sx, sy, SETTINGS_W, sh, (a << 24) | 0x101014);
        int ba = (int)(anim * 255);
        drawRectOutline(g, sx, sy, SETTINGS_W, sh, (ba << 24) | 0x982689);

        g.fill(sx + 1, sy + 1, sx + SETTINGS_W - 1, sy + 26, (a << 24) | 0x1A1020);
        g.drawString(font, mod.getName(), sx + 10, sy + 6,  0xFFFFFFFF);
        g.drawString(font, "settings",   sx + 10, sy + 15, 0xFF888899);

        int ey = sy + 34;
        if (mod instanceof NameHider) {
            g.drawString(font, "Name: " + NameHider.getCustomName(), sx + 10, ey,      0xFF55E0FF);
            g.drawString(font, ".name <nick> in chat",               sx + 10, ey + 11, 0xFF555566);
            ey += 28;
        }

        for (Object setting : settings) {
            if (setting instanceof BoolSetting bs) {
                g.drawString(font, bs.getName(), sx + 10, ey, 0xFFCCCCDD);
                String state = bs.getValue() ? "ON" : "OFF";
                int sc = bs.getValue() ? 0xFF55FF55 : 0xFFFF5555;
                g.drawString(font, state, sx + SETTINGS_W - 12 - font.width(state), ey, sc);
                int bx = sx + SETTINGS_W - 36, bw = 22, bh = 11;
                fillRound(g, bx, ey - 1, bw, bh, bs.getValue() ? 0xFF2A5A2A : 0xFF3A2A2A);
                int kx = bs.getValue() ? bx + bw - 9 : bx + 2;
                fillRound(g, kx, ey, 7, 9, 0xFFEEEEEE);
                ey += 28;
            } else if (setting instanceof IntSetting is) {
                g.drawString(font, is.getName(), sx + 10, ey, 0xFFCCCCDD);
                String val = String.valueOf(is.getValue());
                g.drawString(font, val, sx + SETTINGS_W - 10 - font.width(val), ey, 0xFFFFFFFF);
                int barX = sx + 10, barY = ey + 13, barW = SETTINGS_W - 20;
                g.fill(barX, barY, barX + barW, barY + 3, 0xFF2A2A32);
                float pct = is.getMax() == is.getMin() ? 0f : (float)(is.getValue() - is.getMin()) / (is.getMax() - is.getMin());
                int fill = (int)(pct * barW);
                g.fill(barX, barY, barX + fill, barY + 3, 0xFF982689);
                g.fill(barX + fill - 1, barY - 2, barX + fill + 2, barY + 5, 0xFFCCAAFF);
                ey += 36;
            } else if (setting instanceof FloatSetting fs) {
                g.drawString(font, fs.getName(), sx + 10, ey, 0xFFCCCCDD);
                String val = String.format("%.2f", fs.getValue());
                g.drawString(font, val, sx + SETTINGS_W - 10 - font.width(val), ey, 0xFFFFFFFF);
                int barX = sx + 10, barY = ey + 13, barW = SETTINGS_W - 20;
                g.fill(barX, barY, barX + barW, barY + 3, 0xFF2A2A32);
                float pct = fs.getMax() == fs.getMin() ? 0f : (fs.getValue() - fs.getMin()) / (fs.getMax() - fs.getMin());
                int fill = (int)(pct * barW);
                g.fill(barX, barY, barX + fill, barY + 3, 0xFF982689);
                g.fill(barX + fill - 1, barY - 2, barX + fill + 2, barY + 5, 0xFFCCAAFF);
                ey += 36;
            }
        }
    }

    private void drawBindOverlay(GuiGraphics g) {
        int w = 190, h = 52;
        int bx = (width - w) / 2, by = (height - h) / 2;
        fillRound(g, bx, by, w, h, 0xF0121218);
        drawRectOutline(g, bx, by, w, h, 0xFF982689);
        g.drawString(font, "Bind: " + waitingBindModule.getName(), bx + 12, by + 12, 0xFFFFFF);
        g.drawString(font, "key  ·  DEL clear  ·  ESC cancel",    bx + 12, by + 30, 0xFF888899);
    }

    // 1.21.5+ — mouse coords float
    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        List<Module> list = mods();
        int count = list.size();
        int half  = (count + 1) / 2;
        int[] o   = origin(selected != null);
        int originX = o[0], originY = o[1], totalW = o[2];

        for (int i = 0; i < count; i++) {
            boolean left = i < half;
            int row = left ? i : i - half;
            int x = left ? originX + PAD : originX + BTN_W + COL_GAP + PAD;
            int y = originY + PAD + row * (BTN_H + GAP);
            if (mouseX >= x && mouseX <= x + BTN_W && mouseY >= y && mouseY <= y + BTN_H) {
                Module mod = list.get(i);
                if (button == 0) mod.toggle();
                else if (button == 1) selected = (selected == mod) ? null : mod;
                else if (button == 2) { waitingBindModule = mod; waitingForBind = true; }
                return true;
            }
        }

        if (selected != null && button == 0) {
            int sx = originX + totalW + 10;
            if (clickSettings(selected, sx, originY, mouseX, mouseY)) return true;
            if (clickConfigBar(sx, originY, mouseX, mouseY)) return true;
            profileFocused = false;
        }
        if (button == 0) profileFocused = false;
        return super.mouseClicked(mouseX, mouseY, button);
    }

    private boolean clickSettings(Module mod, int sx, int sy, double mouseX, double mouseY) {
        var settings = mod.getSettings();
        int ey = sy + 34;
        if (mod instanceof NameHider) ey += 28;
        for (Object setting : settings) {
            if (setting instanceof BoolSetting bs) {
                int bx = sx + SETTINGS_W - 36;
                if (mouseX >= bx && mouseX <= bx + 22 && mouseY >= ey - 1 && mouseY <= ey + 10) {
                    bs.toggle(); return true;
                }
                ey += 28;
            } else if (setting instanceof IntSetting is) {
                int barX = sx + 10, barY = ey + 13, barW = SETTINGS_W - 20;
                if (mouseX >= barX && mouseX <= barX + barW && mouseY >= barY - 4 && mouseY <= barY + 8) {
                    float pct = (float)Math.max(0, Math.min(1, (mouseX - barX) / barW));
                    is.setValue(is.getMin() + Math.round(pct * (is.getMax() - is.getMin())));
                    draggingSetting = is; return true;
                }
                ey += 36;
            } else if (setting instanceof FloatSetting fs) {
                int barX = sx + 10, barY = ey + 13, barW = SETTINGS_W - 20;
                if (mouseX >= barX && mouseX <= barX + barW && mouseY >= barY - 4 && mouseY <= barY + 8) {
                    float pct = (float)Math.max(0, Math.min(1, (mouseX - barX) / barW));
                    fs.setValue(fs.getMin() + pct * (fs.getMax() - fs.getMin()));
                    draggingSetting = fs; return true;
                }
                ey += 36;
            }
        }
        return false;
    }

    @Override
    public boolean mouseDragged(double mouseX, double mouseY, int button, double dx, double dy) {
        if (draggingSetting != null && selected != null && button == 0) {
            int[] o = origin(true);
            int sx  = o[0] + o[2] + 10;
            int oy  = o[1];
            clickSettings(selected, sx, oy, mouseX, mouseY);
            return true;
        }
        return super.mouseDragged(mouseX, mouseY, button, dx, dy);
    }

    @Override
    public boolean mouseReleased(double mouseX, double mouseY, int button) {
        draggingSetting = null;
        return super.mouseReleased(mouseX, mouseY, button);
    }

    // 1.21.11 — keyPressed modifiers promoted to long
    @Override
    public boolean keyPressed(int keyCode, int scanCode, long modifiers) {
        if (waitingForBind && waitingBindModule != null) {
            if (keyCode == GLFW.GLFW_KEY_ESCAPE) { waitingForBind = false; waitingBindModule = null; return true; }
            if (keyCode == GLFW.GLFW_KEY_DELETE || keyCode == GLFW.GLFW_KEY_BACKSPACE) {
                waitingBindModule.setKey(-1); waitingForBind = false; waitingBindModule = null; return true;
            }
            waitingBindModule.setKey(keyCode); waitingForBind = false; waitingBindModule = null; return true;
        }

        if (profileFocused) {
            if (keyCode == GLFW.GLFW_KEY_ESCAPE || keyCode == GLFW.GLFW_KEY_ENTER) {
                profileFocused = false; return true;
            }
            if (keyCode == GLFW.GLFW_KEY_BACKSPACE && !profileInput.isEmpty()) {
                profileInput = profileInput.substring(0, profileInput.length() - 1); return true;
            }
            return true;
        }

        if (keyCode == GLFW.GLFW_KEY_ESCAPE) {
            if (selected != null) { selected = null; return true; }
            onClose(); return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    // 1.21.11 — charTyped modifiers promoted to long
    @Override
    public boolean charTyped(char c, long modifiers) {
        if (profileFocused) {
            if (c >= 32 && c < 127 && profileInput.length() < 24) {
                profileInput += c; return true;
            }
            return true;
        }
        return super.charTyped(c, modifiers);
    }

    @Override
    public boolean isPauseScreen() { return false; }

    private void fillRound(GuiGraphics g, int x, int y, int w, int h, int color) {
        g.fill(x + 1, y,     x + w - 1, y + h,     color);
        g.fill(x,     y + 1, x + w,     y + h - 1, color);
    }

    private void drawRectOutline(GuiGraphics g, int x, int y, int w, int h, int color) {
        g.fill(x,         y,         x + w,     y + 1,     color);
        g.fill(x,         y + h - 1, x + w,     y + h,     color);
        g.fill(x,         y,         x + 1,     y + h,     color);
        g.fill(x + w - 1, y,         x + w,     y + h,     color);
    }
}
