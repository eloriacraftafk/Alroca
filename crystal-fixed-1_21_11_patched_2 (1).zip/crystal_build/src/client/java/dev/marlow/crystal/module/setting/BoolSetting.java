package dev.marlow.crystal.module.setting;

public class BoolSetting {
    private final String name;
    private boolean value;

    public BoolSetting(String name, boolean defaultValue) {
        this.name = name;
        this.value = defaultValue;
    }

    public String getName() { return name; }
    public boolean getValue() { return value; }
    public void setValue(boolean value) { this.value = value; }
    public void toggle() { this.value = !this.value; }
}
