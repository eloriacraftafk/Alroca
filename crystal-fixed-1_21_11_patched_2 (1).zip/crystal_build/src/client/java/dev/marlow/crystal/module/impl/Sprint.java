package dev.marlow.crystal.module.impl;

import dev.marlow.crystal.module.Module;
import dev.marlow.crystal.module.setting.BoolSetting;
import dev.marlow.crystal.module.setting.IntSetting;
import dev.marlow.crystal.module.setting.Randomizer;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.world.entity.player.Player;

/**
 * Sprint — multi-AC bypass layer.
 *
 * Grim SprintA:
 *   - food <= 6 blocks sprint; we respect this by default
 *   - sprint while sneaking → flag; we check isShiftKeyDown()
 *   - sprint while using item → flag; we check isUsingItem()
 *   - sprint while horizontally colliding → flag
 *   - instant sprint on first tick of forward movement → sometimes flagged
 *     → startDelay introduces 2–5 tick delay matching natural key-down latency
 *
 * Polar / Intave:
 *   - SprintA flag extended: check sprint packet order vs motion
 *   - Delay variance (gaussianLong) prevents mechanical pattern
 *
 * Badlion / Themis:
 *   - Multi-direction sprint: strafe sprint while only side key down flags some builds
 *     → multiDir is off by default
 */
public class Sprint extends Module {
    private final BoolSetting ignoreHunger = new BoolSetting("Ignore Hunger", false);
    private final BoolSetting multiDir     = new BoolSetting("Multi Direction",false);
    private final IntSetting  startDelay   = new IntSetting ("Start Delay",   3,  1, 10);

    private int delayLeft;

    public Sprint() { super("Sprint", "Multi-AC auto sprint"); }

    public BoolSetting getIgnoreHunger() { return ignoreHunger; }
    public BoolSetting getMultiDir()     { return multiDir; }
    public IntSetting  getStartDelay()   { return startDelay; }

    @Override
    public void onTick(Player player) {
        if (!isEnabled()) return;
        if (!(player instanceof LocalPlayer lp)) return;
        Minecraft mc = getMc();
        if (mc.options == null) return;

        boolean forward = mc.options.keyUp.isDown();
        boolean any = forward
                || (multiDir.getValue() && (mc.options.keyDown.isDown()
                || mc.options.keyLeft.isDown()
                || mc.options.keyRight.isDown()));

        if (!any) {
            // reset delay with variance (Polar mechanical pattern)
            delayLeft = startDelay.getValue() + (int) Randomizer.INSTANCE.gaussianLong(0, 3);
            return;
        }

        // Grim SprintA hard guards
        if (lp.isShiftKeyDown())       return;
        if (lp.isUsingItem())          return;
        if (lp.horizontalCollision)    return;
        if (!ignoreHunger.getValue() && lp.getFoodData().getFoodLevel() <= 6) return;
        if (lp.isSprinting())          return;

        if (delayLeft > 0) { delayLeft--; return; }

        lp.setSprinting(true);
    }
}
