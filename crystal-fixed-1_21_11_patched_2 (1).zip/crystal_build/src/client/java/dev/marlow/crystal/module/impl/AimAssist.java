package dev.marlow.crystal.module.impl;

import dev.marlow.crystal.module.Module;
import dev.marlow.crystal.module.setting.FloatSetting;
import dev.marlow.crystal.module.setting.GrimMouseSimulator;
import dev.marlow.crystal.module.setting.IntSetting;
import dev.marlow.crystal.module.setting.Randomizer;
import net.minecraft.client.Minecraft;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;

/**
 * AimAssist — multi-AC bypass layer.
 *
 * Grim:
 *   - AimModulo360:     yawΔ ≠ 0, never equals 360-multiple, capped to ±24.9
 *   - AimDuplicateLook: (yaw,pitch) must change every tick, min Δ 0.0078125
 *   - Cinematic:        randomized strength + stutter prevents smooth-curve detection
 *   - MouseAccel:       quadratic noise scaling via GrimMouseSimulator
 *
 * Polar / Intave:
 *   - σ(δyaw) check: jitter keeps variance in human range (σ ≈ 0.3–1.8°)
 *   - Jerk: GrimMouseSimulator.humanize() injects 3rd-derivative noise
 *   - Pause distribution: shouldStutter() inserts ~8% pause ticks
 *
 * Badlion AC:
 *   - Checks yaw consistency in 20-tick windows; pauseChance + stutter break regularity
 *   - Requires FOV gating: assist only within realistic tracking FOV
 *
 * Themis / Spartan:
 *   - Target-swap spike: smoothTarget() interpolates to new target over 2 ticks
 */
public class AimAssist extends Module {
    private final FloatSetting fov        = new FloatSetting("FOV",        80f,    30f,  140f);
    private final FloatSetting strength   = new FloatSetting("Strength",   0.032f, 0.01f, 0.09f);
    private final FloatSetting range      = new FloatSetting("Range",      4.0f,   1f,    5.5f);
    private final FloatSetting jitter     = new FloatSetting("Jitter",     0.18f,  0.04f, 0.45f);
    private final FloatSetting maxStep    = new FloatSetting("Max Step",   2.0f,   0.4f,  5.5f);
    private final IntSetting   pauseChance= new IntSetting  ("Pause %",    10,     5,     35);

    // Target smoothing state (Themis target-swap spike guard)
    private LivingEntity prevTarget;
    private float smoothYaw, smoothPitch;
    private int smoothTicks;

    private float lastYaw, lastPitch;
    private boolean hasLast;

    public AimAssist() { super("AimAssist", "Multi-AC aim assist"); }

    public FloatSetting getFov()         { return fov; }
    public FloatSetting getStrength()    { return strength; }
    public FloatSetting getRange()       { return range; }
    public FloatSetting getJitter()      { return jitter; }
    public FloatSetting getMaxStep()     { return maxStep; }
    public IntSetting   getPauseChance() { return pauseChance; }

    @Override
    public void onEnable() {
        GrimMouseSimulator.INSTANCE.resetSession();
        hasLast = false;
        prevTarget = null;
        smoothTicks = 0;
    }

    @Override
    public void onTick(Player player) {
        if (!isEnabled()) return;

        // Stutter pause (Polar/Intave pause distribution)
        if (GrimMouseSimulator.INSTANCE.shouldStutter()) return;
        // Additional random pause (Badlion consistency break)
        if (Randomizer.INSTANCE.roll(pauseChance.getValue())) return;

        Minecraft mc = getMc();
        if (mc.level == null || mc.screen != null) return;
        if (player.isUsingItem()) return;

        LivingEntity target = findTarget(mc, player);
        if (target == null) { prevTarget = null; return; }

        // Themis target-swap: if target changed, interpolate over 2 ticks
        if (target != prevTarget) {
            smoothTicks = 2;
            prevTarget = target;
        }

        Vec3 eyes   = player.getEyePosition();
        // Aim slightly below eye center — more natural, avoids head-lock detection
        Vec3 aimPos = target.getEyePosition().add(0, -0.07, 0);
        Vec3 delta  = aimPos.subtract(eyes);
        if (delta.length() < 0.001) return;

        float targetYaw   = (float)(Mth.atan2(delta.z, delta.x) * (180.0 / Math.PI)) - 90f;
        float targetPitch = (float)(-(Mth.atan2(delta.y,
                Math.sqrt(delta.x * delta.x + delta.z * delta.z)) * (180.0 / Math.PI)));

        float yaw   = player.getYRot();
        float pitch = player.getXRot();
        float dy    = Mth.wrapDegrees(targetYaw - yaw);
        float dp    = targetPitch - pitch;

        // Strength with ±20% random variance (Polar σ check)
        float str = strength.getValue() * (float) Randomizer.INSTANCE.uniform(0.80, 1.20);

        // Themis smooth: reduce step on target swap ticks
        if (smoothTicks > 0) {
            str *= 0.45f;
            smoothTicks--;
        }

        float rawYaw   = dy * str;
        float rawPitch = dp * str;

        // Cap at maxStep before humanizer (humanizer may add noise beyond this)
        float cap = maxStep.getValue();
        rawYaw   = Mth.clamp(rawYaw,   -cap, cap);
        rawPitch = Mth.clamp(rawPitch, -cap * 0.65f, cap * 0.65f);

        // Full humanization pipeline (Grim+Polar+Intave jerk/accel/stutter)
        float[] humanized = GrimMouseSimulator.INSTANCE.humanize(rawYaw, rawPitch);
        float addYaw   = humanized[0];
        float addPitch = humanized[1];

        float ny = yaw   + addYaw;
        float np = Mth.clamp(pitch + addPitch, -90f, 90f);

        // AimDuplicateLook: exact same value as last tick is flagged
        if (hasLast && ny == lastYaw && np == lastPitch) {
            ny += Randomizer.INSTANCE.jitterF(0.012f);
        }

        player.setYRot(ny);
        player.setXRot(np);
        lastYaw  = ny;
        lastPitch = np;
        hasLast = true;
    }

    private LivingEntity findTarget(Minecraft mc, Player player) {
        double bestDist = range.getValue();
        LivingEntity best = null;
        for (Entity e : mc.level.entitiesForRendering()) {
            if (!(e instanceof LivingEntity living) || !living.isAlive() || e == player) continue;
            double d = player.distanceTo(e);
            if (d > bestDist) continue;
            if (!isInFov(player, living)) continue;
            bestDist = d;
            best = living;
        }
        return best;
    }

    private boolean isInFov(Player player, LivingEntity entity) {
        Vec3 eyes = player.getEyePosition();
        Vec3 to   = entity.getEyePosition().subtract(eyes).normalize();
        Vec3 look = player.getLookAngle();
        double angle = Math.toDegrees(Math.acos(Mth.clamp(look.dot(to), -1.0, 1.0)));
        return angle <= fov.getValue() / 2.0;
    }
}
