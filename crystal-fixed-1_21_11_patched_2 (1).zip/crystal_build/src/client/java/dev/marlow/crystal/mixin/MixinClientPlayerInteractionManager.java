package dev.marlow.crystal.mixin;

import dev.marlow.crystal.module.Module;
import dev.marlow.crystal.module.ModuleManager;
import dev.marlow.crystal.module.impl.ElyFix;
import dev.marlow.crystal.module.impl.FireworkSwap;
import net.minecraft.client.multiplayer.MultiPlayerGameMode;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Items;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(MultiPlayerGameMode.class)
public class MixinClientPlayerInteractionManager {

    // Existing FireworkSwap hook — unchanged
    @Inject(method = "attack", at = @At("HEAD"))
    private void onAttackEntity(Player player, Entity entity, CallbackInfo ci) {
        if (!(entity instanceof LivingEntity living)) return;
        Module module = ModuleManager.INSTANCE.getByName("FireworkSwap");
        if (module instanceof FireworkSwap fw) {
            fw.onAttack(player, living);
        }
    }

    // ElyFix hook: intercept useItem when holding a firework while gliding
    @Inject(method = "useItem", at = @At("HEAD"), cancellable = true)
    private void onUseItem(LocalPlayer player, InteractionHand hand,
                           CallbackInfoReturnable<InteractionResult> cir) {
        if (hand != InteractionHand.MAIN_HAND) return;
        var held = player.getItemInHand(hand);
        if (held.isEmpty() || held.getItem() != Items.FIREWORK_ROCKET) return;
        if (!player.isFallFlying()) return;

        Module mod = ModuleManager.INSTANCE.getByName("ElyFix");
        if (!(mod instanceof ElyFix ely)) return;

        // ElyFix handles the use internally (spoof + double jet)
        if (ely.onFireworkUse(player)) {
            cir.setReturnValue(InteractionResult.SUCCESS);
        }
    }
}
