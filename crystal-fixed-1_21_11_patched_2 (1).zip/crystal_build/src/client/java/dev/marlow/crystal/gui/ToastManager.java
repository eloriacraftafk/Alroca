package dev.marlow.crystal.gui;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;

import java.util.ArrayDeque;

public final class ToastManager {
    public static final ToastManager INSTANCE = new ToastManager();
    private final ArrayDeque<Toast> toasts = new ArrayDeque<>();

    private ToastManager() {}

    public void push(String moduleName, boolean enabled) {
        toasts.removeIf(t -> t.getModuleName().equals(moduleName));
        toasts.addLast(new Toast(moduleName, enabled));
        while (toasts.size() > 5) toasts.removeFirst();
    }

    public void render(GuiGraphics graphics) {
        toasts.removeIf(Toast::expired);
        if (toasts.isEmpty()) return;

        Minecraft mc = Minecraft.getInstance();
        int screenW = mc.getWindow().getGuiScaledWidth();
        int screenH = mc.getWindow().getGuiScaledHeight();
        int baseY = (int) (screenH * 0.62f);
        int toastW = 150;
        int toastH = 18;
        int gap = 3;
        int i = 0;

        for (Toast toast : toasts) {
            float alpha = toast.alpha();
            if (alpha <= 0f) continue;
            int a = (int) (alpha * 230);
            // slide in from right based on alpha rising
            float slide = (1f - alpha) * 24f;
            int x = (int) ((screenW - toastW) / 2f + slide);
            int y = baseY + i * (toastH + gap);

            int bg = (a << 24) | 0x121218;
            int accent = toast.isEnabled() ? ((a << 24) | 0x55FF55) : ((a << 24) | 0xFF5555);

            graphics.fill(x + 1, y, x + toastW - 1, y + toastH, bg);
            graphics.fill(x, y + 1, x + toastW, y + toastH - 1, bg);
            graphics.fill(x, y, x + 2, y + toastH, accent);

            String text = toast.getModuleName() + (toast.isEnabled() ? "  on" : "  off");
            graphics.drawString(mc.font, text, x + 8, y + 5, (a << 24) | 0xFFFFFF);
            i++;
        }
    }
}
