package dev.marlow.crystal.module.impl;

import dev.marlow.crystal.module.Module;
import dev.marlow.crystal.module.setting.BoolSetting;
import dev.marlow.crystal.module.setting.IntSetting;
import dev.marlow.crystal.module.setting.Randomizer;
import net.minecraft.client.Minecraft;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;

/**
 * TriggerBot — multi-AC bypass layer.
 *
 * Grim:
 *   - Hitboxes: only attacks mc.crosshairPickEntity (server ray must intersect AABB)
 *   - Reach:    hard cap 2.98 — not 3.0, server-side tolerance is not full block
 *   - BadPacketsN: cooldown >= 0.95
 *   - Timer:    minimum 60ms between attacks enforced
 *
 * Polar / Intave:
 *   - Reaction time model: very short delays (< 80ms) flag "inhuman" TriggerBot
 *     → minDelay floor 95ms (matches ~92nd percentile human reaction to target enter)
 *   - Lognormal delay (humanClickInterval) prevents flat-CPS flag
 *   - missChance 7%: Polar models miss events; zero miss rate → flag
 *
 * Badlion AC:
 *   - Checks for swing immediately after crosshair entity enter frame
 *     → reaction jitter from Randomizer.jitterF delays the attack slightly
 *
 * Themis / Spartan:
 *   - Burst: same burst guard as AttackAura (2 attacks per 160ms window)
 */
public class TriggerBot extends Module {
    private final IntSetting  minDelay   = new IntSetting  ("Min Delay",  95,  60,  280);
    private final IntSetting  maxDelay   = new IntSetting  ("Max Delay",  185, 100, 420);
    private final BoolSetting weaponOnly = new BoolSetting ("Weapon Only",true);
    private final IntSetting  missChance = new IntSetting  ("Miss %",     7,   0,   20);

    private long lastAttack;
    private long nextDelay;

    // Burst guard
    private int  attacksInWindow;
    private long windowStart;
    private static final int  MAX_BURST        = 2;
    private static final long BURST_WINDOW_MS  = 160L;

    public TriggerBot() { super("TriggerBot", "Multi-AC crosshair attack"); }

    public IntSetting  getMinDelay()   { return minDelay; }
    public IntSetting  getMaxDelay()   { return maxDelay; }
    public BoolSetting getWeaponOnly() { return weaponOnly; }
    public IntSetting  getMissChance() { return missChance; }

    @Override
    public void onEnable() {
        scheduleNext();
        attacksInWindow = 0;
        windowStart = System.currentTimeMillis();
    }

    private void scheduleNext() {
        nextDelay = Randomizer.INSTANCE.humanClickInterval(minDelay.getValue(), maxDelay.getValue());
    }

    @Override
    public void onTick(Player player) {
        if (!isEnabled()) return;
        Minecraft mc = getMc();
        if (mc.screen != null) return;
        if (player.isUsingItem()) return;

        if (weaponOnly.getValue()) {
            String key = player.getMainHandItem().getItem().toString().toLowerCase();
            if (!key.contains("sword") && !key.contains("axe") && !key.contains("trident")) return;
        }

        long now = System.currentTimeMillis();

        // Burst guard (Themis)
        if (now - windowStart > BURST_WINDOW_MS) {
            attacksInWindow = 0;
            windowStart = now;
        }
        if (attacksInWindow >= MAX_BURST) return;

        if (now - lastAttack < nextDelay) return;

        // Grim Hitboxes: only crosshair entity
        Entity entity = mc.crosshairPickEntity;
        if (!(entity instanceof LivingEntity living) || !living.isAlive() || entity == player) return;

        // Grim Reach: hard cap 2.98
        if (player.distanceTo(entity) > 2.98) return;

        // Grim BadPacketsN
        float cd = player.getAttackStrengthScale(0.5f);
        if (cd < 0.95f) return;

        // Miss (Polar/Intave human model)
        if (Randomizer.INSTANCE.roll(missChance.getValue())) {
            scheduleNext();
            return;
        }

        // Reaction jitter: add tiny delay so it doesn't fire first frame (Badlion)
        if (Randomizer.INSTANCE.roll(30)) {
            long jitter = (long) Randomizer.INSTANCE.uniform(0, 20);
            if (now - lastAttack < nextDelay + jitter) return;
        }

        player.swing(InteractionHand.MAIN_HAND);
        if (mc.gameMode != null) mc.gameMode.attack(player, entity);
        lastAttack = now;
        attacksInWindow++;
        scheduleNext();
    }
}
