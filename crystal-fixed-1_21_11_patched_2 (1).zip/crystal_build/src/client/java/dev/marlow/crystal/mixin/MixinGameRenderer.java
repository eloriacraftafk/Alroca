package dev.marlow.crystal.mixin;

import com.mojang.blaze3d.vertex.PoseStack;
import dev.marlow.crystal.module.Module;
import dev.marlow.crystal.module.ModuleManager;
import dev.marlow.crystal.module.impl.TargetEsp;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.GameRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(GameRenderer.class)
public class MixinGameRenderer {

    /**
     * Hooks renderLevel TAIL to draw TargetEsp world ring.
     * Replaces WorldRenderEvents.AFTER_ENTITIES (removed in FAPI 0.141+).
     *
     * 1.21.11 renderLevel signature no longer takes a PoseStack param —
     * we allocate a fresh identity PoseStack here (camera offset is
     * applied inside TargetEsp.renderWorld via camera.position()).
     */
    @Inject(method = "renderLevel", at = @At("TAIL"))
    private void onRenderLevel(CallbackInfo ci) {
        Module mod = ModuleManager.INSTANCE.getByName("TargetEsp");
        if (!(mod instanceof TargetEsp esp) || !mod.isEnabled()) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.gameRenderer == null) return;
        // 1.21.5+: Minecraft#getDeltaTracker() replaces getTimer()
        float partialTick = mc.getDeltaTracker().getGameTimeDeltaPartialTick(true);
        esp.renderWorld(new PoseStack(), partialTick);
    }
}
