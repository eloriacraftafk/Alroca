package dev.marlow.crystal.module.impl;

import dev.marlow.crystal.module.Module;
import dev.marlow.crystal.module.setting.BoolSetting;
import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.player.Player;

/**
 * Client-side custom display name.
 * Local tab/HUD/nametag uses this string.
 * Note: real server chat/tab for OTHER players still shows account name
 * unless the server is offline-mode / has a nick plugin. We still force
 * local replacements everywhere we control.
 */
public class NameHider extends Module {
    private final BoolSetting hideInTab = new BoolSetting("Hide In Tab", true);
    private final BoolSetting hideNametag = new BoolSetting("Hide Nametag", true);

    private static String customName = "Player";

    public NameHider() {
        super("NameHider", "Custom local display name");
    }

    public BoolSetting getHideInTab() { return hideInTab; }
    public BoolSetting getHideNametag() { return hideNametag; }

    public static String getCustomName() {
        return customName;
    }

    public static void setCustomName(String name) {
        if (name == null || name.isBlank()) name = "Player";
        customName = name.trim();
        // apply to local player display if possible
        Minecraft mc = Minecraft.getInstance();
        if (mc.player != null) {
            try {
                mc.player.setCustomName(Component.literal(customName));
                mc.player.setCustomNameVisible(true);
            } catch (Exception ignored) {}
        }
    }

    public static String resolve(String original) {
        Module m = dev.marlow.crystal.module.ModuleManager.INSTANCE.getByName("NameHider");
        if (m == null || !m.isEnabled()) return original;
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null) return original;
        String real = mc.player.getGameProfile().getName();
        if (original != null && original.equalsIgnoreCase(real)) {
            return customName;
        }
        return original;
    }

    @Override
    public void onEnable() {
        setCustomName(customName);
    }

    @Override
    public void onTick(Player player) {
        // keep custom name applied
        if (player.getCustomName() == null || !customName.equals(player.getCustomName().getString())) {
            player.setCustomName(Component.literal(customName));
            player.setCustomNameVisible(true);
        }
    }
}
