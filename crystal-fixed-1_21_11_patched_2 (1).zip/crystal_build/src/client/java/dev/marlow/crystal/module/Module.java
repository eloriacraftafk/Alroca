package dev.marlow.crystal.module;

import dev.marlow.crystal.gui.ToastManager;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.world.entity.player.Player;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;

public abstract class Module {
    private final String name;
    private final String description;
    private int key;
    private boolean enabled;

    public Module(String name, String description, int key) {
        this.name = name;
        this.description = description;
        this.key = key;
    }

    public Module(String name, String description) {
        this(name, description, -1);
    }

    public String getName() { return name; }
    public String getDescription() { return description; }
    public int getKey() { return key; }
    public void setKey(int key) { this.key = key; }
    public boolean isEnabled() { return enabled; }

    public void setEnabled(boolean value) {
        if (this.enabled == value) return;
        this.enabled = value;
        ToastManager.INSTANCE.push(name, value);
        if (value) onEnable();
        else onDisable();
    }

    public void toggle() {
        setEnabled(!enabled);
    }

    protected Minecraft getMc() {
        return Minecraft.getInstance();
    }

    public List<Object> getSettings() {
        List<Object> list = new ArrayList<>();
        for (Field f : getClass().getDeclaredFields()) {
            f.setAccessible(true);
            try {
                Object v = f.get(this);
                if (v != null && v.getClass().getName().contains("Setting")) {
                    list.add(v);
                }
            } catch (Exception ignored) {}
        }
        return list;
    }

    public void onEnable() {}
    public void onDisable() {}
    public void onTick(Player player) {}
    public void onRender(GuiGraphics graphics) {}
}
