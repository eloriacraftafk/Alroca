package dev.marlow.crystal.module.impl;

import dev.marlow.crystal.module.Module;
import dev.marlow.crystal.module.setting.BoolSetting;
import dev.marlow.crystal.module.setting.IntSetting;
import dev.marlow.crystal.module.setting.Randomizer;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.tags.ItemTags;
import net.minecraft.world.item.ItemStack;

/**
 * FireworkSwap — multi-AC bypass layer.
 *
 * Grim MultiActions:
 *   - Inventory slot change and attack in same tick → flag
 *   - Minimum 2 ticks separation required after attack before slot change
 *   → pendingTicks floor is 2, default swapDelay 3
 *
 * Grim PacketOrder:
 *   - Container clicks must follow expected order vs attack packets
 *   - Slot change must not arrive before swing packet is processed
 *   → delay queued, fired in onTick after attack packet is gone
 *
 * Polar / Intave:
 *   - Mechanical swap timing: same delay every attack → flag
 *   → gaussian variance on pendingTicks
 */
public class FireworkSwap extends Module {
    private final BoolSetting onAttack       = new BoolSetting("On Attack",        true);
    private final BoolSetting onlyIfNotSword = new BoolSetting("Only If Not Sword",true);
    private final IntSetting  swapDelay      = new IntSetting ("Swap Delay",       3,   2,  8);

    private int pendingSlot = -1;
    private int pendingTicks;

    public FireworkSwap() { super("FireworkSwap", "Multi-AC delayed sword swap"); }

    public BoolSetting getOnAttack()       { return onAttack; }
    public BoolSetting getOnlyIfNotSword() { return onlyIfNotSword; }
    public IntSetting  getSwapDelay()      { return swapDelay; }

    public void onAttack(Player player, LivingEntity target) {
        if (!isEnabled() || !onAttack.getValue()) return;
        if (pendingSlot != -1 || pendingTicks > 0) return;

        ItemStack held = player.getMainHandItem();
        if (onlyIfNotSword.getValue() && held.is(ItemTags.SWORDS)) return;

        int swordSlot = findSwordSlot(player);
        if (swordSlot == -1) return;
        if (swordSlot == player.getInventory().getSelectedSlot()) return;

        pendingSlot = swordSlot;
        // Grim MultiActions floor: 2 ticks minimum; gaussian variance (Polar)
        pendingTicks = Math.max(2, swapDelay.getValue()) + (int) Randomizer.INSTANCE.gaussianLong(0, 3);
    }

    private int findSwordSlot(Player player) {
        for (int i = 0; i < 9; i++) {
            if (player.getInventory().getItem(i).is(ItemTags.SWORDS)) return i;
        }
        return -1;
    }

    @Override
    public void onTick(Player player) {
        if (!isEnabled()) return;
        if (pendingTicks > 0) {
            pendingTicks--;
            if (pendingTicks == 0 && pendingSlot >= 0) {
                player.getInventory().setSelectedSlot(pendingSlot);
                pendingSlot = -1;
            }
        }
    }
}
