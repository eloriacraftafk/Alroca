package dev.marlow.crystal.bypass;

import com.google.gson.*;
import dev.marlow.crystal.module.Module;
import dev.marlow.crystal.module.ModuleManager;
import dev.marlow.crystal.module.setting.BoolSetting;
import dev.marlow.crystal.module.setting.FloatSetting;
import dev.marlow.crystal.module.setting.IntSetting;
import net.fabricmc.loader.api.FabricLoader;

import java.io.*;
import java.nio.file.*;

/**
 * JSON config persistence — multi-profile support.
 * Files: .minecraft/crystal_configs/<profile>.json
 * Default profile: "default"
 *
 * API:
 *   setCurrentProfile(name)  — switch active profile (doesn't load/save)
 *   getCurrentProfile()      — active profile name
 *   save()                   — write current state to <profile>.json
 *   load()                   — read <profile>.json into module state
 */
public final class ConfigManager {
    public static final ConfigManager INSTANCE = new ConfigManager();
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

    private final Path configDir;
    private String currentProfile = "default";

    private ConfigManager() {
        configDir = FabricLoader.getInstance().getGameDir().resolve("crystal_configs");
        try { Files.createDirectories(configDir); } catch (IOException ignored) {}
    }

    public String getCurrentProfile() { return currentProfile; }

    public void setCurrentProfile(String name) {
        if (name == null || name.isBlank()) name = "default";
        currentProfile = name.trim().replaceAll("[^a-zA-Z0-9_\\-]", "_");
    }

    private Path profileFile() {
        return configDir.resolve(currentProfile + ".json");
    }

    public void save() {
        JsonObject root = new JsonObject();
        for (Module m : ModuleManager.INSTANCE.getModules()) {
            JsonObject mod = new JsonObject();
            mod.addProperty("enabled", m.isEnabled());
            JsonObject settings = new JsonObject();
            for (Object s : m.getSettings()) {
                if      (s instanceof BoolSetting  b) settings.addProperty(b.getName(), b.getValue());
                else if (s instanceof FloatSetting f) settings.addProperty(f.getName(), f.getValue());
                else if (s instanceof IntSetting   i) settings.addProperty(i.getName(), i.getValue());
            }
            mod.add("settings", settings);
            root.add(m.getName(), mod);
        }
        try (Writer w = Files.newBufferedWriter(profileFile())) {
            GSON.toJson(root, w);
        } catch (IOException e) {
            System.err.println("[Crystal] Config save failed (" + currentProfile + "): " + e.getMessage());
        }
    }

    public void load() {
        Path file = profileFile();
        if (!Files.exists(file)) return;
        try (Reader r = Files.newBufferedReader(file)) {
            JsonObject root = GSON.fromJson(r, JsonObject.class);
            if (root == null) return;
            for (Module m : ModuleManager.INSTANCE.getModules()) {
                JsonObject mod = root.getAsJsonObject(m.getName());
                if (mod == null) continue;
                if (mod.has("enabled")) {
                    boolean en = mod.get("enabled").getAsBoolean();
                    // write directly to avoid toast spam on load
                    try {
                        var f = Module.class.getDeclaredField("enabled");
                        f.setAccessible(true);
                        f.set(m, en);
                    } catch (Exception ignored) {}
                }
                JsonObject settings = mod.getAsJsonObject("settings");
                if (settings == null) continue;
                for (Object s : m.getSettings()) {
                    if      (s instanceof BoolSetting  b && settings.has(b.getName()))
                        b.setValue(settings.get(b.getName()).getAsBoolean());
                    else if (s instanceof FloatSetting f && settings.has(f.getName()))
                        f.setValue(settings.get(f.getName()).getAsFloat());
                    else if (s instanceof IntSetting   i && settings.has(i.getName()))
                        i.setValue(settings.get(i.getName()).getAsInt());
                }
            }
        } catch (IOException e) {
            System.err.println("[Crystal] Config load failed (" + currentProfile + "): " + e.getMessage());
        }
    }
}
