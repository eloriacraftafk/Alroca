package dev.marlow.crystal.module.setting;

public class IntSetting {
    private final String name;
    private int value;
    private final int min, max;

    public IntSetting(String name, int defaultValue, int min, int max) {
        this.name = name;
        this.value = defaultValue;
        this.min = min;
        this.max = max;
    }

    public String getName() { return name; }
    public int getValue() { return value; }
    public void setValue(int value) {
        this.value = Math.max(min, Math.min(max, value));
    }
    public int getMin() { return min; }
    public int getMax() { return max; }
}
