package dev.marlow.crystal.gui;

public class Toast {
    private final String moduleName;
    private final boolean enabled;
    private final long created;
    private static final long DURATION = 2200;

    public Toast(String moduleName, boolean enabled) {
        this.moduleName = moduleName;
        this.enabled = enabled;
        this.created = System.currentTimeMillis();
    }

    public String getModuleName() { return moduleName; }
    public boolean isEnabled() { return enabled; }

    public float alpha() {
        long age = System.currentTimeMillis() - created;
        if (age < 200) return age / 200f;
        if (age > DURATION - 300) return Math.max(0f, (DURATION - age) / 300f);
        return 1f;
    }

    public boolean expired() {
        return System.currentTimeMillis() - created > DURATION;
    }
}
