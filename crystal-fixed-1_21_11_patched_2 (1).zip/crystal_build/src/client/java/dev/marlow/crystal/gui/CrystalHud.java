package dev.marlow.crystal.gui;

import dev.marlow.crystal.module.Module;
import dev.marlow.crystal.module.ModuleManager;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.Font;
import net.minecraft.network.chat.Component;

/**
 * Compact arraylist — enabled modules only, purple accent.
 * Watermark: top-left pill row  »  Release | <nick> | fps | time | coords | ping | ticks | bps
 */
public final class CrystalHud {
    public static final CrystalHud INSTANCE = new CrystalHud();

    // Watermark colours — matching screenshot palette
    private static final int COL_BG     = 0xB0151520; // dark pill bg
    private static final int COL_DIV    = 0xFF444455; // separator
    private static final int COL_ICON   = 0xFFAAAAAA; // icon / label tint
    private static final int COL_WHITE  = 0xFFE8E8F0; // value text
    private static final int COL_PURPLE = 0xFF982689; // accent

    // Watermark pill dimensions
    private static final int PAD_X = 5;
    private static final int PAD_Y = 3;
    private static final int HEIGHT = 11; // font height + 2*PAD_Y roughly

    private CrystalHud() {}

    public void init() {}

    public void render(GuiGraphics graphics) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.options.hideGui) return;

        Font font = mc.font;

        // ── Watermark row 1 ─────────────────────────────────────────────────
        // segments: "Release"  |  <nick>  |  <fps> Fps  |  <time>
        long now       = System.currentTimeMillis();
        int  fps       = mc.getFps();
        String nick    = mc.player.getName().getString();
        java.time.LocalTime lt = java.time.LocalTime.now();
        String timeStr = String.format("%02d:%02d:%02d", lt.getHour(), lt.getMinute(), lt.getSecond());

        String[] row1 = {
            "Release",
            nick,
            fps + " Fps",
            timeStr
        };

        // ── Watermark row 2 ─────────────────────────────────────────────────
        // segments: coords  |  ping  |  ticks  |  bps
        int x = (int) mc.player.getX();
        int y2 = (int) mc.player.getY();
        int z = (int) mc.player.getZ();
        int ping = 0;
        if (mc.getConnection() != null && mc.getConnection().getPlayerInfo(mc.player.getUUID()) != null) {
            ping = mc.getConnection().getPlayerInfo(mc.player.getUUID()).getLatency();
        }
        // server ticks/bps — only available if server sends them; use 0 as fallback
        float ticks = 20.0f;
        float bps   = 0.0f;

        String[] row2 = {
            x + ", " + y2 + ", " + z,
            ping + " Ping",
            String.format("%.1f Ticks", ticks),
            String.format("%.1f Bps", bps)
        };

        drawPillRow(graphics, font, 2, 2,  row1);
        drawPillRow(graphics, font, 2, 16, row2);

        // ── Module arraylist ─────────────────────────────────────────────────
        int ay = 32;
        for (Module m : ModuleManager.INSTANCE.getModules()) {
            if (!m.isEnabled()) continue;
            graphics.fill(2, ay - 1, 4, ay + 9, COL_PURPLE);
            graphics.drawString(font, m.getName(), 7, ay, COL_WHITE);
            ay += 11;
        }

        ToastManager.INSTANCE.render(graphics);
    }

    // ── helpers ───────────────────────────────────────────────────────────────

    /**
     * Draws a horizontal pill row of segments separated by thin dividers.
     * Each segment: [PAD_X] text [PAD_X] | ...
     * Row is rendered at (startX, startY), height = font.lineHeight + 2*PAD_Y.
     */
    private void drawPillRow(GuiGraphics g, Font font, int startX, int startY,
                              String[] segments) {
        int fh    = font.lineHeight; // typically 9
        int rowH  = fh + PAD_Y * 2;
        int cx    = startX;

        // measure total width first
        int totalW = 0;
        for (int i = 0; i < segments.length; i++) {
            totalW += PAD_X + font.width(segments[i]) + PAD_X;
            if (i < segments.length - 1) totalW += 1; // divider
        }

        // background pill
        drawRoundRect(g, cx, startY, cx + totalW, startY + rowH, COL_BG);

        // segments
        for (int i = 0; i < segments.length; i++) {
            String seg = segments[i];
            int sw = font.width(seg);

            // text
            g.drawString(font, seg, cx + PAD_X, startY + PAD_Y, COL_WHITE, false);
            cx += PAD_X + sw + PAD_X;

            // divider
            if (i < segments.length - 1) {
                g.fill(cx, startY + 2, cx + 1, startY + rowH - 2, COL_DIV);
                cx += 1;
            }
        }
    }

    /** Minimal filled rect — MC 1.21 GuiGraphics has no built-in rounded rect,
     *  so we fake it with 1-pixel corner cutoffs (barely visible at this scale). */
    private void drawRoundRect(GuiGraphics g, int x0, int y0, int x1, int y1, int color) {
        // main fill minus corners
        g.fill(x0 + 1, y0,     x1 - 1, y1,     color);
        g.fill(x0,     y0 + 1, x1,     y1 - 1, color);
    }
}
