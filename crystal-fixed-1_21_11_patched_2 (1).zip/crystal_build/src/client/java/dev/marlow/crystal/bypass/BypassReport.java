package dev.marlow.crystal.bypass;

import java.util.*;

/**
 * BypassReport — static registry of which AC checks each module targets.
 * Populated at init; queried by CrystalScreen to show the bypass table.
 *
 * Format per entry:
 *   moduleName → List<BypassEntry{ ac, checkName, notes }>
 */
public final class BypassReport {
    public record BypassEntry(String ac, String checkName, String notes) {}

    private static final Map<String, List<BypassEntry>> REPORT = new LinkedHashMap<>();

    static {
        reg("AimAssist",
            e("Grim",    "AimModulo360",      "yawΔ capped ±24.9, never 0 or 360-multiple"),
            e("Grim",    "AimDuplicateLook",  "forced min Δ 0.0078125 every tick"),
            e("Grim",    "CinematicCamera",   "randomized strength + stutter breaks smooth-curve"),
            e("Grim",    "MouseAccel",        "quadratic accel noise via GrimMouseSimulator"),
            e("Polar",   "σ(δyaw) check",     "jitter keeps variance σ ≈ 0.3–1.8°"),
            e("Polar",   "JerkDetect",        "d³/dt³ noise injected by humanize()"),
            e("Polar",   "PauseDistrib",      "~8% stutter ticks via shouldStutter()"),
            e("Intave",  "RotConsis",         "same variance + stutter as Polar path"),
            e("Badlion", "YawConsistency20t", "pauseChance + stutter break 20-tick window"),
            e("Themis",  "TargetSwapSpike",   "smoothTarget() interpolates over 2 ticks on swap")
        );

        reg("AttackAura",
            e("Grim",    "Reach",             "hard cap 2.95, below Grim 2.98 tolerance"),
            e("Grim",    "Hitboxes",          "angleTo check gates attack to expanded AABB"),
            e("Grim",    "BadPacketsN",        "CD gate 0.92 (not 0.90) for prediction headroom"),
            e("Grim",    "AimDuplicateLook",  "forced yaw change before every swing packet"),
            e("Grim",    "Timer",             "floor 60ms, lognormal delay, no < 60ms"),
            e("Polar",   "CPS Consistency",   "humanClickInterval lognormal prevents flat CPS"),
            e("Polar",   "MissRate",          "missChance 5% — Polar models human misses"),
            e("Intave",  "CPS Consistency",   "same lognormal path as Polar"),
            e("Badlion", "SwingMotion",       "rotate forces yaw change before swing packet"),
            e("Themis",  "BurstPattern",      "2-attack / 160ms burst guard"),
            e("Spartan", "SwingFrequency",    "delay floor 60ms enforced")
        );

        reg("TriggerBot",
            e("Grim",    "Hitboxes",          "only mc.crosshairPickEntity"),
            e("Grim",    "Reach",             "hard cap 2.98"),
            e("Grim",    "BadPacketsN",        "CD gate 0.95"),
            e("Grim",    "Timer",             "floor 60ms, lognormal"),
            e("Polar",   "ReactionModel",     "minDelay 95ms ≥ 92nd-pct human reaction"),
            e("Polar",   "CPS Flat",          "lognormal distribution, not uniform"),
            e("Polar",   "MissRate",          "7% miss events"),
            e("Badlion", "FirstFrameFire",    "30% chance reaction jitter on crosshair enter"),
            e("Themis",  "BurstPattern",      "shared burst guard with AttackAura"),
            e("Spartan", "SwingFrequency",    "floor 60ms enforced")
        );

        reg("Velocity",
            e("Grim",    "VelocityH",         "horizontal floor 0.14 + [0,0.06] random residual"),
            e("Grim",    "VelocityV",         "vertical floor 0.10 + [0,0.05] random residual"),
            e("Polar",   "MechDetect",        "±15% per-hit variance breaks flat-reduction flag"),
            e("Polar",   "PassRate",          "20% full KB pass for consistency"),
            e("Intave",  "MechDetect",        "same variance + pass path as Polar"),
            e("Badlion", "KBConsistency",     "passChance 20% matches empirical passing threshold"),
            e("Themis",  "ExpectedKB",        "passChance + floor matches server prediction"),
            e("Spartan", "DeltaVelocity",     "floor prevents near-zero reduction flag")
        );

        reg("Sprint",
            e("Grim",    "SprintA (food)",    "food <= 6 guard respected; ignoreHunger off by default"),
            e("Grim",    "SprintA (sneak)",   "isShiftKeyDown() checked"),
            e("Grim",    "SprintA (item)",    "isUsingItem() checked"),
            e("Grim",    "SprintA (collide)", "horizontalCollision checked"),
            e("Grim",    "SprintA (instant)", "startDelay 2–5 ticks, gaussian variance"),
            e("Polar",   "MechPattern",       "delay variance (gaussianLong) on key-down")
        );

        reg("AimAssist/AttackAura rotation",
            e("Grim",    "AimModulo360",      "yawΔ % 360 ≠ 0, capped ±24.9 everywhere"),
            e("Grim",    "AimDuplicateLook",  "GrimMouseSimulator.clampNotZero enforces ε = 0.0078125")
        );

        reg("FireworkSwap",
            e("Grim",    "MultiActions",      "pendingTicks floor 2 — slot change never same tick as attack"),
            e("Grim",    "PacketOrder",       "swap queued, fired in onTick after attack packet"),
            e("Polar",   "MechTiming",        "gaussian variance on pendingTicks")
        );

        reg("NameHider",
            e("N/A",     "Client-side only",  "server tab / chat unaffected on online-mode servers")
        );

        reg("TargetEsp",
            e("N/A",     "Render only",       "no packets sent; zero server-side detection surface")
        );

        reg("FakePlayer / ElyFix",
            e("N/A",     "Client-side only",  "no modified outbound packets")
        );
    }

    private static void reg(String module, BypassEntry... entries) {
        REPORT.put(module, List.of(entries));
    }

    private static BypassEntry e(String ac, String check, String notes) {
        return new BypassEntry(ac, check, notes);
    }

    public static Map<String, List<BypassEntry>> getReport() {
        return Collections.unmodifiableMap(REPORT);
    }

    /** Formats the full report as a human-readable string for logging. */
    public static String formatText() {
        StringBuilder sb = new StringBuilder();
        sb.append("=== Crystal Bypass Report ===\n\n");
        for (var entry : REPORT.entrySet()) {
            sb.append("[ ").append(entry.getKey()).append(" ]\n");
            for (var bp : entry.getValue()) {
                sb.append(String.format("  %-10s  %-28s  %s%n", bp.ac(), bp.checkName(), bp.notes()));
            }
            sb.append("\n");
        }
        return sb.toString();
    }
}
