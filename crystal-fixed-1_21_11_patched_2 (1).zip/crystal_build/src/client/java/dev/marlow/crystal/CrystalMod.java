package dev.marlow.crystal;

import dev.marlow.crystal.bypass.BypassReport;
import dev.marlow.crystal.bypass.ConfigManager;
import dev.marlow.crystal.gui.CrystalHud;
import dev.marlow.crystal.gui.CrystalScreen;
import dev.marlow.crystal.module.Module;
import dev.marlow.crystal.module.ModuleManager;
import dev.marlow.crystal.module.impl.NameHider;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.message.v1.ClientSendMessageEvents;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.Component;
import org.lwjgl.glfw.GLFW;

import java.util.HashMap;
import java.util.Map;

public class CrystalMod implements ClientModInitializer {
    private final Map<Integer, Boolean> keyPrevState = new HashMap<>();
    private boolean menuKeyPrev;

    @Override
    public void onInitializeClient() {
        ModuleManager.INSTANCE.init();
        CrystalHud.INSTANCE.init();

        ConfigManager.INSTANCE.load();

        System.out.print(BypassReport.formatText());

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            ModuleManager.INSTANCE.onTick();

            long window = GLFW.glfwGetCurrentContext();
            boolean menuDown = GLFW.glfwGetKey(window, GLFW.GLFW_KEY_RIGHT_SHIFT) == GLFW.GLFW_PRESS;
            if (menuDown && !menuKeyPrev) {
                if (client.getScreen() instanceof CrystalScreen) {
                    client.setScreen(null);
                    ConfigManager.INSTANCE.save();
                } else {
                    client.setScreen(new CrystalScreen());
                }
            }
            menuKeyPrev = menuDown;

            for (Module mod : ModuleManager.INSTANCE.getModules()) {
                int key = mod.getKey();
                if (key == -1) continue;
                boolean nowDown = GLFW.glfwGetKey(window, key) == GLFW.GLFW_PRESS;
                boolean wasDown = keyPrevState.getOrDefault(key, false);
                if (nowDown && !wasDown) mod.toggle();
                keyPrevState.put(key, nowDown);
            }
        });

        HudRenderCallback.EVENT.register((graphics, tickCounter) -> {
            CrystalHud.INSTANCE.render(graphics);
            ModuleManager.INSTANCE.onRender(graphics);
        });

        // WorldRenderEvents removed in FAPI 0.141+1.21.11 —
        // TargetEsp world render now wired via MixinGameRenderer.renderLevel

        ClientSendMessageEvents.ALLOW_CHAT.register(message -> {
            if (message.startsWith(".name ")) {
                String nick = message.substring(6).trim();
                if (!nick.isEmpty()) {
                    NameHider.setCustomName(nick);
                    Minecraft mc = Minecraft.getInstance();
                    if (mc.player != null) {
                        mc.player.displayClientMessage(
                                Component.literal("§a[Crystal] name set to §f" + nick), false);
                    }
                    Module m = ModuleManager.INSTANCE.getByName("NameHider");
                    if (m != null && !m.isEnabled()) m.setEnabled(true);
                }
                return false;
            }
            if (message.equalsIgnoreCase(".name")) {
                Minecraft mc = Minecraft.getInstance();
                if (mc.player != null) {
                    mc.player.displayClientMessage(
                            Component.literal("§e[Crystal] current: §f" + NameHider.getCustomName()), false);
                }
                return false;
            }
            return true;
        });
    }
}
