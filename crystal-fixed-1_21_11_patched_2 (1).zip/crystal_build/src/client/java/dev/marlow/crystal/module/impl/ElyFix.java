package dev.marlow.crystal.module.impl;

import dev.marlow.crystal.module.Module;
import dev.marlow.crystal.module.setting.BoolSetting;
import dev.marlow.crystal.module.setting.IntSetting;
import dev.marlow.crystal.module.setting.Randomizer;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

/**
 * ElyFix — Wall-Rocket spoof + Double Jet boost.
 *
 * Problem 1 — Wall-Rocket (Grim FastUse / ElytraFlyingGliding):
 *   Grim flags USE_ITEM (firework) when the player's look vector intersects
 *   a block at the moment of use. In crystal trap the player constantly faces
 *   obsidian walls, so raw firework use always flags.
 *   Fix: before firing, we find the nearest clear (air-facing) yaw offset
 *   (+0°, ±90°, 180°) using a short raytrace, snap rotation there for one
 *   tick, fire, then restore. The server sees a valid USE_ITEM with a clear
 *   line of sight.
 *
 * Problem 2 — Double Jet (Grim ElytraBoost / Polar momentum):
 *   Single firework gives ~0.75 blocks/tick horizontal boost. In a tight trap
 *   surround that's often not enough to clear. Double Jet schedules a second
 *   UseItem call 1–2 ticks after the first (gaussian jitter, Polar mechanical
 *   detection). Grim allows two boost packets per elytra fly phase before
 *   flagging; we stay at exactly 2.
 *
 * Settings:
 *   Wall Spoof   — rotate away from wall before firework use
 *   Double Jet   — fire second boost 1–2 ticks after first
 *   Spoof Offset — preferred clear-yaw search order (0=forward first)
 */
public class ElyFix extends Module {

    private final BoolSetting wallSpoof  = new BoolSetting("Wall Spoof",  true);
    private final BoolSetting doubleJet  = new BoolSetting("Double Jet",  true);
    private final IntSetting  jetDelay   = new IntSetting ("Jet Delay",   1,  1, 3);

    // Double-jet state
    private int pendingJetTick = -1;   // countdown; fires when reaches 0
    private float savedYaw, savedPitch;
    private boolean restoreRot = false;

    // Candidate yaw offsets to try when wall-spoofing (degrees from current yaw)
    private static final float[] SPOOF_OFFSETS = { 0f, -90f, 90f, 180f,
                                                    -45f, 45f, -135f, 135f };

    public ElyFix() {
        super("ElyFix", "Wall-rocket spoof + double jet boost");
    }

    public BoolSetting getWallSpoof() { return wallSpoof; }
    public BoolSetting getDoubleJet() { return doubleJet; }
    public IntSetting  getJetDelay()  { return jetDelay; }

    @Override
    public void onDisable() {
        pendingJetTick = -1;
        restoreRot = false;
    }

    @Override
    public void onTick(Player player) {
        if (!isEnabled()) return;
        if (!(player instanceof LocalPlayer lp)) return;
        Minecraft mc = getMc();
        if (mc.level == null || mc.screen != null) return;
        if (!lp.isFallFlying()) { pendingJetTick = -1; restoreRot = false; return; }

        // --- Restore rotation after wall-spoof ---
        if (restoreRot) {
            lp.setYRot(savedYaw);
            lp.setXRot(savedPitch);
            restoreRot = false;
        }

        // --- Pending double-jet countdown ---
        if (pendingJetTick > 0) {
            pendingJetTick--;
            return;
        }
        if (pendingJetTick == 0) {
            pendingJetTick = -1;
            int fwSlot = findFireworkSlot(lp);
            if (fwSlot != -1) {
                int prev = lp.getInventory().getSelectedSlot();
                lp.getInventory().setSelectedSlot(fwSlot);
                mc.gameMode.useItem(lp, InteractionHand.MAIN_HAND);
                lp.getInventory().setSelectedSlot(prev);
            }
        }
    }

    /**
     * Call this when the player manually presses the firework key / right-clicks
     * while gliding. CrystalMod wires this via MixinClientPlayerInteractionManager
     * or we hook it from the existing mixin by adding a check there.
     *
     * Returns true if we intercepted (cancelled the original use; we handle it).
     */
    public boolean onFireworkUse(LocalPlayer player) {
        if (!isEnabled() || !player.isFallFlying()) return false;
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null) return false;

        int fwSlot = findFireworkSlot(player);
        if (fwSlot == -1) return false;

        // --- Wall Spoof: find a clear yaw ---
        float fireYaw   = player.getYRot();
        float firePitch = -20f; // slightly up — standard rocket angle

        if (wallSpoof.getValue()) {
            Float clearYaw = findClearYaw(player);
            if (clearYaw != null) {
                savedYaw   = player.getYRot();
                savedPitch = player.getXRot();
                player.setYRot(clearYaw);
                player.setXRot(firePitch);
                restoreRot = true;
                fireYaw    = clearYaw;
            }
        }

        // --- Fire first rocket ---
        int prev = player.getInventory().getSelectedSlot();
        player.getInventory().setSelectedSlot(fwSlot);
        mc.gameMode.useItem(player, InteractionHand.MAIN_HAND);
        player.getInventory().setSelectedSlot(prev);

        // --- Schedule second rocket (Double Jet) ---
        if (doubleJet.getValue() && findFireworkSlot(player) != -1) {
            // Gaussian jitter on delay (Polar mechanical detection)
            int delay = jetDelay.getValue()
                    + (int) Randomizer.INSTANCE.gaussianLong(0, 1);
            pendingJetTick = Math.max(1, delay);
        }

        return true;
    }

    // ── helpers ──────────────────────────────────────────────────────────────

    /**
     * Returns the first yaw (from SPOOF_OFFSETS) where a 4.5-block raycast
     * does not hit a block, or null if all directions are blocked.
     */
    private Float findClearYaw(LocalPlayer player) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null) return null;

        Vec3 eyes = player.getEyePosition();
        float baseYaw = player.getYRot();

        for (float offset : SPOOF_OFFSETS) {
            float yaw = baseYaw + offset;
            Vec3 dir = dirFromAngles(yaw, -15f); // slight upward angle
            Vec3 end = eyes.add(dir.scale(4.5));

            BlockHitResult hit = mc.level.clip(new ClipContext(
                    eyes, end,
                    ClipContext.Block.COLLIDER,
                    ClipContext.Fluid.NONE,
                    player));

            if (hit.getType() == HitResult.Type.MISS) {
                return yaw;
            }
        }
        return null; // surrounded — fire anyway without spoof
    }

    private static Vec3 dirFromAngles(float yawDeg, float pitchDeg) {
        double yaw   = Math.toRadians(yawDeg);
        double pitch = Math.toRadians(pitchDeg);
        double cosP  = Math.cos(pitch);
        return new Vec3(
                -Math.sin(yaw) * cosP,
                -Math.sin(pitch),
                 Math.cos(yaw) * cosP
        ).normalize();
    }

    private static int findFireworkSlot(LocalPlayer player) {
        for (int i = 0; i < 9; i++) {
            var item = player.getInventory().getItem(i);
            if (!item.isEmpty() && item.getItem() == net.minecraft.world.item.Items.FIREWORK_ROCKET)
                return i;
        }
        return -1;
    }
}
