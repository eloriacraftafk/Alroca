package dev.marlow.crystal.module.impl;

import com.mojang.authlib.GameProfile;
import dev.marlow.crystal.module.Module;
import dev.marlow.crystal.module.setting.FloatSetting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.RemotePlayer;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;

import java.lang.reflect.Method;
import java.util.UUID;

/**
 * Spawns a client-side copy of you in front for testing aim/aura/esp.
 * Only exists on your client — not a real server entity.
 */
public class FakePlayer extends Module {
    private final FloatSetting distance = new FloatSetting("Distance", 3.0f, 1.0f, 8.0f);

    private RemotePlayer bot;

    public FakePlayer() {
        super("FakePlayer", "Client-side bot clone for testing");
    }

    public FloatSetting getDistance() { return distance; }

    @Override
    public void onEnable() {
        spawn();
    }

    @Override
    public void onDisable() {
        remove();
    }

    private void spawn() {
        Minecraft mc = getMc();
        if (mc.player == null || mc.level == null) return;
        remove();

        GameProfile profile = new GameProfile(UUID.randomUUID(), mc.player.getGameProfile().getName() + "_bot");
        bot = new RemotePlayer(mc.level, profile);

        double yawRad = Math.toRadians(mc.player.getYRot());
        double dist = distance.getValue();
        double x = mc.player.getX() - Math.sin(yawRad) * dist;
        double z = mc.player.getZ() + Math.cos(yawRad) * dist;
        double y = mc.player.getY();

        bot.setPos(x, y, z);
        bot.setYRot(mc.player.getYRot() + 180f);
        bot.setXRot(0f);
        bot.setYHeadRot(bot.getYRot());
        bot.setYBodyRot(bot.getYRot());

        for (var slot : net.minecraft.world.entity.EquipmentSlot.values()) {
            bot.setItemSlot(slot, mc.player.getItemBySlot(slot).copy());
        }

        // 1.21.11 Mojang: ClientLevel has addEntity(Entity) accessible via reflection
        // Direct call to avoid Mojang obfuscation mismatch at dev time
        try {
            Method m = mc.level.getClass().getMethod("addEntity", net.minecraft.world.entity.Entity.class);
            m.invoke(mc.level, bot);
        } catch (Exception e1) {
            try {
                // fallback: putNonPlayerEntity(int id, Entity e)
                Method m = mc.level.getClass().getMethod("putNonPlayerEntity", int.class, net.minecraft.world.entity.Entity.class);
                m.invoke(mc.level, bot.getId(), bot);
            } catch (Exception e2) {
                // FakePlayer unavailable on this MC version
                bot = null;
            }
        }
    }

    private void remove() {
        Minecraft mc = getMc();
        if (bot != null && mc.level != null) {
            bot.discard();
            bot = null;
        }
    }

    @Override
    public void onTick(Player player) {
        if (bot == null || bot.isRemoved()) {
            if (isEnabled()) spawn();
        }
    }
}
