package dev.marlow.crystal.module;

import dev.marlow.crystal.module.impl.*;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.world.entity.player.Player;

import java.util.ArrayList;
import java.util.List;

public final class ModuleManager {
    public static final ModuleManager INSTANCE = new ModuleManager();
    private final List<Module> modules = new ArrayList<>();

    private ModuleManager() {}

    public void init() {
        modules.clear();
        // left 5
        modules.add(new AimAssist());
        modules.add(new TriggerBot());
        modules.add(new TargetEsp());
        modules.add(new NameHider());
        modules.add(new Sprint());
        // right 5
        modules.add(new AttackAura());
        modules.add(new FireworkSwap());
        modules.add(new ElyFix());
        modules.add(new FakePlayer());
        modules.add(new Velocity());
    }

    public List<Module> getModules() {
        return modules;
    }

    public Module getByName(String name) {
        for (Module m : modules) {
            if (m.getName().equalsIgnoreCase(name)) return m;
        }
        return null;
    }

    public void onTick() {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.level == null) return;
        Player player = mc.player;
        for (Module m : modules) {
            if (m.isEnabled()) {
                m.onTick(player);
            }
        }
    }

    public void onRender(GuiGraphics graphics) {
        for (Module m : modules) {
            if (m.isEnabled()) {
                m.onRender(graphics);
            }
        }
    }

    public void onKeyPress(int key) {
        for (Module m : modules) {
            if (m.getKey() == key) {
                m.toggle();
            }
        }
    }
}
