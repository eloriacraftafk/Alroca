package dev.marlow.crystal.module.setting;

public class FloatSetting {
    private final String name;
    private float value;
    private final float min, max;

    public FloatSetting(String name, float defaultValue, float min, float max) {
        this.name = name;
        this.value = defaultValue;
        this.min = min;
        this.max = max;
    }

    public String getName() { return name; }
    public float getValue() { return value; }
    public void setValue(float value) {
        this.value = Math.max(min, Math.min(max, value));
    }
    public float getMin() { return min; }
    public float getMax() { return max; }
}
