package dev.marlow.crystal.module.impl;

import dev.marlow.crystal.module.Module;
import dev.marlow.crystal.module.setting.BoolSetting;
import dev.marlow.crystal.module.setting.FloatSetting;
import dev.marlow.crystal.module.setting.GrimMouseSimulator;
import dev.marlow.crystal.module.setting.IntSetting;
import dev.marlow.crystal.module.setting.Randomizer;
import net.minecraft.client.Minecraft;
import net.minecraft.util.Mth;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;

/**
 * AttackAura — multi-AC bypass layer.
 *
 * Grim:
 *   - Reach:          hard cap at 2.98 (vanilla interaction is 3.0, Grim adds ~0.0 tolerance)
 *   - Hitboxes:       attack only when entity is in expanded AABB ray — angleTo check
 *   - MultiActions:   never attack same tick as inventory action (FireworkSwap guards this)
 *   - BadPacketsN:    cooldown must be ≥ 0.90 at attack time
 *   - Timer:          attack delay must not be faster than 1 attack per 50ms
 *
 * Polar / Intave:
 *   - CPS consistency: lognormal delay distribution (humanClickInterval) prevents flat CPS
 *   - 1-target focus: random target switching looks mechanical; we keep 1 target per burst
 *   - Attack on CD < 0.90: filtered; we check 0.92 to give server prediction headroom
 *
 * Badlion AC:
 *   - Swing packet without player motion check: rotate must produce visible yaw change
 *   - Identical rotation across swing sequence: AimDuplicateLook enforced
 *
 * Themis:
 *   - Burst pattern: > 2 attacks in 150ms is flagged; nextDelay floor 110ms
 *   - Reach via lag compensation: lag allows slightly extended reach — we stay at 2.98
 *
 * Spartan:
 *   - Checks for swing packet frequency; delay floor 60ms minimum enforced here
 */
public class AttackAura extends Module {
    private final FloatSetting range      = new FloatSetting("Range",      2.95f, 2.4f,  2.98f);
    private final BoolSetting  rotate     = new BoolSetting ("Rotate",     false);
    private final FloatSetting rotSpeed   = new FloatSetting("Rot Speed",  0.22f, 0.05f, 0.55f);
    private final IntSetting   minDelay   = new IntSetting  ("Min Delay",  110,   60,    280);
    private final IntSetting   maxDelay   = new IntSetting  ("Max Delay",  175,   110,   380);
    private final BoolSetting  weaponOnly = new BoolSetting ("Weapon Only",true);
    private final FloatSetting maxAngle   = new FloatSetting("Max Angle",  38f,   15f,   75f);
    private final IntSetting   missChance = new IntSetting  ("Miss %",     5,     0,     15);

    private long lastSwing;
    private long nextDelay;
    private float lastYaw, lastPitch;
    private boolean hasLastRot;

    // Burst guard (Themis)
    private int attacksInWindow;
    private long windowStart;
    private static final int MAX_BURST = 2;
    private static final long BURST_WINDOW_MS = 160L;

    public AttackAura() { super("AttackAura", "Multi-AC auto attack"); }

    public FloatSetting getRange()      { return range; }
    public BoolSetting  getRotate()     { return rotate; }
    public FloatSetting getRotSpeed()   { return rotSpeed; }
    public IntSetting   getMinDelay()   { return minDelay; }
    public IntSetting   getMaxDelay()   { return maxDelay; }
    public BoolSetting  getWeaponOnly() { return weaponOnly; }
    public FloatSetting getMaxAngle()   { return maxAngle; }
    public IntSetting   getMissChance() { return missChance; }

    @Override
    public void onEnable() {
        scheduleDelay();
        hasLastRot = false;
        attacksInWindow = 0;
        windowStart = System.currentTimeMillis();
    }

    private void scheduleDelay() {
        // Lognormal distribution (Polar/Intave CPS consistency check)
        nextDelay = Randomizer.INSTANCE.humanClickInterval(minDelay.getValue(), maxDelay.getValue());
    }

    @Override
    public void onTick(Player player) {
        if (!isEnabled()) return;
        Minecraft mc = getMc();
        if (mc.level == null || mc.screen != null) return;
        if (player.isUsingItem()) return;

        if (weaponOnly.getValue()) {
            String key = player.getMainHandItem().getItem().toString().toLowerCase();
            if (!key.contains("sword") && !key.contains("axe") && !key.contains("trident")) return;
        }

        long now = System.currentTimeMillis();

        // Themis burst guard
        if (now - windowStart > BURST_WINDOW_MS) {
            attacksInWindow = 0;
            windowStart = now;
        }
        if (attacksInWindow >= MAX_BURST) return;

        // Grim BadPacketsN: cooldown >= 0.92 (not 0.90 — prediction headroom)
        float cd = player.getAttackStrengthScale(0.5f);
        if (cd < 0.92f) return;

        if (now - lastSwing < nextDelay) return;

        // Miss chance (Polar CPS: occasional misses look human)
        if (Randomizer.INSTANCE.roll(missChance.getValue())) {
            scheduleDelay();
            return;
        }

        LivingEntity target = findTarget(mc, player);
        if (target == null) return;

        if (rotate.getValue()) {
            applySoftRot(player, target);
        }

        // AimDuplicateLook: never send identical rotation twice
        float yaw   = player.getYRot();
        float pitch = player.getXRot();
        if (hasLastRot && yaw == lastYaw && pitch == lastPitch) {
            player.setYRot(yaw + Randomizer.INSTANCE.jitterF(0.01f));
        }
        lastYaw   = player.getYRot();
        lastPitch = player.getXRot();
        hasLastRot = true;

        player.swing(InteractionHand.MAIN_HAND);
        if (mc.gameMode != null) mc.gameMode.attack(player, target);
        lastSwing = now;
        attacksInWindow++;
        scheduleDelay();
    }

    private LivingEntity findTarget(Minecraft mc, Player player) {
        LivingEntity best = null;
        double bestDist = range.getValue();
        for (Entity e : mc.level.entitiesForRendering()) {
            if (!(e instanceof LivingEntity living) || !living.isAlive() || e == player) continue;
            double d = player.distanceTo(e);
            if (d > bestDist) continue;
            if (angleTo(player, living) > maxAngle.getValue()) continue;
            bestDist = d;
            best = living;
        }
        return best;
    }

    private void applySoftRot(Player player, LivingEntity target) {
        Vec3 eyes = player.getEyePosition();
        Vec3 aim  = target.getEyePosition().subtract(eyes);
        float ty = (float)(Mth.atan2(aim.z, aim.x) * (180.0 / Math.PI)) - 90f;
        float tp = (float)(-(Mth.atan2(aim.y,
                Math.sqrt(aim.x * aim.x + aim.z * aim.z)) * (180.0 / Math.PI)));
        float dy = Mth.wrapDegrees(ty - player.getYRot());
        float dp = tp - player.getXRot();

        float[] h = GrimMouseSimulator.INSTANCE.humanize(
                Mth.clamp(dy, -24.9f, 24.9f) * rotSpeed.getValue(),
                Mth.clamp(dp, -15f, 15f) * rotSpeed.getValue()
        );
        player.setYRot(player.getYRot() + h[0]);
        player.setXRot(Mth.clamp(player.getXRot() + h[1], -90f, 90f));
    }

    private float angleTo(Player player, LivingEntity entity) {
        Vec3 to   = entity.getEyePosition().subtract(player.getEyePosition()).normalize();
        Vec3 look = player.getLookAngle();
        return (float) Math.toDegrees(Math.acos(Mth.clamp(look.dot(to), -1.0, 1.0)));
    }
}
