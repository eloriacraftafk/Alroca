package dev.marlow.crystal.module.setting;

/**
 * Humanized mouse delta pipeline targeting Grim AimAssist/AimDuplicateLook/AimModulo360.
 *
 * Grim checks (all sourced from grim source, PlayerData.java / AimProcessor.java):
 *  - AimModulo360:     yawDelta % 360 must not == 0 and must be "small" for inertia model
 *  - AimDuplicateLook: (yaw,pitch) can't be identical to previous tick
 *  - Cinematic camera: detected if movement exactly follows a smoothed curve every tick
 *  - Mouse accel model: Grim models mouse accel; perfect linear deltas fail
 *
 * Polar / Intave also model:
 *  - Rotation consistency: σ of δyaw per 20-tick window shouldn't be too low (macro)
 *  - Jerk (3rd derivative): > 0 or the signal is mechanical
 *  - Pause distribution: humans occasionally pause; zero pauses in 100 ticks flags
 *
 * This class applies:
 *  1. Noise injection matching mouse accel curve (quadratic, not flat)
 *  2. Session-based "fatigue" drift (slight bias accumulates and reverses)
 *  3. Micro-stutter insertion (1–3 tick pauses ~8% of time)
 *  4. Jerk injection (d³/dt³ ≠ 0)
 *  5. AimModulo360 hard guard
 *  6. AimDuplicateLook: forced min Δ of 0.0078125 (Grim's float epsilon)
 */
public final class GrimMouseSimulator {
    public static final GrimMouseSimulator INSTANCE = new GrimMouseSimulator();

    // Fatigue state — simulates wrist drift over session
    private float fatigueBiasYaw  = 0f;
    private float fatigueBiasPitch = 0f;
    private int   fatigueTick = 0;

    // Previous output — for jerk calculation
    private float prevDeltaYaw   = 0f;
    private float prevDeltaPitch = 0f;
    private float prevJerkYaw    = 0f;

    // Stutter state
    private int stutterCooldown = 0;

    private GrimMouseSimulator() {}

    public void resetSession() {
        fatigueBiasYaw   = (float) Randomizer.INSTANCE.uniform(-0.015, 0.015);
        fatigueBiasPitch = (float) Randomizer.INSTANCE.uniform(-0.008, 0.008);
        fatigueTick = 0;
        prevDeltaYaw = prevDeltaPitch = prevJerkYaw = 0f;
        stutterCooldown = 0;
    }

    /**
     * Apply full humanization pipeline to a raw rotation delta.
     * @param rawYaw   raw yaw delta (pre-clamped by caller)
     * @param rawPitch raw pitch delta
     * @return float[2]{humanizedYaw, humanizedPitch}
     */
    public float[] humanize(float rawYaw, float rawPitch) {
        fatigueTick++;

        // --- 1. Fatigue bias drifts slowly, reverses at [60,90] tick intervals ---
        int fatigueperiod = 60 + (int) Randomizer.INSTANCE.uniform(0, 30);
        if (fatigueTick % fatigueperiod == 0) {
            fatigueBiasYaw   = (float) Randomizer.INSTANCE.uniform(-0.02, 0.02);
            fatigueBiasPitch = (float) Randomizer.INSTANCE.uniform(-0.01, 0.01);
        }

        // --- 2. Mouse accel noise: quadratic scaling with |delta| (not flat) ---
        float absYaw = Math.abs(rawYaw);
        float accelScale = 0.04f + absYaw * 0.012f;   // bigger moves → more noise
        float noiseYaw   = Randomizer.INSTANCE.jitterF(accelScale);
        float noisePitch = Randomizer.INSTANCE.jitterF(accelScale * 0.55f);

        float outYaw   = rawYaw   + noiseYaw   + fatigueBiasYaw;
        float outPitch = rawPitch + noisePitch + fatigueBiasPitch;

        // --- 3. Jerk injection — ensure d³/dt³ ≠ 0 ---
        float jerkYaw   = outYaw   - prevDeltaYaw;
        float jerkDelta = jerkYaw  - prevJerkYaw;
        // if jerk is too close to 0 (mechanical), perturb
        if (Math.abs(jerkDelta) < 0.001f) {
            outYaw += Randomizer.INSTANCE.jitterF(0.018f);
        }
        prevJerkYaw  = jerkYaw;
        prevDeltaYaw  = outYaw;
        prevDeltaPitch = outPitch;

        // --- 4. AimModulo360 hard guard (Grim exact check) ---
        // delta must not be 0 and must not reduce to a 360-multiple
        outYaw = clampNotZero(outYaw, 0.0078125f);

        // --- 5. AimDuplicateLook: enforce min change ---
        if (Math.abs(outYaw) < 0.0078125f)   outYaw   = 0.0078125f * Math.signum(outYaw != 0 ? outYaw : 1);
        if (Math.abs(outPitch) < 0.0078125f) outPitch = 0.0078125f * Math.signum(outPitch != 0 ? outPitch : 1);

        // --- 6. AimModulo360 final: cap at ±25 (Grim inertia model threshold) ---
        outYaw   = clamp(outYaw,   -24.9f, 24.9f);
        outPitch = clamp(outPitch, -16.0f, 16.0f);

        return new float[]{outYaw, outPitch};
    }

    /**
     * Single-axis humanization (legacy compat for existing calls).
     */
    public float getHumanizedDelta(float raw) {
        float[] r = humanize(raw, 0f);
        return r[0];
    }

    /**
     * Returns true if a stutter pause should be applied this tick (~8% chance,
     * min 15 ticks between stutters to avoid clustering flags).
     */
    public boolean shouldStutter() {
        if (stutterCooldown > 0) { stutterCooldown--; return false; }
        if (Randomizer.INSTANCE.roll(8.0)) {
            stutterCooldown = 15 + (int) Randomizer.INSTANCE.uniform(0, 10);
            return true;
        }
        return false;
    }

    private float clamp(float v, float lo, float hi) {
        return Math.max(lo, Math.min(hi, v));
    }

    private float clampNotZero(float v, float epsilon) {
        if (v == 0f) return epsilon;
        if (Math.abs(v) < epsilon) return epsilon * Math.signum(v);
        return v;
    }
}
